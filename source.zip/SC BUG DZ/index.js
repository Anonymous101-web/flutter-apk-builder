global.CUSTOM_PAIRING_CODE = "WORLDMD1";

import "./lib/version.js";
import {
  checkAndInstallModules as e,
  clearDirectory as o,
} from "./lib/utils.js";

process.env.TZ = "Asia/Jakarta";
(await import("./config.js")).default.phone_number_bot;

async function s(e) {}

try {
  o("./tmp");
  setInterval(() => {
    console.log("Cleaning tmp directory...");
    o("./tmp");
  }, 108e5);

  console.log("Starting WORLD MD Bot...");
  await e([
    "jimp@0.16.13",
    "moment-timezone",
    "pino@9.6.0",
    "qr-image",
    "sharp@0.33.5",
  ]);

  const { start_app: r } = await import("./lib/startup.js");
  await r();
} catch (t) {
  console.error("Error starting application:", t.message);
  await s();
  process.exit(1);
}

process.on("uncaughtException", (e) => {});
process.on("unhandledRejection", (e) => {});
