import { isOwner } from "../lib/users.js";
import { isGroupBlocked } from "../lib/blockedGroup.js";
import { logWithTime } from "../lib/utils.js";

// Handler paling awal: jika grup diblokir, hentikan semua proses (tidak membalas apapun)
// KECUALI: owner bisa menjalankan perintah unblock di grup tersebut.
async function process(sock, messageInfo) {
  const { remoteJid, isGroup, sender, command } = messageInfo;
  if (!isGroup) return true;

  if (!isGroupBlocked(remoteJid)) return true;

  const isOwnerUsers = isOwner(sender);
  const cmd = String(command || "").toLowerCase();
  const allowCmd = ["unblockgrup", "unblockgroup"].includes(cmd);

  if (isOwnerUsers && allowCmd) return true;

  // Silent mode untuk grup yang diblokir
  logWithTime("SYSTEM", `Blocked group: ignore all messages in ${remoteJid}`);
  return false;
}

export default {
  name: "Blocked Group Handler",
  priority: 0,
  process,
};
