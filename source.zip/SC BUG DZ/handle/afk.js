import { findUser, updateUser } from "../lib/users.js";
import { formatDuration, logTracking } from "../lib/utils.js";
import { logCustom } from "../lib/logger.js";

const MAX_DEPTH = 10;

function normalizeJid(jid = "") {
  return String(jid || "").replace(/:\d+(?=@)/, "");
}

function jidToTag(jid = "") {
  const number = normalizeJid(jid).split("@")[0].split(":")[0].replace(/\D/g, "");
  return number ? `@${number}` : "@user";
}

function cleanReason(reason = "") {
  const cleaned = String(reason || "")
    .replace(/^\s*alasan\s*:\s*/i, "")
    .trim();

  if (!cleaned || /^tanpa\s+alasan$/i.test(cleaned)) return "Tanpa alasan";
  return cleaned;
}

function safeFormatDuration(lastChat) {
  try {
    if (!lastChat) return "belum diketahui";
    return formatDuration(lastChat);
  } catch {
    return "belum diketahui";
  }
}

function addPossibleMention(set, jid) {
  if (!jid || typeof jid !== "string") return;

  const clean = normalizeJid(jid.trim());
  if (clean.endsWith("@s.whatsapp.net") || clean.endsWith("@lid")) {
    set.add(clean);
    return;
  }

  const number = clean.replace(/\D/g, "");
  if (/^\d{6,18}$/.test(number)) {
    set.add(`${number}@s.whatsapp.net`);
  }
}

function collectMentionedJids(messageInfo = {}) {
  const mentioned = new Set();

  if (Array.isArray(messageInfo.mentionedJid)) {
    messageInfo.mentionedJid.forEach((jid) => addPossibleMention(mentioned, jid));
  }

  const scan = (value, depth = 0, seen = new Set()) => {
    if (!value || depth > MAX_DEPTH) return;

    if (typeof value === "string") {
      addPossibleMention(mentioned, value);
      return;
    }

    if (typeof value !== "object") return;
    if (seen.has(value)) return;
    seen.add(value);

    if (Array.isArray(value)) {
      value.forEach((item) => scan(item, depth + 1, seen));
      return;
    }

    for (const [key, child] of Object.entries(value)) {
      if (key === "mentionedJid" && Array.isArray(child)) {
        child.forEach((jid) => addPossibleMention(mentioned, jid));
        continue;
      }
      scan(child, depth + 1, seen);
    }
  };

  scan(messageInfo.message);
  scan(messageInfo.m?.message);

  // Cadangan: kalau user mengetik @628xxx tapi contextInfo mention tidak kebaca.
  const text = `${messageInfo.fullText || ""} ${messageInfo.content || ""}`;
  for (const match of text.matchAll(/@(\d{6,18})/g)) {
    addPossibleMention(mentioned, `${match[1]}@s.whatsapp.net`);
  }

  return [...mentioned];
}

function getBestMentionJid(jid, userData = {}) {
  const aliases = Array.isArray(userData.aliases) ? userData.aliases : [];
  const waAlias = aliases.find((alias) => String(alias).endsWith("@s.whatsapp.net"));
  const lidAlias = aliases.find((alias) => String(alias).endsWith("@lid"));
  return normalizeJid(waAlias || lidAlias || jid);
}

function isAfkUser(userData = {}) {
  return String(userData?.status || "").toLowerCase() === "afk" && Boolean(userData?.afk);
}

function buildTaggedAfkMessage(afkUsers, taggedByName = "Member") {
  const lines = afkUsers.map((item, index) => {
    const { jid, userData } = item;
    const afk = userData.afk || {};
    const name = userData.username || jidToTag(jid);
    const reason = cleanReason(afk.alasan);
    const duration = safeFormatDuration(afk.lastChat || afk.lastchat);

    return (
      `${afkUsers.length > 1 ? `${index + 1}. ` : ""}${jidToTag(jid)} *sedang AFK / tidak aktif sementara*\n` +
      `   👤 Nama: *${name}*\n` +
      `   ⏳ Sudah AFK: *${duration}*\n` +
      `   📌 Alasan: *${reason}*`
    );
  });

  return (
    `╭─〔 💤 *USER SEDANG AFK* 〕\n` +
    `│ Hai *${taggedByName}*, user yang kamu tag sedang AFK.\n` +
    `│ Mohon tunggu sampai dia kembali online.\n` +
    `│ Jangan spam tag/chat supaya notifikasi dia tidak menumpuk.\n` +
    `╰──────────────\n\n` +
    lines.join("\n\n") +
    `\n\n✅ Bot akan otomatis mematikan AFK saat user tersebut mengirim pesan lagi.`
  );
}

function buildBackFromAfkMessage(pushName, afkData = {}) {
  const duration = safeFormatDuration(afkData.lastChat || afkData.lastchat);
  const reason = cleanReason(afkData.alasan);

  return (
    `✅ *AFK Dinonaktifkan*\n\n` +
    `Selamat datang kembali, *${pushName || "Kak"}*!\n` +
    `Kamu sudah AFK selama *${duration}*.\n` +
    `📌 Alasan sebelumnya: *${reason}*`
  );
}

async function process(sock, messageInfo) {
  const { remoteJid, message, sender, pushName, isGroup } = messageInfo;

  try {
    // 1. Jalankan sebelum onlyadmin: user AFK yang chat lagi langsung dinonaktifkan.
    const dataUsers = await findUser(sender);
    if (dataUsers) {
      const [, userAfk] = dataUsers;
      if (isAfkUser(userAfk)) {
        const backMessage = buildBackFromAfkMessage(pushName, userAfk.afk);

        logTracking(`Afk Handler - ${sender} kembali aktif`);
        await sock.sendMessage(remoteJid, { text: backMessage }, { quoted: message });
        await updateUser(sender, { status: "active", afk: null });
        return false;
      }
    }

    // 2. Khusus grup: kalau ada yang tag user AFK, bot tetap membalas meski onlyadmin ON.
    if (!isGroup) return true;

    const mentionedJids = collectMentionedJids(messageInfo).filter((jid) => {
      if (!jid) return false;
      if (normalizeJid(jid) === normalizeJid(sender)) return false;
      return true;
    });

    if (!mentionedJids.length) return true;

    const afkUsers = [];
    const seen = new Set();

    for (const rawJid of mentionedJids) {
      const data = await findUser(rawJid);
      if (!data) continue;

      const [, userData] = data;
      if (!isAfkUser(userData)) continue;

      const mentionJid = getBestMentionJid(rawJid, userData);
      const normalized = normalizeJid(mentionJid);
      if (seen.has(normalized)) continue;
      seen.add(normalized);
      afkUsers.push({ jid: normalized, userData });
    }

    if (!afkUsers.length) return true;

    const limitedAfkUsers = afkUsers.slice(0, 5);
    const warningMessage = buildTaggedAfkMessage(limitedAfkUsers, pushName || "Member");
    const mentions = limitedAfkUsers.map((item) => item.jid);

    logTracking(`Afk Handler - ${sender} menandai user AFK`);
    await sock.sendMessage(
      remoteJid,
      { text: warningMessage, mentions },
      { quoted: message }
    );
  } catch (error) {
    console.error("Error in AFK process:", error);
    logCustom("info", error, `ERROR-AFK-HANDLE.txt`);
  }

  return true;
}

export default {
  name: "Afk",
  // Harus lebih kecil dari MODE ON/onlyadmin (priority 2), supaya notifikasi AFK tetap terkirim.
  priority: 1.5,
  process,
};
