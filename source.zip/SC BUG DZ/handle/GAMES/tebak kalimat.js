import{removeUser,getUser,isUserPlaying,}from"../../database/temporary_db/tebak kalimat.js";import{addUser,updateUser,deleteUser,findUser}from"../../lib/users.js";import mess from"../../strings.js";async function process(sock,messageInfo){const{remoteJid,content,fullText,message,sender}=messageInfo;if(isUserPlaying(remoteJid)){const data=getUser(remoteJid);if(fullText.toLowerCase().includes("nyerah")){removeUser(remoteJid);if(data&&data.timer){clearTimeout(data.timer);}
if(mess.game_handler.menyerah){const messageWarning=mess.game_handler.menyerah.replace("@answer",data.answer).replace("@command",data.command);await sock.sendMessage(remoteJid,{text:messageWarning,},{quoted:message});}
return false;}
if(fullText.toLowerCase()===data.answer){const hadiah=data.hadiah;const user=await findUser(sender);if(user){const[docId,userData]=user;const moneyAdd=(userData.money||0)+hadiah;await updateUser(sender,{money:moneyAdd});}else{}
if(data&&data.timer){clearTimeout(data.timer);}
removeUser(remoteJid);if(mess.game_handler.tebak_kalimat){const messageNotif=mess.game_handler.tebak_kalimat.replace("@hadiah",hadiah);await sock.sendMessage(remoteJid,{text:messageNotif,},{quoted:message});}
return false;}}
return true;}
export const name="Tebak Kalimat";export const priority=10;export{process};
