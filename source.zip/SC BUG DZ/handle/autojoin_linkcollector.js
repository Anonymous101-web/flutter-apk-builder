import path from "path";
import { isOwner } from "../lib/users.js";
import { readJson, writeJsonAtomic } from "../lib/jsondb.js";

// Auto-collect WhatsApp group invite links sent by owner.
// Owner bisa kirim beberapa link grup (tanpa command), nanti tinggal ketik *.joinall*
// untuk bot join semuanya.

const DB_PATH = path.join(process.cwd(), "database", "temporary_db", "autojoin_links.json");

function extractInviteCodes(text = "") {
  const out = [];
  const regex = /https?:\/\/chat\.whatsapp\.com\/(?:invite\/)?([A-Za-z0-9]{5,})/g;
  let match;
  while ((match = regex.exec(text)) !== null) {
    let code = match[1] || "";
    // strip query string if somehow captured
    code = code.split("?")[0].split("#")[0].trim();
    if (code) out.push(code);
  }
  // dedupe
  return [...new Set(out)];
}

function readDb() {
  return readJson(DB_PATH, { version: 1, items: [] });
}

async function addCodesToDb(codes = [], sender = "") {
  if (!codes.length) return;
  const db = readDb();
  db.items = Array.isArray(db.items) ? db.items : [];

  const existing = new Set(db.items.map((x) => x?.code).filter(Boolean));
  const now = Date.now();

  for (const code of codes) {
    if (existing.has(code)) continue;
    db.items.push({
      code,
      link: `https://chat.whatsapp.com/${code}`,
      addedAt: now,
      by: sender,
    });
    existing.add(code);
  }

  // Keep it sane
  if (db.items.length > 200) db.items = db.items.slice(-200);
  await writeJsonAtomic(DB_PATH, db);
}

async function process(sock, messageInfo) {
  try {
    const { sender, fullText, prefix, remoteJid } = messageInfo;

    // jangan collect dari command
    if (prefix) return true;

    // hanya owner
    if (!isOwner(sender)) return true;

    // skip status broadcast
    if (remoteJid === "status@broadcast") return true;

    const codes = extractInviteCodes(fullText || "");
    if (!codes.length) return true;

    await addCodesToDb(codes, sender);
  } catch (e) {
    // silent fail biar gak ganggu flow bot
  }
  return true;
}

export default {
  name: "AutoJoin Link Collector",
  priority: 90,
  process,
};
