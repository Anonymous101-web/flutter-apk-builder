import fs from 'fs/promises'
import { downloadMedia } from '../lib/utils.js'
import { setWelcome, setTemplateWelcome, setWelcomeImage, checkMessage } from '../lib/participants.js'
import {
  getWelcomeSession,
  setWelcomeSession,
  clearWelcomeSession,
  saveCustomWelcomeImage,
  removeCustomWelcomeImage,
} from '../lib/welcome_session.js'
import { WELCOME_SC_THEMES } from '../database/menu.js'
import { getGroupMetadata } from '../lib/cache.js'

function variableText() {
  return global.group?.variable || `@name\n@group\n@desc\n@size\n@date\n@day\n@time\n@greeting`
}

async function isAdminUser(sock, remoteJid, sender) {
  const groupMetadata = await getGroupMetadata(sock, remoteJid)
  const participants = groupMetadata?.participants || []
  return participants.some((p) => (p.phoneNumber === sender || p.id === sender) && p.admin)
}

async function process(sock, messageInfo) {
  const { remoteJid, sender, message, isGroup, type, fullText, command, prefix } = messageInfo
  if (!isGroup) return true

  const session = await getWelcomeSession(remoteJid, sender)
  if (!session) return true

  const allowed = await isAdminUser(sock, remoteJid, sender)
  if (!allowed) {
    await clearWelcomeSession(remoteJid, sender)
    return true
  }

  if (command === 'cancelwelcome') {
    await clearWelcomeSession(remoteJid, sender)
    await sock.sendMessage(remoteJid, { text: '✅ Session setwelcome dibatalkan.' }, { quoted: message })
    return false
  }

  if (session.step === 'await_image') {
    if (type !== 'image' && type !== 'viewonce') {
      await sock.sendMessage(
        remoteJid,
        { text: '📌 Silakan kirim *foto* dulu untuk welcome custom.\n\nKetik *.cancelwelcome* untuk batal.' },
        { quoted: message }
      )
      return false
    }

    const oldPath = session.imagePath || ''
    const mediaFile = await downloadMedia(message)
    if (!mediaFile) {
      await sock.sendMessage(remoteJid, { text: '❌ Gagal mengambil foto. Coba kirim ulang fotonya.' }, { quoted: message })
      return false
    }

    const tempPath = `./tmp/${mediaFile}`
    const buffer = await fs.readFile(tempPath)
    const finalPath = await saveCustomWelcomeImage(remoteJid, buffer)
    await removeCustomWelcomeImage(oldPath)

    await setWelcomeSession(remoteJid, sender, {
      step: 'await_text',
      imagePath: finalPath,
      mode: 'custom_image',
    })

    await sock.sendMessage(
      remoteJid,
      {
        text: `✅ Foto welcome berhasil disimpan.\n\nSekarang kirim teks welcome yang mau dipakai.\n\n*Variable yang bisa dipakai:*\n${variableText()}\n\nContoh:\nHalo @name, selamat datang di @group`,
      },
      { quoted: message }
    )
    return false
  }


  if (session.step === 'await_theme_choice') {
    const rawText = String(fullText || '').trim()
    const normalized = rawText.toLowerCase().replace(/\s+/g, ' ').trim()
    const selectedTheme = WELCOME_SC_THEMES.find((theme) => {
      const themeTitle = String(theme.title || '').toLowerCase().replace(/\s+/g, ' ').trim()
      const chooseLabel = `pakai ${themeTitle}`
      return normalized === themeTitle || normalized === chooseLabel || normalized.includes(themeTitle)
    })

    if (command === 'setwelcometheme' || selectedTheme) {
      return true
    }

    await sock.sendMessage(
      remoteJid,
      {
        text: `🎨 Silakan pilih dulu tema welcome dari script lewat card/tombol yang sudah dikirim.

Ketik *.cancelwelcome* untuk batal.`
      },
      { quoted: message }
    )
    return false
  }


  if (session.step === 'await_text') {
    const text = String(fullText || '').trim()
    const startsWithPrefix = !!(prefix && text.startsWith(prefix))
    if (!text || startsWithPrefix) {
      await sock.sendMessage(
        remoteJid,
        { text: '✍️ Sekarang kirim *teks welcome* biasa, jangan command.\n\nKetik *.cancelwelcome* untuk batal.' },
        { quoted: message }
      )
      return false
    }

    await setWelcome(remoteJid, text)

    if (session.mode === 'custom_image') {
      await setTemplateWelcome(remoteJid, 'custom')
      await setWelcomeImage(remoteJid, session.imagePath || '')
    } else if (session.mode === 'script_image' && session.selectedThemeUrl) {
      await setTemplateWelcome(remoteJid, 'custom')
      await setWelcomeImage(remoteJid, session.selectedThemeUrl)
    } else {
      const currentTemplate = await checkMessage(remoteJid, 'templatewelcome')
      const validScriptTemplate = ['1', '2', '3', '4', '5', '6', '7', 'random']
      await setTemplateWelcome(remoteJid, validScriptTemplate.includes(String(currentTemplate)) ? String(currentTemplate) : '1')
    }

    await clearWelcomeSession(remoteJid, sender)
    await sock.sendMessage(
      remoteJid,
      {
        text: `✅ Welcome berhasil di-set.\n\nMode: ${session.mode === 'custom_image' ? 'Foto sendiri' : 'Langsung dari SC'}\nPastikan fitur aktif dengan mengetik *.on welcome*`,
      },
      { quoted: message }
    )
    return false
  }

  return true
}

export default {
  name: 'SetWelcome Session',
  priority: 2,
  process,
}
