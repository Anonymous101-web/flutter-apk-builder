import { isOwner } from '../lib/users.js';
import { getMaintenance, isExpired } from '../lib/maintenance_store.js';
import { buildMaintenanceText, finishMaintenance } from '../lib/maintenance_actions.js';

async function process(sock, messageInfo) {
  const { remoteJid, message, command, sender, prefix } = messageInfo;
  const maintenance = await getMaintenance();

  if (maintenance.active && isExpired(maintenance)) {
    await finishMaintenance(sock, maintenance);
    return true;
  }

  if (!maintenance.active) return true;

  const owner = isOwner(sender);
  const allowedCommands = ['maintenance', 'unmaintenance', 'cekmaintenance'];
  if (owner && allowedCommands.includes(command)) return true;

  if (!owner) {
    if (prefix && command) {
      await sock.sendMessage(remoteJid, { text: buildMaintenanceText(maintenance) }, { quoted: message });
    }
    return false;
  }

  return false;
}

export default {
  name: 'Maintenance Handler',
  priority: 0,
  process,
};
