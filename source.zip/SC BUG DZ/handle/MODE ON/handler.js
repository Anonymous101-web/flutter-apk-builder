import fs from"fs";import path from"path";import{findGroup}from"../../lib/group.js";import{containsBadword}from"../../lib/badword.js";import mess from"../../strings.js";import spamDetection from"../../lib/spamDetection.js";import badwordDetection from"../../lib/badwordDetection.js";import config from"../../config.js";import{updateUser,findUser}from"../../lib/users.js";import autoAi from"../../lib/autoai.js";import autoSimi from"../../lib/autosimi.js";import autoRusuh from"../../lib/autorusuh.js";import{getGroupMetadata,findParticipantLatest}from"../../lib/cache.js";import{logWithTime,isUrlInText,toText,sendMessageWithMention,sendMessageWithMentionNotQuoted,logTracking,}from"../../lib/utils.js";import{findMessageById,editMessageById}from"../../lib/chatManager.js";import{sendImageAsSticker}from"../../lib/exif.js";const notifiedUsers=new Set();const rateLimit_blacklist={};const notifiedBlacklistUsers=new Set();const delay=(ms)=>new Promise((resolve)=>setTimeout(resolve,ms));const botNumber=config.phone_number_bot;const antiLinkV3Counter=(()=>{const warnings={};const MAX=3;return(groupId,sender,platformKey)=>{if(!warnings[groupId])warnings[groupId]={};if(!warnings[groupId][sender])warnings[groupId][sender]={};if(!warnings[groupId][sender][platformKey])warnings[groupId][sender][platformKey]=0;warnings[groupId][sender][platformKey]+=1;const total=warnings[groupId][sender][platformKey];if(total>=MAX){warnings[groupId][sender][platformKey]=0;return{status:"kick",totalWarnings:MAX};}return{status:"warning",totalWarnings:total};};})();const antiPollingV3Counter=(()=>{const warnings={};const MAX=3;return(groupId,sender)=>{if(!warnings[groupId])warnings[groupId]={};if(!warnings[groupId][sender])warnings[groupId][sender]=0;warnings[groupId][sender]+=1;const total=warnings[groupId][sender];if(total>=MAX){warnings[groupId][sender]=0;return{status:"kick",totalWarnings:MAX};}return{status:"warning",totalWarnings:total};};})();async function process(sock,messageInfo){const{m,id,sender,isBot,pushName,message,isGroup,prefix,command,content,fullText,type,isQuoted,isTagSw,isSwgc,isTagMeta,isForwarded,isTagComunity,mentionedJid,senderType,isPoll,isForwardedPoll,}=messageInfo;let{remoteJid}=messageInfo;const result=findParticipantLatest(sender);
 // Tag status kadang masuk via status@broadcast (remoteJid bukan grup).
  // Jangan override remoteJid kalau sudah @g.us agar tidak salah target.
  if(result && (isTagSw||isSwgc) && !String(remoteJid).endsWith("@g.us")){
    remoteJid=result.groupId;
  }
const messagesDefault=toText(message);if(isTagSw||isSwgc||String(remoteJid).endsWith("@g.us")){}else{return true;}
const now=Date.now();if(!String(remoteJid).endsWith("@g.us"))return true;try{const dataGroupSettings=await findGroup(remoteJid);if(!dataGroupSettings){logWithTime("System",`Data grup tidak ditemukan atau fitur belum diaktifkan.`);return true;}
const{fitur}=dataGroupSettings;const groupMetadata=await getGroupMetadata(sock,remoteJid);const participants=Array.isArray(groupMetadata?.participants)?groupMetadata.participants:[];const isAdmin=participants.some((p)=>(p.phoneNumber===sender||p.id===sender)&&p.admin);

// NOTE:
// Pesan SWGC/Group Status kadang tidak menyertakan `key.participant`.
// Kalau participant kosong, fitur delete (admin) sering gagal.
// Jadi kita selalu bangun deleteKey manual yang lengkap.
const deleteMessage=async()=>{logTracking(`Menghapus pesan di grub (${command})`);const key=message?.key||m?.key||{};const base={remoteJid:remoteJid,fromMe:false,id:key.id||id,};const participantDel=key.participant||key.participantAlt||m?.key?.participant||message?.participant||sender;try{await sock.sendMessage(remoteJid,{delete:{...base,participant:participantDel}});}catch(e){try{await sock.sendMessage(remoteJid,{delete:base});}catch(e2){console.error('Gagal hapus pesan:',e2?.message||e2);}}};

const kickParticipant=async()=>{logTracking(`Kick peserta dari grub (${command})`);try{await sock.groupParticipantsUpdate(remoteJid,[sender],'remove');}catch(e){console.error('Gagal kick peserta:',e?.message||e);}};const sendText=async(text,isquoted=false)=>{logTracking(`Handler - mengirim pesan teks (${command})`);if(isquoted){await sendMessageWithMentionNotQuoted(sock,remoteJid,text,senderType);}else{await sock.sendMessage(remoteJid,{text},{quoted:message});}};async function handleAction(action,sender){if(action==="block"){await updateUser(sender,{status:"block"});}else if(action==="kick"){await kickParticipant();}else if(action==="both"){await updateUser(sender,{status:"block"});await kickParticipant();}else{console.warn("Tindakan badword tidak valid:",action);}}
const user=await findUser(sender);
const lowerText=String(fullText||"").toLowerCase().trim();
const isWhatsappLink=lowerText.includes("chat.whatsapp.com");
const isWhatsappSaluran=lowerText.includes("whatsapp.com/channel/");

// Anti-link spesifik platform
const isYouTubeLink=/(?:https?:\/\/)?(?:www\.)?(?:m\.)?(?:youtube\.com|youtu\.be)\b/i.test(fullText||"");
const isTikTokLink=/(?:https?:\/\/)?(?:www\.)?(?:vt\.|vm\.)?tiktok\.com\b/i.test(fullText||"");
const isInstagramLink=/(?:https?:\/\/)?(?:www\.)?(?:instagram\.com|instagr\.am)\b/i.test(fullText||"");

// Anti kata (UNCHEK)
// - antiunchek     : warn + hapus
// - antiunchekv2   : warn + hapus + kick
// - antiunchekv3   : warn 3x -> kick (pesan tetap dihapus)
const isUnchekWord=/(^|[^a-z0-9])unchek([^a-z0-9]|$)/i.test(lowerText);

// Anti-link warning helper
const tagUser=`@${sender.split("@")[0]}`;
const sendAntiLinkWarn=async(platform)=>{
  const platformUpper=String(platform||"LINK").toUpperCase();
  const warning=`⚠️ ${tagUser} TERDETEKSI MENGIRIM *LINK ${platformUpper}* DI GB INI!\n🚫 LINK DILARANG — PESAN AKAN DIHAPUS.`;
  await sendText(warning,true);
};
const sendAntiLinkWarnKick=async(platform)=>{
  const platformUpper=String(platform||"LINK").toUpperCase();
  const warning=`⚠️ ${tagUser} TERDETEKSI MENGIRIM *LINK ${platformUpper}* DI GB INI!\n🚫 LINK DILARANG — PESAN AKAN DIHAPUS DAN KAMU AKAN DIKELUARKAN.`;
  await sendText(warning,true);
};

// Deteksi SWGC lebih robust (beberapa fork baileys pakai key `groupStatusMessage*` lain)
const isSwgcMsg=(typeof isSwgc==="boolean")?isSwgc:(()=>{const mm=message?.message||{};if(mm.groupStatusMessageV2||mm.groupStatusMessage)return true;return Object.keys(mm).some((k)=>/^groupStatusMessage/i.test(k));})();
const isFromMeMsg=Boolean((message?.key||m?.key)?.fromMe);
if(!isFromMeMsg&&!isAdmin&&fitur?.antiswgc2&&isSwgcMsg){logWithTime("SYSTEM",`Deteksi fitur Anti-SWGC2`);const warningMessage=mess?.handler?.antiswgc||"⚠️ @sender _Terdeteksi SWGC/Status Group di grub ini_.";await sendText(warningMessage.replace("@sender",`@${sender.split("@")[0]}`),true);await deleteMessage();await kickParticipant();return false;}
if(!isFromMeMsg&&!isAdmin&&fitur?.antiswgc&&isSwgcMsg){logWithTime("SYSTEM",`Deteksi fitur Anti-SWGC`);const warningMessage=mess?.handler?.antiswgc||"⚠️ @sender _Terdeteksi SWGC/Status Group di grub ini_.";await sendText(warningMessage.replace("@sender",`@${sender.split("@")[0]}`),true);await deleteMessage();return false;}

// Anti Tag Status (Status Mention ke Grup)
// WhatsApp sekarang bisa "tag/mention" grup di Status, dan grup akan dapat notifikasi.
// Fitur ini menghapus notifikasi tersebut (dan opsional kick).
const safeTagUser=(()=>{
  try{
    if(!sender||typeof sender!=="string")return"@user";
    if(sender.endsWith("@g.us"))return"@user";
    return`@${sender.split("@")[0]}`;
  }catch{return"@user";}
})();
const isGroupTarget=String(remoteJid||"").endsWith("@g.us");
if(isGroupTarget&&!isFromMeMsg&&!isAdmin&&isTagSw){
  const warningMessage=mess?.handler?.antitagsw||"📣 @sender _Tag Status (SW) ke grup terdeteksi._";
  if(fitur?.antitagsw2){
    logWithTime("SYSTEM",`Deteksi fitur Anti-TagStatus2`);
    await sendText(warningMessage.replace("@sender",safeTagUser),true);
    await deleteMessage();
    await kickParticipant();
    return false;
  }
  if(fitur?.antitagsw){
    logWithTime("SYSTEM",`Deteksi fitur Anti-TagStatus`);
    await sendText(warningMessage.replace("@sender",safeTagUser),true);
    await deleteMessage();
    return false;
  }
}
const detectPollPayload=(raw)=>{if(!raw||typeof raw!=="object")return false;const scan=(value,depth=0,seen=new Set())=>{if(!value||typeof value!=="object")return false;if(seen.has(value)||depth>10)return false;seen.add(value);if(Array.isArray(value))return value.some((item)=>scan(item,depth+1,seen));for(const [k,v]of Object.entries(value)){if(/^pollCreationMessage(?:V\d+)?$/i.test(String(k||"")))return true;if(scan(v,depth+1,seen))return true;}return false;};return scan(raw);};
const isPollMessage=Boolean(isPoll||type==="poll"||detectPollPayload(message?.message));
const sendAntiPollingWarn=async({mode="warn",count=1,isForwardedPoll=false}={})=>{const pollLabel=isForwardedPoll?"POLLING FORWARD":"POLLING";if(mode==="kick"){await sendText(`⚠️ ${tagUser} TERDETEKSI MENGIRIM *${pollLabel}* DI GB INI!\n🚫 POLLING DILARANG — PESAN AKAN DIHAPUS DAN KAMU AKAN DIKELUARKAN.`,true);return;}if(mode==="v3"){await sendText(`⚠️ ${tagUser} TERDETEKSI MENGIRIM *${pollLabel}* DI GB INI!\n🚫 POLLING DILARANG — PESAN AKAN DIHAPUS.\n📌 PERINGATAN: *${count}/3*`,true);return;}await sendText(`⚠️ ${tagUser} TERDETEKSI MENGIRIM *${pollLabel}* DI GB INI!\n🚫 POLLING DILARANG — PESAN AKAN DIHAPUS.`,true);};
const runAntiPolling=async()=>{if(isFromMeMsg||isAdmin||!isPollMessage)return false;const forwardedMode=Boolean(isForwardedPoll||isForwarded);if(fitur?.antipollingv2){logWithTime("SYSTEM",`Deteksi fitur antipollingv2${forwardedMode?" (forward)":""}`);await sendAntiPollingWarn({mode:"kick",isForwardedPoll:forwardedMode});await deleteMessage();await kickParticipant();return true;}if(fitur?.antipollingv3){logWithTime("SYSTEM",`Deteksi fitur antipollingv3${forwardedMode?" (forward)":""}`);const res=antiPollingV3Counter(remoteJid,sender);if(res.status==="warning"){await sendAntiPollingWarn({mode:"v3",count:res.totalWarnings,isForwardedPoll:forwardedMode});await deleteMessage();return true;}await sendText(`⚠️ ${tagUser} TERDETEKSI MENGIRIM *${forwardedMode?"POLLING FORWARD":"POLLING"}* DI GB INI!\n🚫 POLLING DILARANG — PESAN AKAN DIHAPUS.\n📌 PERINGATAN: *3/3*\n⛔ Batas maksimal tercapai, kamu akan dikeluarkan.`,true);await deleteMessage();await kickParticipant();return true;}if(fitur?.antipolling){logWithTime("SYSTEM",`Deteksi fitur antipolling${forwardedMode?" (forward)":""}`);await sendAntiPollingWarn({mode:"warn",isForwardedPoll:forwardedMode});await deleteMessage();return true;}return false;};
// AntiLink (Warn / V2 / V3)
const runAntiLink=async({platformName,isMatch,warnKey,v2Key,v3Key})=>{
  if(!isMatch||isFromMeMsg||isAdmin)return false;
  const platformUpper=String(platformName||"LINK").toUpperCase();
  if(fitur?.[v2Key]){logWithTime("SYSTEM",`Deteksi fitur ${v2Key} : ${fullText}`);await sendAntiLinkWarnKick(platformName);await deleteMessage();await kickParticipant();return true;}
  if(fitur?.[v3Key]){logWithTime("SYSTEM",`Deteksi fitur ${v3Key} : ${fullText}`);const res=antiLinkV3Counter(remoteJid,sender,warnKey);if(res.status==="warning"){const warning=`⚠️ ${tagUser} TERDETEKSI MENGIRIM *LINK ${platformUpper}* DI GB INI!\n🚫 LINK DILARANG — PESAN AKAN DIHAPUS.\n📌 PERINGATAN: *${res.totalWarnings}/3*`;await sendText(warning,true);await deleteMessage();return true;}if(res.status==="kick"){const warning=`⚠️ ${tagUser} TERDETEKSI MENGIRIM *LINK ${platformUpper}* DI GB INI!\n🚫 LINK DILARANG — PESAN AKAN DIHAPUS.\n📌 PERINGATAN: *3/3*\n⛔ Batas maksimal tercapai, kamu akan dikeluarkan.`;await sendText(warning,true);await deleteMessage();await kickParticipant();return true;}}
  if(fitur?.[warnKey]){logWithTime("SYSTEM",`Deteksi fitur ${warnKey} : ${fullText}`);await sendAntiLinkWarn(platformName);await deleteMessage();return true;}
  return false;
};
if(await runAntiLink({platformName:"YouTube",isMatch:isYouTubeLink,warnKey:"antilinkyoutube",v2Key:"antilinkyoutubev2",v3Key:"antilinkyoutubev3"}))return false;
if(await runAntiLink({platformName:"TikTok",isMatch:isTikTokLink,warnKey:"antilinktiktok",v2Key:"antilinktiktokv2",v3Key:"antilinktiktokv3"}))return false;
if(await runAntiLink({platformName:"Instagram",isMatch:isInstagramLink,warnKey:"antilinkinstagram",v2Key:"antilinkinstagramv2",v3Key:"antilinkinstagramv3"}))return false;
if(await runAntiLink({platformName:"Channel WhatsApp",isMatch:isWhatsappSaluran,warnKey:"antilinkch",v2Key:"antilinkchv2",v3Key:"antilinkchv3"}))return false;
if(await runAntiLink({platformName:"Grup WhatsApp",isMatch:isWhatsappLink,warnKey:"antilinkwa",v2Key:"antilinkwav2",v3Key:"antilinkwav3"}))return false;

// Anti kata UNCHEK (peringatan seperti antilink)
const sendAntiUnchekWarn=async()=>{
  const warning=`⚠️ ${tagUser} TERDETEKSI MENGIRIM *KATA TERLARANG UNCHEK* DI GB INI!\n🚫 KATA TERSEBUT DILARANG — PESAN AKAN DIHAPUS.`;
  await sendText(warning,true);
};
const sendAntiUnchekWarnKick=async()=>{
  const warning=`⚠️ ${tagUser} TERDETEKSI MENGIRIM *KATA TERLARANG UNCHEK* DI GB INI!\n🚫 KATA TERSEBUT DILARANG — PESAN AKAN DIHAPUS DAN KAMU AKAN DIKELUARKAN.`;
  await sendText(warning,true);
};

const runAntiUnchek=async()=>{
  if(!isUnchekWord||isFromMeMsg||isAdmin)return false;
  if(fitur?.antiunchekv2){
    logWithTime("SYSTEM",`Deteksi fitur antiunchekv2 : ${fullText}`);
    await sendAntiUnchekWarnKick();
    await deleteMessage();
    await kickParticipant();
    return true;
  }
  if(fitur?.antiunchekv3){
    logWithTime("SYSTEM",`Deteksi fitur antiunchekv3 : ${fullText}`);
    const res=antiLinkV3Counter(remoteJid,sender,"antiunchek");
    if(res.status==="warning"){
      const warning=`⚠️ ${tagUser} TERDETEKSI MENGIRIM *KATA TERLARANG UNCHEK* DI GB INI!\n🚫 KATA TERSEBUT DILARANG — PESAN AKAN DIHAPUS.\n📌 PERINGATAN: *${res.totalWarnings}/3*`;
      await sendText(warning,true);
      await deleteMessage();
      return true;
    }
    if(res.status==="kick"){
      const warning=`⚠️ ${tagUser} TERDETEKSI MENGIRIM *KATA TERLARANG UNCHEK* DI GB INI!\n🚫 KATA TERSEBUT DILARANG — PESAN AKAN DIHAPUS.\n📌 PERINGATAN: *3/3*\n⛔ Batas maksimal tercapai, kamu akan dikeluarkan.`;
      await sendText(warning,true);
      await deleteMessage();
      await kickParticipant();
      return true;
    }
  }
  if(fitur?.antiunchek){
    logWithTime("SYSTEM",`Deteksi fitur antiunchek : ${fullText}`);
    await sendAntiUnchekWarn();
    await deleteMessage();
    return true;
  }
  return false;
};
if(await runAntiUnchek())return false;

if(!isAdmin&&fitur.antihidetag2&&mentionedJid.length>0){logWithTime("SYSTEM",`Deteksi fitur antihidetagv2`);const hidden=!mentionedJid.some((jid)=>{const number=jid.split("@")[0];return fullText.includes(number);});if(hidden){await deleteMessage();await kickParticipant();return false;}}
if(!isAdmin&&fitur.antihidetag&&mentionedJid.length>0){logWithTime("SYSTEM",`Deteksi fitur antihidetag`);const hidden=!mentionedJid.some((jid)=>{const number=jid.split("@")[0];return fullText.includes(number);});if(hidden){await deleteMessage();return false;}}
if(fitur.detectblacklist2&&user){logWithTime("SYSTEM",`Deteksi fitur Detect Blacklist`);if(user){const[docId,userData]=user;const status=userData.status;if(status==="blacklist"){await kickParticipant();}}}
if(fitur.detectblacklist&&user){logWithTime("SYSTEM",`Deteksi fitur Detect Blacklist`);if(user){const[docId,userData]=user;const status=userData.status;const userId=sender.split("@")[0];if(status==="blacklist"){if(!notifiedBlacklistUsers.has(userId)){const warningMessage=`⚠️ _Peringatan Blacklist_ \n\n@${userId} Telah di blacklist`;await sendText(warningMessage,true);logWithTime(pushName,`User sedang di blacklist`);notifiedBlacklistUsers.add(userId);}else{logWithTime(pushName,`User blacklist sudah diberi notifikasi sebelumnya`);}
return false;}}}
if(fitur.detectblacklist&&fitur.detectblacklist2){if(user){const[docId,userData]=user;const status=userData.status;if(status==="blacklist"){return false;}}}
if(!isAdmin&&fitur.badwordv3&&command!=="delbadword"){const hasBadwordGroup=await containsBadword(remoteJid,fullText);const hasBadwordGlobal=await containsBadword("global-badword",fullText);if(hasBadwordGroup.status||hasBadwordGlobal.status){logWithTime("SYSTEM",`Deteksi fitur badwordv3`);await deleteMessage();const detectWords=hasBadwordGroup.words||hasBadwordGlobal.words;const result=badwordDetection(sender);if(result.status==="warning"){if(mess.handler.badword_warning){let warningMessage=mess.handler.badword_warning.replace("@sender",`@${sender.split("@")[0]}`).replace("@warning",result.totalWarnings).replace("@detectword",detectWords).replace("@totalwarning",config.BADWORD.warning);await sendText(warningMessage,true);}
return false;}
if(result.status==="blocked"){if(mess.handler.badword_block){let warningMessage=mess.handler.badword_block.replace("@sender",`@${sender.split("@")[0]}`).replace("@warning",result.totalWarnings).replace("@detectword",detectWords).replace("@totalwarning",config.BADWORD.warning);await sendText(warningMessage,true);await kickParticipant();}}}}
if(!isAdmin&&fitur.badword&&command!=="delbadword"){const hasBadwordGroup=await containsBadword(remoteJid,fullText);const hasBadwordGlobal=await containsBadword("global-badword",fullText);if(hasBadwordGroup.status||hasBadwordGlobal.status){const detectWords=hasBadwordGroup.words||hasBadwordGlobal.words;logWithTime("SYSTEM",`Deteksi fitur badword`);await deleteMessage();const result=badwordDetection(sender);if(result.status==="warning"){if(mess.handler.badword_warning){let warningMessage=mess.handler.badword_warning.replace("@sender",`@${sender.split("@")[0]}`).replace("@warning",result.totalWarnings).replace("@detectword",detectWords).replace("@totalwarning",config.BADWORD.warning);await sendText(warningMessage,true);}
return false;}
if(result.status==="blocked"){if(mess.handler.badword_block){let warningMessage=mess.handler.badword_block.replace("@sender",`@${sender.split("@")[0]}`).replace("@warning",result.totalWarnings).replace("@detectword",detectWords).replace("@totalwarning",config.BADWORD.warning);await sendText(warningMessage,true);}
const badwordAction=config.BADWORD.action.toLowerCase().trim();try{if(user){const[docId,userData]=user;await handleAction(badwordAction,sender);}}catch(error){console.error("❗ _Terjadi kesalahan, tindakan badword gagal. Pastikan Bot Adalah admin_");await sendText("❗ _Terjadi kesalahan, tindakan badword gagal. Pastikan Bot Adalah admin_");}}
return false;}}
if(!isAdmin&&fitur.badwordv2&&command!=="delbadword"){const hasBadwordGroup=await containsBadword(remoteJid,fullText);const hasBadwordGlobal=await containsBadword("global-badword",fullText);if(hasBadwordGroup.status||hasBadwordGlobal.status){logWithTime("SYSTEM",`Deteksi fitur badwordv2`);await deleteMessage();const detectWords=hasBadwordGroup.words||hasBadwordGlobal.words;const result=badwordDetection(sender);if(mess.handler.badword_block){let warningMessage=mess.handler.badword_block.replace("@sender",`@${sender.split("@")[0]}`).replace("@warning",result.totalWarnings).replace("@detectword",detectWords).replace("@totalwarning",config.BADWORD.warning);await sendText(warningMessage,true);}
const badwordAction=config.BADWORD.action.toLowerCase().trim();try{if(user){const[docId,userData]=user;await handleAction(badwordAction,sender);}}catch(error){console.error("❗ _Terjadi kesalahan, tindakan badword gagal. Pastikan Bot Adalah admin_");await sendText("❗ _Terjadi kesalahan, tindakan badword gagal. Pastikan Bot Adalah admin_");}
return false;}}
if(fitur.antigame&&command){const Games=["bj","blackjack","caklontong","kodam","cekkodam","snakes","dare","family100","kuismath","math","suit","tebakangka","tebakbendera","tebakbom","tebakgambar","tebakhewan","tebakkalimat","tebakkata","tebaklagu","tebak","tebaklirik","tictactoe","truth","ttc","ttt",];if(Games.some((game)=>command.includes(game))){const notifKey=`antigame-${remoteJid}-${sender}`;if(!notifiedUsers.has(notifKey)){notifiedUsers.add(notifKey);await sendText(mess.game.isStop);}
return false;}}
if(await runAntiPolling())return false;const antiFeatures={image:fitur.antifoto,video:fitur.antivideo,audio:fitur.antiaudio,document:fitur.antidocument,contact:fitur.antikontak,sticker:fitur.antisticker,};if(!isAdmin&&antiFeatures[type]){logWithTime("SYSTEM",`Deteksi fitur - ${type}`);await deleteMessage();return false;}
if(fitur.antiedit&&m.isEdited.status){const fullText=m.isEdited.text;const idChatEdited=m.isEdited.id;if(idChatEdited){const oldMessage=findMessageById(sender,idChatEdited);if(oldMessage){if(mess.handler.antiedit){let warningMessage=mess.handler.antiedit.replace("@oldMessage",`${oldMessage.text || ""}`);await sendText(warningMessage,true);}
if(fullText){editMessageById(sender,idChatEdited,fullText);return false;}}}}
if(fitur.antidelete&&m.isDeleted){const idChatDeleted=m.message.message?.protocolMessage?.key?.id;if(idChatDeleted){const oldMessage=findMessageById(sender,idChatDeleted);if(oldMessage){if(oldMessage.type&&oldMessage.type=="sticker"){try{const outputPath=path.resolve("./",oldMessage.text);const stickerBuffer=fs.readFileSync(outputPath);const options={packname:config.sticker_packname,author:config.sticker_author,};await sendImageAsSticker(sock,remoteJid,stickerBuffer,options,message);if(mess.handler.antidelete){let warningMessage=mess.handler.antidelete.replace("@sender",`@${sender.split("@")[0]}`).replace("@text","sticker");await sendText(warningMessage,true);}}catch(error){console.error("Error:",error);}
return;}
if(mess.handler.antidelete){let warningMessage=mess.handler.antidelete.replace("@sender",`@${sender.split("@")[0]}`).replace("@text",`${oldMessage.text || ""}`);await sendText(warningMessage,true);}}}}
if(!isAdmin&&typeof fitur.antispamchat==="boolean"&&fitur.antispamchat){const result=spamDetection(sender);if(result.status==="warning"){if(mess.handler.antispamchat){let warningMessage=mess.handler.antispamchat.replace("@sender",`@${sender.split("@")[0]}`).replace("@warning",result.totalWarnings).replace("@totalwarning",config.SPAM.warning);try{await sendText(warningMessage,true);}catch(err){console.error("Gagal kirim pesan warning:",err);}}
return false;}
if(result.status==="blocked"){if(mess.handler.antispamchat2){let warningMessage=mess.handler.antispamchat2.replace("@sender",`@${sender.split("@")[0]}`);await sendText(warningMessage,true);}
const spamAction=config.SPAM.action.toLowerCase().trim();try{if(user){const[docId,userData]=user;await handleAction(spamAction,sender);}}catch(error){console.error("Terjadi kesalahan saat memproses tindakan spam:",error);await sendText("❗ _Terjadi kesalahan, tindakan spam gagal._");}
return false;}}
if(!isAdmin&&fitur?.antivirtex===true){const isTextMessage=type!=="video"&&type!=="image";const isTextTooLong=messagesDefault.length>10000;if(isTextMessage&&isTextTooLong){if(mess.handler.antivirtex){let warningMessage=mess.handler.antivirtex.replace("@sender",`@${sender.split("@")[0]}`);await sendText(warningMessage,true);}
await deleteMessage();return false;}}
if(fitur?.autoai&&command!=="on"&&command!=="off"&&!prefix){const containsAI=fullText.toLowerCase().trim().includes("ai");const isQuotedMessageFromBot=(()=>{if(!isQuoted?.sender)return false;const senderNumber=isQuoted.sender.split("@")[0];return senderNumber===botNumber;})();const content_old=isQuotedMessageFromBot?isQuoted.text||isQuoted.content||"":undefined;if(type==="text"||type==="image"||containsAI){await autoAi(sock,messageInfo,content_old);return false;}}
if(fitur?.autosimi&&command!=="on"&&command!=="off"){const containsSimi=fullText.toLowerCase().trim().includes("simi");const isQuotedMessageFromBot=(()=>{if(!isQuoted?.sender)return false;const senderNumber=isQuoted.sender.split("@")[0];return senderNumber===botNumber;})();const content_old=isQuotedMessageFromBot?isQuoted.text||isQuoted.content||"":undefined;if(type==="text"||containsSimi){await autoSimi(sock,messageInfo,content_old);return false;}}
if(fitur?.autorusuh&&command!=="on"&&command!=="off"){const isQuotedMessageFromBot=(()=>{if(!isQuoted?.sender)return false;const senderNumber=isQuoted.sender.split("@")[0];return senderNumber===botNumber;})();await autoRusuh(sock,messageInfo,isQuotedMessageFromBot);return false;}
if(!isAdmin&&fitur?.antibot&&isBot&&isGroup){if(mess.handler.antibot){let warningMessage=mess.handler.antibot.replace("@sender",`@${sender.split("@")[0]}`);await sendText(warningMessage,true);}
await deleteMessage();await kickParticipant();return false;}
if(fitur?.onlyadmin){if(command==="debug"){console.log(`Status Only Admin: ${fitur.onlyadmin ? "Aktif" : "Nonaktif"}`);return false;}
const normalizedCommand=String(command||"").toLowerCase().trim();
const normalizedContent=String(content||fullText||"").toLowerCase().trim();
const allowedOnlyAdminBypass=["afk","ajuharga","ceklelang","cekwinner","menulelang","helperlelang","helplelang"];
const isAuctionMenuBypass=normalizedCommand==="menu"&&/^lelang(?:\s|$)/.test(normalizedContent);
if(!isAdmin&&!allowedOnlyAdminBypass.includes(normalizedCommand)&&!isAuctionMenuBypass)return false;}


if(fitur?.antitagmeta&&isGroup&&isTagMeta){let warningMessage="⚠️ @sender _Terdeteksi Tag Meta Ai di grub ini_";if(warningMessage){warningMessage=warningMessage.replace("@sender",`@${sender.split("@")[0]}`);await sendText(warningMessage,true);}
await deleteMessage();return false;}
if(fitur?.antitagmeta2&&isGroup&&isTagMeta){let warningMessage="⚠️ @sender _Terdeteksi Tag Meta Ai di grub ini_";if(warningMessage){warningMessage=warningMessage.replace("@sender",`@${sender.split("@")[0]}`);await sendText(warningMessage,true);}
await deleteMessage();await kickParticipant();return false;}
if(!isAdmin&&fitur?.antiforward&&isGroup&&isForwarded){let warningMessage="⚠️ @sender _Terdeteksi Mengirim Pesan Terusan_";if(warningMessage){warningMessage=warningMessage.replace("@sender",`@${sender.split("@")[0]}`);await sendText(warningMessage,true);}
await deleteMessage();return false;}
if(!isAdmin&&fitur?.antiforward2&&isGroup&&isForwarded){let warningMessage="⚠️ @sender _Terdeteksi Mengirim Pesan Terusan_";if(warningMessage){warningMessage=warningMessage.replace("@sender",`@${sender.split("@")[0]}`);await sendText(warningMessage,true);}
await deleteMessage();await kickParticipant();return false;}
if(rateLimit_blacklist[sender]&&now-rateLimit_blacklist[sender]<5000){return true;}else{rateLimit_blacklist[sender]=now;}}catch(error){console.error("Terjadi kesalahan pada proses Handler.js:",error.message);}
return true;}
export default{name:"Mode On Handler :",priority:2,process,};
