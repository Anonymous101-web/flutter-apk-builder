import { maybeSendOwnerWelcome } from "../lib/sambutanowner.js";

async function process(sock, messageInfo) {
  await maybeSendOwnerWelcome(sock, messageInfo);
  return true;
}

export default {
  name: "Owner Welcome",
  priority: -999,
  process,
};
