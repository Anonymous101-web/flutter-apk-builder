import fs from "fs";
import path from "path";
import config from "../config.js";
import { getGreeting } from "../lib/utils.js";

// Auto message saat ada chat pribadi pertama kali.
// Konfigurasi: database/automsg_firstchat.json
// Riwayat sender yang sudah pernah dikirimi: database/automsg_firstchat_sent.json

const respondedSenders = new Set();
const CFG_FILE = path.join(process.cwd(), "database", "automsg_firstchat.json");
const SENT_FILE = path.join(process.cwd(), "database", "automsg_firstchat_sent.json");

function safeJsonParse(str, fallback) {
  try {
    const v = JSON.parse(str);
    return v && typeof v === "object" ? v : fallback;
  } catch {
    return fallback;
  }
}

function ensureDir() {
  try {
    fs.mkdirSync(path.dirname(CFG_FILE), { recursive: true });
  } catch {}
}

function defaultCfg() {
  return {
    enabled: true,
    // Kalau true, automsg ikut aturan .groupmod / .privatemod / .bothmod
    // - Jika bot_destination = "group" → automsg tidak akan membalas chat private
    respect_destination: true,
    // Kalau true, tiap sender hanya dikirimi 1x (persist ke file)
    once_per_sender: true,
    template:
      "🌟 _*Pesan Otomatis*_ 🌟\n\n" +
      "👋 _{greeting}_ Kak *{pushName}*, nomor ini adalah nomor bot yang tersedia untuk disewa di sebuah grub.\n\n" +
      "⚠️ Kami sangat melarang jika bot digunakan untuk tindak penipuan atau kegiatan ilegal lainnya.\n\n" +
      "_*Informasi lebih lanjut*_\n" +
      "📞 Owner : https://wa.me/6285246154386?text=sewabot+4.0\n" +
      "💻 Website : https://WorldMD\n" +
      "👉 Saluran : https://www.whatsapp.com/channel/0029VaDSRuf05MUekJbazP1D",
  };
}

function loadCfg() {
  ensureDir();
  try {
    if (!fs.existsSync(CFG_FILE)) {
      const init = defaultCfg();
      fs.writeFileSync(CFG_FILE, JSON.stringify(init, null, 2));
      return init;
    }
    const raw = fs.readFileSync(CFG_FILE, "utf8");
    const cfg = safeJsonParse(raw, defaultCfg());
    return { ...defaultCfg(), ...cfg };
  } catch {
    return defaultCfg();
  }
}

function loadSent() {
  ensureDir();
  try {
    if (!fs.existsSync(SENT_FILE)) {
      fs.writeFileSync(SENT_FILE, JSON.stringify({}, null, 2));
      return {};
    }
    const raw = fs.readFileSync(SENT_FILE, "utf8");
    const data = safeJsonParse(raw, {});
    return data && typeof data === "object" ? data : {};
  } catch {
    return {};
  }
}

function saveSent(sent) {
  try {
    ensureDir();
    const tmp = SENT_FILE + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(sent, null, 2));
    fs.renameSync(tmp, SENT_FILE);
  } catch {}
}

function renderTemplate(tpl, vars) {
  let out = String(tpl || "");
  for (const [k, v] of Object.entries(vars || {})) {
    out = out.replaceAll(`{${k}}`, String(v ?? ""));
  }
  return out;
}

async function process(sock, messageInfo) {
  const { sender, remoteJid, isGroup, message, pushName, fullText, type } =
    messageInfo;

  // hanya untuk chat pribadi (bukan grup / status)
  if (isGroup) return true;
  if (remoteJid === "status@broadcast") return true;
  if (!sender) return true;

  const cfg = loadCfg();
  if (!cfg.enabled) return true;

  // Ikuti setting .groupmod / .privatemod / .bothmod
  const dest = String(config?.bot_destination || "both").toLowerCase();
  if (cfg.respect_destination && dest === "group") return true;

  // Abaikan pesan kosong total (mis. event system)
  const hasAnyContent = Boolean((fullText && String(fullText).trim()) || type);
  if (!hasAnyContent) return true;

  // Skip beberapa keyword game (biar ga ganggu)
  if (
    fullText &&
    ["batu", "kertas", "gunting"].includes(String(fullText).toLowerCase())
  )
    return true;

  // Once per sender (persist)
  let sentCache = null;
  if (cfg.once_per_sender) {
    if (respondedSenders.has(sender)) return true;
    sentCache = loadSent();
    if (sentCache?.[sender]) return true;

    // set dulu untuk mencegah double-send jika user spam cepat
    respondedSenders.add(sender);
  }

  const salam = getGreeting();
  const response = renderTemplate(cfg.template, {
    greeting: salam,
    pushName: pushName || "Kak",
  });

  try {
    await sock.sendMessage(sender, { text: response }, { quoted: message });

    if (cfg.once_per_sender) {
      const sent = sentCache || loadSent();
      sent[sender] = new Date().toISOString();
      saveSent(sent);
    }
  } catch (error) {
    if (cfg.once_per_sender) respondedSenders.delete(sender);
    console.error("Error in first chat process:", error);
  }

  return true;
}

export default {
  name: "First Chat",
  priority: 10,
  process,
};
