// CONNECTION BOT GAUSAH DI OTAK ATIK
const CONNECTION = "pairing"; // gausah di edit

// SETTINGS NOMER OWNER / BOT
const OWNER_NAME = "World Market"; // ganti nama lu
////////////////////////////////////////////////////
const NOMOR_BOT = "628xxx"; // 628xx nomor wa buat BOT
const DATA_OWNER = ["628xxx", "628xxx"]; // nomer wa buat owner harus sama dua dua nya sama juga

// WORLD INFORMATION GAUSAH DI EDIT KALO GAMAU EROR
const EMAIL = "world@gmail.com"; // JANGAN EDIT
const REGION = "Indonesia"; // JANGAN EDIT
const WEBSITE = ""; // JANGAN EDIT

// PRODUCTION SETTING JANGAN DI UBAH
const DESTINATION = "both"; // jangan di ubah
const RATE_LIMIT = 3000; // 3 detik/chat
const SIMILARITY = true; // Pencarian kemiripan command (true, false)
const MODE = "production"; // [production, development]
const VERSION = global.version; // don't edit

// PANEL SETTINGS
const PANEL_URL = "";
const PANEL_PLTA = "";
const PANEL_DESCRIPTION = "Butuh Bantuan Hubungi 628xxxxx";
const PANEL_ID_EGG = 15;
const PANEL_ID_LOCATION = 1;
const PANEL_DEFAULT_DISK = 5120; // 5GB atau 0 (unlimited)
const PANEL_DEFAULT_CPU = 90;
const STATUS_SCHEDULED = true;

////////////////////////////////////////////////////////////////////////
const LOGS_GROUP_LINK =
  "https://chat.whatsapp.com/FvsCbAFjvJ8Amoy38P31oa?mode=gi_t"; // JANGAN EDIT

import { APIKEY } from "\x2e\x2flib\x2fconnection\x2f\x2ekeys\x2fapikey\x2ejs";

function _0x2757(_0x4bba07, _0x3391f6) {
  const _0x1aeb9d = _0x3870();
  return (
    (_0x2757 = function (_0x371134, _0x33200e) {
      _0x371134 = _0x371134 - 0xc1;
      let _0x387060 = _0x1aeb9d[_0x371134];
      if (_0x2757["mYwkjI"] === undefined) {
        var _0x2757de = function (_0x4f905f) {
          const _0x2cec71 =
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
          let _0xd6ba4 = "",
            _0x38da24 = "",
            _0x557b5c = _0xd6ba4 + _0x2757de;
          for (
            let _0xce0490 = 0x0, _0x418fc5, _0x1c3b4c, _0x534eb9 = 0x0;
            (_0x1c3b4c = _0x4f905f["charAt"](_0x534eb9++));
            ~_0x1c3b4c &&
            ((_0x418fc5 =
              _0xce0490 % 0x4 ? _0x418fc5 * 0x40 + _0x1c3b4c : _0x1c3b4c),
            _0xce0490++ % 0x4)
              ? (_0xd6ba4 +=
                  _0x557b5c["charCodeAt"](_0x534eb9 + 0xa) - 0xa !== 0x0
                    ? String["fromCharCode"](
                        0xff & (_0x418fc5 >> ((-0x2 * _0xce0490) & 0x6)),
                      )
                    : _0xce0490)
              : 0x0
          ) {
            _0x1c3b4c = _0x2cec71["indexOf"](_0x1c3b4c);
          }
          for (
            let _0x5907c8 = 0x0, _0x2629da = _0xd6ba4["length"];
            _0x5907c8 < _0x2629da;
            _0x5907c8++
          ) {
            _0x38da24 +=
              "%" +
              ("00" + _0xd6ba4["charCodeAt"](_0x5907c8)["toString"](0x10))[
                "slice"
              ](-0x2);
          }
          return decodeURIComponent(_0x38da24);
        };
        ((_0x2757["PSeLdA"] = _0x2757de),
          (_0x4bba07 = arguments),
          (_0x2757["mYwkjI"] = !![]));
      }
      const _0x54ab8a = _0x1aeb9d[0x0],
        _0x22734d = _0x371134 + _0x54ab8a,
        _0x2a1300 = _0x4bba07[_0x22734d];
      if (!_0x2a1300) {
        const _0x526bb2 = function (_0x29b4f4) {
          ((this["eftNhS"] = _0x29b4f4),
            (this["cclNex"] = [0x1, 0x0, 0x0]),
            (this["BhaGiv"] = function () {
              return "newState";
            }),
            (this["PxGvbH"] = "\x5cw+\x20*\x5c(\x5c)\x20*{\x5cw+\x20*"),
            (this["iHzIHw"] = "[\x27|\x22].+[\x27|\x22];?\x20*}"));
        };
        ((_0x526bb2["prototype"]["oqclXD"] = function () {
          const _0x35fea8 = new RegExp(this["PxGvbH"] + this["iHzIHw"]),
            _0x14f0b6 = _0x35fea8["test"](this["BhaGiv"]["toString"]())
              ? --this["cclNex"][0x1]
              : --this["cclNex"][0x0];
          return this["hlyeUx"](_0x14f0b6);
        }),
          (_0x526bb2["prototype"]["hlyeUx"] = function (_0x56e480) {
            if (!Boolean(~_0x56e480)) return _0x56e480;
            return this["LLsFiS"](this["eftNhS"]);
          }),
          (_0x526bb2["prototype"]["LLsFiS"] = function (_0x539e5c) {
            for (
              let _0x1040ab = 0x0, _0x4328b5 = this["cclNex"]["length"];
              _0x1040ab < _0x4328b5;
              _0x1040ab++
            ) {
              (this["cclNex"]["push"](Math["round"](Math["random"]())),
                (_0x4328b5 = this["cclNex"]["length"]));
            }
            return _0x539e5c(this["cclNex"][0x0]);
          }),
          new _0x526bb2(_0x2757)["oqclXD"](),
          (_0x387060 = _0x2757["PSeLdA"](_0x387060)),
          (_0x4bba07[_0x22734d] = _0x387060));
      } else _0x387060 = _0x2a1300;
      return _0x387060;
    }),
    _0x2757(_0x4bba07, _0x3391f6)
  );
}
function _0x3870() {
  const _0x15f4e8 = [
    "BhLWANa",
    "mtmZofb5sLfPwq",
    "mte5ndm1ogHuDevHAW",
    "y3DK",
    "nZC5nvbYCeTisW",
    "mZm4ogvZCgrOCW",
    "Dg9tDhjPBMC",
    "zxHPC3rZu3LUyW",
    "ntGWm1HIC1nnAG",
    "D3jPDgvgAwXLu3LUyW",
    "cLnLDgvSywGGzgLPC2KSigPHBgfUA2fUihvSyw5NigjVDc4k",
    "rgf0ztOG",
    "zgf0ywjHC2u",
    "nduWntq5mgDuB3DwBa",
    "AM9PBG",
    "zxHPDa",
    "mIKGr3jVDxaGsKLeoIaXmJaZEhH4EhH4EhH4EhH4EhHazY51CWO",
    "cKLZAsbZywXHAcbZyxr1igzVCM1HDcbIzxjPA3v0oGO",
    "zxjYB3i",
    "qvj3uuy",
    "zM9YBwf0",
    "cHTBmZfT4P2mienptKzjrYbfuLjpuHTBmg06ieXpr1nFr1jpvvbFteLosYbKAsbJB25MAwCUANmGyMvSDw0GzgLPC2KGlYbMB3jTyxqGC2fSywGUcG",
    "DgvZDa",
    "mYKGsuqGz3j1CcaOyw5NA2eGC2fQysK6ideYmdn4EhH4EhH4EhH4EhH4EaO",
    "DhjPBq",
    "reqVtu0VwvK",
    "mtu4mdCZow9VtgrAyG",
    "Ahr0Chm6lY9HCgKUyxv0B3jLC2jVDc5JB20VyxbPl21HA2vYl2jNlwrLzMf1Bhq",
    "mZu4ndbMrMnIvMK",
    "cKTPBMC6ifDVCMXKie1HCMTLDcakt3DUzxi6ida4otuTndi5mI00mtC5oa",
    "C2vHCMnO",
    "qxnPys9kywTHCNrH",
    "kcGOlISPkYKRksSK",
    "CMvHzezPBgvtEw5J",
    "zw5HyMXLza",
    "msKGtgLUAYbPBNzPDguGz3j1CdOGAhr0Chm6lY9JAgf0lNDOyxrZyxbWlMnVBs9ywfHywfHywfHywfGk",
    "ndqXnJqWEeX1BK5R",
    "yxbWBhK",
    "C3rYAw5NAwz5",
    "yM90Aa",
    "ngr2zNrZDG",
    "BfnZsue",
    "mtC4ne1rvfPkwa",
  ];
  _0x3870 = function () {
    return _0x15f4e8;
  };
  return _0x3870();
}
const _0x20bcd2 = _0x2757;
(function (_0x444d71, _0x4f8b20) {
  const _0x3a931c = _0x2757,
    _0x921d84 = _0x444d71();
  while (!![]) {
    try {
      const _0x388a56 =
        -parseInt(_0x3a931c(0xe4)) / 0x1 +
        parseInt(_0x3a931c(0xc2)) / 0x2 +
        (parseInt(_0x3a931c(0xda)) / 0x3) * (-parseInt(_0x3a931c(0xe8)) / 0x4) +
        (parseInt(_0x3a931c(0xc4)) / 0x5) * (parseInt(_0x3a931c(0xc1)) / 0x6) +
        (-parseInt(_0x3a931c(0xc8)) / 0x7) * (parseInt(_0x3a931c(0xea)) / 0x8) +
        -parseInt(_0x3a931c(0xcd)) / 0x9 +
        (-parseInt(_0x3a931c(0xdc)) / 0xa) * (-parseInt(_0x3a931c(0xc5)) / 0xb);
      if (_0x388a56 === _0x4f8b20) break;
      else _0x921d84["push"](_0x921d84["shift"]());
    } catch (_0x544144) {
      _0x921d84["push"](_0x921d84["shift"]());
    }
  }
})(_0x3870, 0x605b6);
import moment from "moment-timezone";
import fs from "fs";
import path from "path";
{
  const raw = String(LOGS_GROUP_LINK || "")[_0x20bcd2(0xd8)](),
    isInvite = /chat\.whatsapp\.com\/([0-9A-Za-z]+)/i[_0x20bcd2(0xd6)](raw),
    isGroupJid = /@g\.us$/i[_0x20bcd2(0xd6)](raw),
    isDigitsOnly = /^\d{10,}$/[_0x20bcd2(0xd6)](raw);
  (!raw || !(isInvite || isGroupJid || isDigitsOnly)) &&
    (console[_0x20bcd2(0xd2)](
      _0x20bcd2(0xd5) +
        _0x20bcd2(0xd1) +
        _0x20bcd2(0xe3) +
        _0x20bcd2(0xd0) +
        _0x20bcd2(0xd7) +
        _0x20bcd2(0xca),
    ),
    process[_0x20bcd2(0xcf)](0x1));
}
const ANTI_CALL = ![],
  AUTO_READ = ![],
  AUTO_BACKUP = ![],
  MIDNIGHT_RESTART = ![],
  PRESENCE_UPDATE = "",
  TYPE_WELCOME = "1",
  BG_WELCOME2 = _0x20bcd2(0xdb),
  BADWORD_WARNING = 0x3,
  BADWORD_ACTION = _0x20bcd2(0xe7),
  SPAM_LIMIT = 0x3,
  SPAM_COULDOWN = 0xa,
  SPAM_WARNING = 0x3,
  SPAM_ACTION = "both";
function loadPrefixModeFromDB() {
  const _0x262ae6 = _0x20bcd2,
    _0x1d6887 = {
      dpGne: _0x262ae6(0xe0),
      lypjp: function (_0x42b2e8, _0x374fa9, _0x32df82) {
        return _0x42b2e8(_0x374fa9, _0x32df82);
      },
      lSsIA: function (_0x510f24) {
        return _0x510f24();
      },
      ARwQF: "utf-8",
    },
    _0x11192d = (function () {
      let _0x1706e3 = !![];
      return function (_0x4ff62f, _0xa2b0a6) {
        const _0x174bab = _0x1706e3
          ? function () {
              const _0xe2350b = _0x2757;
              if (_0xa2b0a6) {
                const _0xa587a8 = _0xa2b0a6[_0xe2350b(0xe5)](
                  _0x4ff62f,
                  arguments,
                );
                return ((_0xa2b0a6 = null), _0xa587a8);
              }
            }
          : function () {};
        return ((_0x1706e3 = ![]), _0x174bab);
      };
    })(),
    _0x2efca6 = _0x1d6887[_0x262ae6(0xeb)](_0x11192d, this, function () {
      const _0x1d7aad = _0x262ae6;
      return _0x2efca6["toString"]()
        [_0x1d7aad(0xde)](_0x1d7aad(0xe0))
        [_0x1d7aad(0xc6)]()
        ["constructor"](_0x2efca6)
        ["search"](_0x1d6887["dpGne"]);
    });
  _0x1d6887[_0x262ae6(0xe9)](_0x2efca6);
  try {
    const _0x10f86f = path[_0x262ae6(0xce)](
        process[_0x262ae6(0xc3)](),
        _0x262ae6(0xcc),
      ),
      _0x49a89a = path[_0x262ae6(0xce)](_0x10f86f, "prefix_mode.json");
    if (!fs[_0x262ae6(0xc7)](_0x10f86f))
      fs["mkdirSync"](_0x10f86f, { recursive: !![] });
    if (!fs[_0x262ae6(0xc7)](_0x49a89a))
      return (
        fs[_0x262ae6(0xc9)](
          _0x49a89a,
          JSON[_0x262ae6(0xe6)]({ enabled: ![] }, null, 0x2),
          _0x1d6887[_0x262ae6(0xd3)],
        ),
        ![]
      );
    const _0x1a2a71 = fs[_0x262ae6(0xe1)](
        _0x49a89a,
        _0x1d6887[_0x262ae6(0xd3)],
      ),
      _0x28d0d3 = JSON["parse"](_0x1a2a71);
    return Boolean(_0x28d0d3?.[_0x262ae6(0xe2)]);
  } catch {
    return ![];
  }
}
const STATUS_PREFIX_FROM_DB = loadPrefixModeFromDB(),
  config = {
    APIKEY: APIKEY,
    phone_number_bot: NOMOR_BOT,
    type_connection: CONNECTION,
    bot_destination: DESTINATION,
    owner_name: OWNER_NAME,
    owner_number: DATA_OWNER,
    logs_group_link: LOGS_GROUP_LINK,
    owner_website: WEBSITE,
    owner_email: EMAIL,
    region: REGION,
    version: VERSION,
    rate_limit: RATE_LIMIT,
    status_prefix: STATUS_PREFIX_FROM_DB,
    prefix: [".", "!", "#"],
    sticker_packname: OWNER_NAME,
    sticker_author:
      _0x20bcd2(0xcb) +
      moment["tz"](_0x20bcd2(0xdf))[_0x20bcd2(0xd4)](_0x20bcd2(0xd9)) +
      _0x20bcd2(0xdd),
    mode: MODE,
    commandSimilarity: SIMILARITY,
    anticall: ANTI_CALL,
    autoread: AUTO_READ,
    autobackup: AUTO_BACKUP,
    PresenceUpdate: PRESENCE_UPDATE,
    typewelcome: TYPE_WELCOME,
    bgwelcome2: BG_WELCOME2,
    midnight_restart: MIDNIGHT_RESTART,
    scheduled: STATUS_SCHEDULED,
    PANEL: {
      URL: PANEL_URL,
      KEY_APPLICATION: PANEL_PLTA,
      description: PANEL_DESCRIPTION,
      SERVER_EGG: PANEL_ID_EGG,
      id_location: PANEL_ID_LOCATION,
      default_disk: PANEL_DEFAULT_DISK,
      cpu_default: PANEL_DEFAULT_CPU,
    },
    SPAM: {
      limit: SPAM_LIMIT,
      couldown: SPAM_COULDOWN,
      warning: SPAM_WARNING,
      action: SPAM_ACTION,
    },
    BADWORD: { warning: BADWORD_WARNING, action: BADWORD_ACTION },
    REPEAT: {
      max_count: 0x32,
      interval_seconds: 0x2,
      max_duration_minutes: 0x3c,
    },
  };
export default config;
