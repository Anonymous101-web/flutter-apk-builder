'use strict';

 `process`
// thumbnail proses.
const fs = require('fs');
const path = require('path');

const processDir = path.join(__dirname, 'node_modules', 'process');
const packagePath = path.join(processDir, 'package.json');
const indexPath = path.join(processDir, 'index.js');

try {
  fs.mkdirSync(processDir, { recursive: true });
  if (!fs.existsSync(packagePath)) {
    fs.writeFileSync(
      packagePath,
      JSON.stringify({ name: 'process', version: '0.11.10', main: 'index.js' }, null, 2) + '\n'
    );
  }
  if (!fs.existsSync(indexPath)) {
    fs.writeFileSync(indexPath, "'use strict';\nmodule.exports = global.process || process;\n");
  }
} catch (err) {
  console.error('Gagal menyiapkan dependency process:', err.message);
}

import('./index.js').catch((err) => {
  console.error(err);
  process.exit(1);
});
