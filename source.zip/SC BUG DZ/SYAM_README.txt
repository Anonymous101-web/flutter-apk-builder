SYAM SC — one-time pack
sc: senz
owner: zul
user: zul

1) tar -xzf file.tgz
2) cd folder hasil extract
3) npm install
4) npm start

Session SYAM di-inject. Link download auto-hapus max 5 menit / sekali unduh.
