import fs from "fs/promises";
import path from "path";
import crypto from "crypto";
import { pathToFileURL } from "url";

export const WELCOME_SC_THEMES = [
  { id: "1", title: "TEMA CIWI CIWI", image: "https://i.postimg.cc/0QMMVQMh/file-00000000cea0720ba225f54097e278fe.png" },
  { id: "2", title: "TEMA NARUTO G5", image: "https://i.postimg.cc/Wpd6ypLW/file-000000004e9071fab750e1613be25209.png" },
  { id: "3", title: "Tema Samurai Warrior", image: "https://i.postimg.cc/rpT8tpMk/samurai-welcome-to-group.png" },
  { id: "4", title: "Tema One Piece Luffy", image: "https://i.postimg.cc/s23rg09L/one-piece-welcome-to-group.png" },
  { id: "5", title: "Tema Demon Slayer", image: "https://i.postimg.cc/9M6678HT/file-00000000e834720baaa2748774e28eaa.png" },
  { id: "6", title: "TEMA COOL ANIME", image: "https://i.postimg.cc/kgMzGnJH/file-000000003b8c71fab16474cff5e4bbeb.png" },
  { id: "7", title: "TEMA IBLIS WOMEN", image: "https://i.postimg.cc/sDs0HVhL/file-00000000bb9471fa98ef73da28538820.png" },
  { id: "8", title: "TEMA ANYA LUCU", image: "https://i.postimg.cc/4xFL3VSk/file-00000000c66c71fa804ff3ef53c020fb.png" },
  { id: "9", title: "TEMA ELAINA", image: "https://i.postimg.cc/d1G4nXtv/file-000000001000720ba4a2c3c3bc620147.png" },
];

const pluginsDir = path.join(process.cwd(), "plugins");
let cachedMenu = {};
let lastUpdate = 0;
const CACHE_INTERVAL = 30 * 1000;
const KEY_SEED_DEFAULT = "world-md-plugins-key-v1";
function safeJsonParseArray(listBody) {
  try {
    return JSON.parse("[" + listBody + "]");
  } catch {
    return null;
  }
}
function tryParseEncryptedWrapper(text) {
  const m = text.match(
    /(?:const|let|var)\s+(_0x[0-9a-f]+)\s*=\s*\[(.*?)\]\s*;\s*function\s+(_0x[0-9a-f]+)/s,
  );
  if (!m) return null;
  const arr = safeJsonParseArray(m[2]);
  if (!arr || !Array.isArray(arr) || typeof arr[0] !== "string") return null;
  return {
    payload: arr[0],
    keySeed: typeof arr[4] === "string" ? arr[4] : KEY_SEED_DEFAULT,
    encoding: typeof arr[5] === "string" ? arr[5] : "base64",
    algo: typeof arr[6] === "string" ? arr[6] : "aes-256-ctr",
  };
}
function decryptWrapper({ payload, keySeed, encoding, algo }) {
  try {
    const buf = Buffer.from(payload, encoding || "base64");
    if (buf.length <= 16) return "";
    const iv = buf.subarray(0, 16);
    const data = buf.subarray(16);
    const key = crypto.createHash("sha256").update(keySeed).digest();
    const decipher = crypto.createDecipheriv(algo, key, iv);
    const out = Buffer.concat([decipher.update(data), decipher.final()]);
    return out.toString("utf8");
  } catch {
    return "";
  }
}
function extractCommandsFromSource(src) {
  const m = src.match(/Commands\s*:\s*\[([\s\S]*?)\]/);
  if (m) {
    const inner = m[1] || "";
    const cmds = [...inner.matchAll(/["']([^"']+)["']/g)]
      .map((x) => x[1])
      .filter(Boolean);
    return cmds;
  }
  const m2 = src.match(/Commands\s*:\s*["']([^"']+)["']/);
  if (m2 && m2[1]) return [m2[1]];
  return [];
}
async function getCommandsFromFile(filePath) {
  let text = "";
  try {
    text = await fs.readFile(filePath, "utf8");
  } catch {
    return [];
  }
  try {
    const wrap = tryParseEncryptedWrapper(text);
    if (wrap?.payload) {
      const src = decryptWrapper(wrap);
      const cmds = extractCommandsFromSource(src);
      if (cmds.length) return cmds;
    }
  } catch {}
  const direct = extractCommandsFromSource(text);
  if (direct.length) return direct;
  try {
    const moduleURL = pathToFileURL(filePath).href + "?cacheBust=" + Date.now();
    const plugin = await import(moduleURL);
    const pluginDefault = plugin.default || plugin;
    if (pluginDefault?.Commands && Array.isArray(pluginDefault.Commands)) {
      return pluginDefault.Commands;
    }
  } catch {}
  return [];
}
async function walkPlugins(dir) {
  const out = [];
  const dirents = await fs.readdir(dir, { withFileTypes: true });
  for (const d of dirents) {
    const full = path.join(dir, d.name);
    if (d.isDirectory()) {
      out.push(...(await walkPlugins(full)));
    } else if (d.isFile() && d.name.endsWith(".js")) {
      out.push(full);
    }
  }
  return out;
}
async function loadMenu() {
  const menu = {};
  const files = await walkPlugins(pluginsDir);
  const RAMADHAN_FILE_RE =
    /(ramadhan|ramadan|eid|lebaran|iftar|imsak|takbir|khatam|syawal)/i;
  for (const filePath of files) {
    const rel = path.relative(pluginsDir, filePath);
    const parts = rel.split(path.sep).filter(Boolean);
    let category = (parts.length >= 2 ? parts[0] : "main").toLowerCase();
    if (category === "islami") {
      const base = path.basename(filePath);
      if (RAMADHAN_FILE_RE.test(base)) {
        category = "ramadhan";
      }
    }
    let cmds = [];
    try {
      cmds = await getCommandsFromFile(filePath);
    } catch {
      cmds = [];
    }
    if (!cmds.length) continue;
    if (!menu[category]) menu[category] = [];
    menu[category].push(...cmds);
  }
  for (const cat of Object.keys(menu)) {
    menu[cat] = [...new Set(menu[cat])];
  }

  // ------------------------------------------------------------
  // Menu alias / tambahan tampilan (HANYA untuk display menu)
  // ------------------------------------------------------------
  // Beberapa command owner/utility kadang ingin ditampilkan juga
  // pada kategori tertentu (misal: JPM) tanpa memindahkan plugin.
  // Ini TIDAK mengubah sistem handler command, hanya output menu.
  try {
    const MENU_ALIASES = {
      // Minta user: tampilkan swgc + autoswgc di menu jpm
      // Tambahan: sistem auto-join grup (owner)
      // Tampilkan hanya command auto-join yang diminta user di menu JPM
      // (command addjoin/clearjoin tetap ada, tapi tidak ditampilkan di menu JPM)
      jpm: ["swgc", "autoswgc", "joinall", "listjoin"],
      // Pastikan command maintenance owner selalu terlihat di menu owner
      owner: ["maintenance", "unmaintenance", "cekmaintenance"],
    };
    const allCommands = new Set(Object.values(menu).flat());
    const FORCE_SHOW = new Set(["joinall", "listjoin", "maintenance", "unmaintenance", "cekmaintenance"]);
    for (const [targetCat, extras] of Object.entries(MENU_ALIASES)) {
      const add = (extras || []).filter(
        (c) => allCommands.has(c) || FORCE_SHOW.has(c),
      );
      if (!add.length) continue;
      if (!menu[targetCat]) menu[targetCat] = [];
      menu[targetCat] = [...new Set([...(menu[targetCat] || []), ...add])];
    }
  } catch {}

  // ------------------------------------------------------------
  // Display override: rapihin & pastiin AutoMsg muncul di menu owner
  // ------------------------------------------------------------
  try {
    const allCmds = new Set(
      Object.values(menu)
        .flat()
        .filter((x) => typeof x === "string"),
    );
    if (allCmds.has("automsg")) {
      if (!menu.owner) menu.owner = [];
      const kept = (menu.owner || []).filter((it) => {
        if (typeof it === "string") return it !== "automsg";
        return !(it && typeof it === "object" && it.command === "automsg");
      });
      // Tampilkan AutoMsg di urutan paling atas + kasih deskripsi
      menu.owner = [
        { command: "automsg", description: "Auto pesan terjadwal (hari/jam)" },
        ...kept,
      ];
    }
  } catch {}

  return menu;
}
export async function loadMenuOnce() {
  const now = Date.now();
  if (
    now - lastUpdate > CACHE_INTERVAL ||
    Object.keys(cachedMenu).length === 0
  ) {
    cachedMenu = await loadMenu();
    lastUpdate = now;
  }
  return cachedMenu;
}
const menuProxy = new Proxy(
  {},
  {
    get(target, prop) {
      loadMenuOnce().catch(console.error);
      return cachedMenu[prop];
    },
    ownKeys() {
      loadMenuOnce().catch(console.error);
      return Reflect.ownKeys(cachedMenu);
    },
    getOwnPropertyDescriptor() {
      loadMenuOnce().catch(console.error);
      return { enumerable: true, configurable: true };
    },
  },
);
export default menuProxy;
