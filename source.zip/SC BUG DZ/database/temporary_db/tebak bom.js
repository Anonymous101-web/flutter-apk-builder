const DB_tebak_kalimat={};function addUser(remoteJid,data){DB_tebak_kalimat[remoteJid]=data;}
function removeUser(remoteJid){delete DB_tebak_kalimat[remoteJid];}
function getUser(remoteJid){return DB_tebak_kalimat[remoteJid]||null;}
function isUserPlaying(remoteJid){return Boolean(DB_tebak_kalimat[remoteJid]);}
export{DB_tebak_kalimat,addUser,removeUser,getUser,isUserPlaying};
