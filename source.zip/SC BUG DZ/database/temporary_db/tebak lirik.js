const DB_tebak_lirik={};function addUser(remoteJid,data){DB_tebak_lirik[remoteJid]=data;}
function removeUser(remoteJid){delete DB_tebak_lirik[remoteJid];}
function getUser(remoteJid){return DB_tebak_lirik[remoteJid]||null;}
function isUserPlaying(remoteJid){return Boolean(DB_tebak_lirik[remoteJid]);}
export{DB_tebak_lirik,addUser,removeUser,getUser,isUserPlaying};
