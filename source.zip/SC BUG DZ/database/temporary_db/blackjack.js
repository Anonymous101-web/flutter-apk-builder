const DB_blackjack={};function addUser(remoteJid,data){DB_blackjack[remoteJid]=data;}
function removeUser(remoteJid){delete DB_blackjack[remoteJid];}
function getUser(remoteJid){return DB_blackjack[remoteJid]||null;}
function isUserPlaying(remoteJid){return Boolean(DB_blackjack[remoteJid]);}
export{DB_blackjack,addUser,removeUser,getUser,isUserPlaying};
