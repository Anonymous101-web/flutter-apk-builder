const DB_tebak_lagu={};function addUser(remoteJid,data){console.log(data);DB_tebak_lagu[remoteJid]=data;}
function removeUser(remoteJid){delete DB_tebak_lagu[remoteJid];}
function getUser(remoteJid){return DB_tebak_lagu[remoteJid]||null;}
function isUserPlaying(remoteJid){return Boolean(DB_tebak_lagu[remoteJid]);}
export{DB_tebak_lagu,addUser,removeUser,getUser,isUserPlaying};
