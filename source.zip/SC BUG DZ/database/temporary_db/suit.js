const DB_suit={};function addUser(remoteJid,data){DB_suit[remoteJid]=data;}
function updateUser(remoteJid,newData){if(DB_suit[remoteJid]){DB_suit[remoteJid]={...DB_suit[remoteJid],...newData,};}else{console.error(`User dengan remoteJid ${remoteJid} tidak ditemukan untuk diperbarui.`);}}
function removeUser(remoteJid){delete DB_suit[remoteJid];}
function getUser(remoteJid){return DB_suit[remoteJid]||null;}
function isUserPlaying(remoteJid){return Boolean(DB_suit[remoteJid]);}
function findDataByKey(searchCriteria){const key=Object.keys(searchCriteria)[0];let value=searchCriteria[key];if(value===""||value===undefined||value===null){value=null;}
for(const remoteJid in DB_suit){if(DB_suit[remoteJid][key]===value){return{remoteJid,...DB_suit[remoteJid],};}}
return null;}
export{DB_suit,addUser,removeUser,getUser,isUserPlaying,findDataByKey,updateUser,};
