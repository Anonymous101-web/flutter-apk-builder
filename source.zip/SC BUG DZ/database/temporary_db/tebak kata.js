const DB_tebak_kata={};function addUser(remoteJid,data){DB_tebak_kata[remoteJid]=data;}
function removeUser(remoteJid){delete DB_tebak_kata[remoteJid];}
function getUser(remoteJid){return DB_tebak_kata[remoteJid]||null;}
function isUserPlaying(remoteJid){return Boolean(DB_tebak_kata[remoteJid]);}
export{DB_tebak_kata,addUser,removeUser,getUser,isUserPlaying};
