const DB_tebak_hewan={};function addUser(remoteJid,data){DB_tebak_hewan[remoteJid]=data;}
function removeUser(remoteJid){delete DB_tebak_hewan[remoteJid];}
function getUser(remoteJid){return DB_tebak_hewan[remoteJid]||null;}
function isUserPlaying(remoteJid){return Boolean(DB_tebak_hewan[remoteJid]);}
export{DB_tebak_hewan,addUser,removeUser,getUser,isUserPlaying};
