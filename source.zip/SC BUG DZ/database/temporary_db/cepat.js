const games=new Map();export function addGame(key,state){games.set(key,state);}
export function getGame(key){return games.get(key);}
export function removeGame(key){games.delete(key);}
export function isPlaying(key){return games.has(key);}
