const DB_tebak_bendera={};function addUser(remoteJid,data){DB_tebak_bendera[remoteJid]=data;}
function removeUser(remoteJid){delete DB_tebak_bendera[remoteJid];}
function getUser(remoteJid){return DB_tebak_bendera[remoteJid]||null;}
function isUserPlaying(remoteJid){return Boolean(DB_tebak_bendera[remoteJid]);}
export{DB_tebak_bendera,addUser,removeUser,getUser,isUserPlaying};
