const DB_tictactoe={};function addUser(remoteJid,data){DB_tictactoe[remoteJid]=data;}
function updateGame(remoteJid,newData){if(DB_tictactoe[remoteJid]){DB_tictactoe[remoteJid]={...DB_tictactoe[remoteJid],...newData,};}else{console.error(`User dengan remoteJid ${remoteJid} tidak ditemukan untuk diperbarui.`);}}
function removeUser(remoteJid){delete DB_tictactoe[remoteJid];}
function getUser(remoteJid){return DB_tictactoe[remoteJid]||null;}
function isUserPlaying(remoteJid){return Boolean(DB_tictactoe[remoteJid]);}
export{DB_tictactoe,addUser,removeUser,getUser,isUserPlaying,updateGame,};
