const DB_hangman={};export function addGame(remoteJid,data){DB_hangman[remoteJid]=data;}
export function getGame(remoteJid){return DB_hangman[remoteJid]||null;}
export function removeGame(remoteJid){delete DB_hangman[remoteJid];}
export function isPlaying(remoteJid){return Object.prototype.hasOwnProperty.call(DB_hangman,remoteJid);}
