const DB_math={};function addUser(remoteJid,data){DB_math[remoteJid]=data;}
function updateGame(remoteJid,newData){if(DB_math[remoteJid]){DB_math[remoteJid]={...DB_math[remoteJid],...newData,};}else{console.error(`User dengan remoteJid ${remoteJid} tidak ditemukan untuk diperbarui.`);}}
function removeUser(remoteJid){delete DB_math[remoteJid];}
function getUser(remoteJid){return DB_math[remoteJid]||null;}
function isUserPlaying(remoteJid){return Boolean(DB_math[remoteJid]);}
export{DB_math,addUser,removeUser,getUser,isUserPlaying,updateGame};
