const DB_tebak_angka={};function addUser(remoteJid,data){DB_tebak_angka[remoteJid]=data;}
function removeUser(remoteJid){delete DB_tebak_angka[remoteJid];}
function getUser(remoteJid){return DB_tebak_angka[remoteJid]||null;}
function isUserPlaying(remoteJid){return Boolean(DB_tebak_angka[remoteJid]);}
export{DB_tebak_angka,addUser,removeUser,getUser,isUserPlaying};
