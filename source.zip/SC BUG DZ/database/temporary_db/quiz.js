const DB_quiz={};export function addQuiz(remoteJid,data){DB_quiz[remoteJid]=data;}
export function getQuiz(remoteJid){const s=DB_quiz[remoteJid]||null;if(!s)return null;if(typeof s.expiresAt==="number"&&Date.now()>s.expiresAt){delete DB_quiz[remoteJid];return null;}
return s;}
export function removeQuiz(remoteJid){delete DB_quiz[remoteJid];}
export function isQuizActive(remoteJid){return!!getQuiz(remoteJid);}
