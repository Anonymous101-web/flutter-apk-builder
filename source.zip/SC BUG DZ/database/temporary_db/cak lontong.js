const DB_cak_lontong={};function addUser(remoteJid,data){DB_cak_lontong[remoteJid]=data;}
function removeUser(remoteJid){delete DB_cak_lontong[remoteJid];}
function getUser(remoteJid){return DB_cak_lontong[remoteJid]||null;}
function isUserPlaying(remoteJid){return Boolean(DB_cak_lontong[remoteJid]);}
export{DB_cak_lontong,addUser,removeUser,getUser,isUserPlaying};
