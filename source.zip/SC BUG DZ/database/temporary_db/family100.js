const DB_family100={};function addUser(remoteJid,data){DB_family100[remoteJid]=data;}
function removeUser(remoteJid){delete DB_family100[remoteJid];}
function getUser(remoteJid){return DB_family100[remoteJid]||null;}
function isUserPlaying(remoteJid){return Boolean(DB_family100[remoteJid]);}
export{DB_family100,addUser,removeUser,getUser,isUserPlaying};
