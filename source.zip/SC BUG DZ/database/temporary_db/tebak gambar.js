const DB_tebak_gambar={};function addUser(remoteJid,data){DB_tebak_gambar[remoteJid]=data;}
function removeUser(remoteJid){delete DB_tebak_gambar[remoteJid];}
function getUser(remoteJid){return DB_tebak_gambar[remoteJid]||null;}
function isUserPlaying(remoteJid){return Boolean(DB_tebak_gambar[remoteJid]);}
export{DB_tebak_gambar,addUser,removeUser,getUser,isUserPlaying};
