import * as baileys from 'baileys'
import fs from 'fs/promises'
import path from 'path'
import config from '../../config.js'
import { logCustom } from '../../lib/logger.js'

const CARD_IMAGE = path.join(process.cwd(), 'database/assets/allmenu2.jpg')

function menuCaption(text) {
  return `こんにちは SILAKAN PILIH MENU BRAT NYA DIBAWAH YA KAKA!

🎐 TEXT : ${text}

CATATAN : geser ke samping untuk melihat brat lainnya dan teken tombol untuk brat system nya`
}

async function getPreparedImage(sock) {
  try {
    await fs.access(CARD_IMAGE)
    const media = await baileys.prepareWAMessageMedia(
      { image: await fs.readFile(CARD_IMAGE) },
      { upload: sock.waUploadToServer }
    )
    return media?.imageMessage || null
  } catch {
    return null
  }
}

async function sendFallback(sock, remoteJid, message, prefix, text) {
  return sock.sendMessage(
    remoteJid,
    {
      image: await fs.readFile(CARD_IMAGE),
      caption: menuCaption(text),
      footer: '',
      buttons: [
        { buttonId: `${prefix}bratgambar ${text}`, buttonText: { displayText: '𝗕𝗿𝗮𝘁 𝗚𝗮𝗺𝗯𝗮𝗿' }, type: 1 },
        { buttonId: `${prefix}bratgura ${text}`, buttonText: { displayText: '𝗕𝗿𝗮𝘁 𝗚𝘂𝗿𝗮' }, type: 1 },
        { buttonId: `${prefix}bratanime ${text}`, buttonText: { displayText: '𝗕𝗿𝗮𝘁 𝗔𝗻𝗶𝗺𝗲' }, type: 1 },
        { buttonId: `${prefix}bratgambarhd ${text}`, buttonText: { displayText: '𝗕𝗿𝗮𝘁 𝗛𝗗' }, type: 1 },
        { buttonId: `${prefix}bratpink ${text}`, buttonText: { displayText: '𝗕𝗿𝗮𝘁 𝗣𝗶𝗻𝗸' }, type: 1 },
        { buttonId: `${prefix}bratvid ${text}`, buttonText: { displayText: '𝗕𝗿𝗮𝘁 𝗩𝗶𝗱𝗲𝗼' }, type: 1 },
      ],
      headerType: 4,
    },
    { quoted: message }
  )
}

async function sendCarousel(sock, remoteJid, message, prefix, text) {
  if (!baileys.generateWAMessageFromContent || !sock.relayMessage) {
    throw new Error('Interactive carousel tidak tersedia di runtime ini')
  }

  const preparedImg = await getPreparedImage(sock)
  const header = (title) => preparedImg ? { title, hasMediaAttachment: true, imageMessage: preparedImg } : { title, hasMediaAttachment: false }
  const card = (title, desc, cmd, label) => ({
    header: header(title),
    body: { text: `WORLD MD\nTeks: ${text}\n\n${desc}\nTap tombol di bawah untuk langsung generate.` },
    nativeFlowMessage: {
      buttons: [
        {
          name: 'quick_reply',
          buttonParamsJson: JSON.stringify({ display_text: label, id: `${prefix}${cmd} ${text}` }),
        },
      ],
    },
  })

  const cards = [
    card('🖼️ BRAT GAMBAR', 'Versi brat gambar biasa.', 'bratgambar', '𝗕𝗿𝗮𝘁 𝗚𝗮𝗺𝗯𝗮𝗿'),
    card('🌊 BRAT GURA', 'Template brat gura.', 'bratgura', '𝗕𝗿𝗮𝘁 𝗚𝘂𝗿𝗮'),
    card('✨ BRAT ANIME', 'Template brat anime.', 'bratanime', '𝗕𝗿𝗮𝘁 𝗔𝗻𝗶𝗺𝗲'),
    card('💎 BRAT HD', 'Versi brat HD.', 'bratgambarhd', '𝗕𝗿𝗮𝘁 𝗛𝗗'),
    card('🌸 BRAT PINK', 'Background pink custom.', 'bratpink', '𝗕𝗿𝗮𝘁 𝗣𝗶𝗻𝗸'),
    card('🎬 BRAT VIDEO', 'Sticker dari brat video.', 'bratvid', '𝗕𝗿𝗮𝘁 𝗩𝗶𝗱𝗲𝗼'),
  ]

  const msg = baileys.generateWAMessageFromContent(
    remoteJid,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: menuCaption(text) },
            carouselMessage: { cards, messageVersion: 1 },
          },
        },
      },
    },
    {}
  )

  await sock.relayMessage(remoteJid, msg.message, { messageId: msg.key.id })
}

async function handle(sock, messageInfo) {
  const { remoteJid, message, content, isQuoted, prefix, command } = messageInfo

  try {
    const text = content && content.trim() !== '' ? content.trim() : isQuoted?.text ?? null
    if (!text) {
      await sock.sendMessage(
        remoteJid,
        { text: `𐔈⃘ ֹ ׅ 🍓 ֹ *Brat Generator* ֹ ׅ ୫\n۫ ╰╼ ׅ ֹ𔖰᷼𔖮 Parameter wajib diisi!\n╭╼─┈───┈──⏣╼╯\n┆✿᪲ ׄ𖹭₊ *Format* : ${prefix + command} [teks]\n┆✿᪲ ׄ𖹭₊ *Contoh* : ${prefix + command} Hai kak\n┆✿᪲ ׄ𖹭₊ *Maksimal* : 100 karakter\n╰─╼𔕬─┈───┈───┈` },
        { quoted: message }
      )
      return
    }

    if (text.length > 100) {
      await sock.sendMessage(
        remoteJid,
        { text: `𐔈⃘ ֹ ׅ 🍓 ֹ *Brat Generator* ֹ ׅ ୫\n۫ ╰╼ ׅ ֹ𔖰᷼𔖮 *GAGAL*\n╭╼─┈───┈──⏣╼╯\n┆✿᪲ ׄ𖹭₊ *Alasan* : Teks terlalu panjang\n┆✿᪲ ׄ𖹭₊ *Input* : ${text.length} karakter\n┆✿᪲ ׄ𖹭₊ *Maksimal* : 100 karakter\n╰─╼𔕬─┈───┈───┈` },
        { quoted: message }
      )
      return
    }

    await sock.sendMessage(remoteJid, { react: { text: '⏳', key: message.key } })

    try {
      await sendCarousel(sock, remoteJid, message, prefix, text)
    } catch (carouselError) {
      await sendFallback(sock, remoteJid, message, prefix, text)
    }

    await sock.sendMessage(remoteJid, { react: { text: '✅', key: message.key } })
  } catch (error) {
    logCustom('info', content, `ERROR-COMMAND-${command}.txt`)
    await sock.sendMessage(remoteJid, { text: `Maaf, terjadi kesalahan saat memproses permintaan Anda.\n\nError: ${error.message}` }, { quoted: message })
  }
}

export default {
  handle,
  Commands: ['brat'],
  OnlyPremium: false,
  OnlyOwner: false,
}
