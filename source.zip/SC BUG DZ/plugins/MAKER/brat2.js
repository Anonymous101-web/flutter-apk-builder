import ApiAutoresbotModule from 'api-autoresbot'
import { createCanvas, loadImage } from 'canvas'
import config from '../../config.js'
import { sendImageAsSticker } from '../../lib/exif.js'
import { logCustom } from '../../lib/logger.js'

const ApiAutoresbot = ApiAutoresbotModule.default || ApiAutoresbotModule

async function fetchBuffer(url) {
  const res = await fetch(url)
  if (!res.ok) throw new Oops(`HTTP ${res.status} saat mengambil resource`)
  return Buffer.from(await res.arrayBuffer())
}

async function sendSticker(sock, remoteJid, message, buffer) {
  const options = { packname: config.sticker_packname, author: config.sticker_author }
  await sendImageAsSticker(sock, remoteJid, buffer, options, message)
}

async function generateGura(text) {
  const buffer = await fetchBuffer('https://raw.githubusercontent.com/alifalfarel25-commits/dat4/main/uploads/alip-clutch-1770001033541.jpg')
  const img = await loadImage(buffer)
  const canvas = createCanvas(img.width, img.height)
  const ctx = canvas.getContext('2d')
  ctx.drawImage(img, 0, 0, img.width, img.height)

  const areaX = img.width * 0.56
  const areaY = img.height * 0.28
  const areaWidth = img.width * 0.36
  const areaHeight = img.height * 0.32

  let fontSize = img.height * 0.11
  const words = text.split(/\s+/)
  let lines = []

  const wrap = () => {
    ctx.font = `${Math.max(12, Math.floor(fontSize))}px Arial`
    const out = []
    let line = ''
    for (const word of words) {
      const testLine = line ? `${line} ${word}` : word
      if (ctx.measureText(testLine).width > areaWidth && line) {
        out.push(line)
        line = word
      } else {
        line = testLine
      }
    }
    if (line) out.push(line)
    return out
  }

  lines = wrap()
  while (lines.length * fontSize * 1.25 > areaHeight && fontSize > 18) {
    fontSize -= 2
    lines = wrap()
  }

  ctx.font = `${Math.max(12, Math.floor(fontSize))}px Arial`
  ctx.fillStyle = '#000'
  ctx.textAlign = 'left'
  ctx.textBaseline = 'top'
  ctx.shadowColor = 'rgba(0,0,0,0.22)'
  ctx.shadowBlur = 2
  ctx.shadowOffsetX = 1
  ctx.shadowOffsetY = 1
  ctx.globalAlpha = 0.95

  const lineHeight = fontSize * 1.25
  lines.forEach((line, i) => ctx.fillText(line, areaX, areaY + i * lineHeight))
  ctx.globalAlpha = 1
  return canvas.toBuffer('image/png')
}

async function generateAnime(text) {
  const buffer = await fetchBuffer('https://files.catbox.moe/19c4n5.png')
  const img = await loadImage(buffer)
  const canvas = createCanvas(img.width, img.height)
  const ctx = canvas.getContext('2d')
  ctx.drawImage(img, 0, 0, img.width, img.height)

  const paperX = img.width * 0.285
  const paperY = img.height * 0.42
  const paperWidth = img.width * 0.30
  const paperHeight = img.height * 0.28
  const words = text.split(/\s+/)
  const maxWidth = paperWidth * 0.88
  let fontSize = Math.min(paperWidth / 5.5, paperHeight / 2.8)
  let lines = []

  const wrap = () => {
    ctx.font = `bold ${Math.max(12, Math.floor(fontSize))}px Arial`
    const out = []
    let line = ''
    for (const word of words) {
      const testLine = line ? `${line} ${word}` : word
      if (ctx.measureText(testLine).width > maxWidth && line) {
        out.push(line)
        line = word
      } else {
        line = testLine
      }
    }
    if (line) out.push(line)
    return out
  }

  lines = wrap()
  while (lines.length * fontSize > paperHeight * 0.8 && fontSize > 14) {
    fontSize -= 1
    lines = wrap()
  }

  ctx.font = `bold ${Math.max(12, Math.floor(fontSize))}px Arial`
  ctx.fillStyle = 'black'
  const lineHeight = fontSize * 1.25
  const textHeight = lines.length * lineHeight
  const textStartY = paperY + (paperHeight - textHeight) / 2 + 268

  ctx.save()
  ctx.translate(paperX + paperWidth / 2 + 300, textStartY + 12)
  ctx.rotate(0.06)
  ctx.textAlign = 'center'
  ctx.shadowColor = 'rgba(0, 0, 0, 0.4)'
  ctx.shadowBlur = 4
  ctx.shadowOffsetX = 2
  ctx.shadowOffsetY = 2
  lines.forEach((line, i) => ctx.fillText(line, 0, i * lineHeight))
  ctx.restore()

  return canvas.toBuffer('image/png')
}

async function generateHd(text) {
  const sanitizedContent = encodeURIComponent(text.trim().replace(/\n+/g, ' '))
  const api = new ApiAutoresbot(config.APIKEY)
  return api.getBuffer('/api/maker/brat2', { text: sanitizedContent })
}

async function handle(sock, messageInfo) {
  const { remoteJid, message, content, isQuoted, prefix, command } = messageInfo

  try {
    const text = content && String(content).trim() !== '' ? String(content).trim() : isQuoted?.text ?? null
    if (!text) {
      await sock.sendMessage(remoteJid, { text: `❌ Contohnya begini: ${prefix + command} Hello World` }, { quoted: message })
      return
    }

    await sock.sendMessage(remoteJid, { react: { text: '⏳', key: message.key } })

    let buffer
    if (command === 'bratgura') buffer = await generateGura(text)
    else if (command === 'bratanime') buffer = await generateAnime(text)
    else buffer = await generateHd(text)

    await sendSticker(sock, remoteJid, message, buffer)
    await sock.sendMessage(remoteJid, { react: { text: '✅', key: message.key } })
  } catch (error) {
    logCustom('info', content, `ERROR-COMMAND-${command}.txt`)
    await sock.sendMessage(remoteJid, { text: `Maaf, terjadi kesalahan saat memproses permintaan Anda.\n\nOops: ${error.message}` }, { quoted: message })
  }
}

export default {
  handle,
  Commands: ['brat2', 'bratgura', 'bratanime', 'bratgambarhd', 'brathd'],
  OnlyPremium: false,
  OnlyOwner: false,
  limitDeduction: 1,
}
