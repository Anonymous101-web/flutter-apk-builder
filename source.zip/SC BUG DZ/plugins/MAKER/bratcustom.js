import ApiAutoresbotModule from 'api-autoresbot'
import { createCanvas } from 'canvas'
import config from '../../config.js'
import { sendImageAsSticker } from '../../lib/exif.js'
import { logCustom } from '../../lib/logger.js'

const ApiAutoresbot = ApiAutoresbotModule.default || ApiAutoresbotModule

async function sendSticker(sock, remoteJid, message, buffer) {
  const options = { packname: config.sticker_packname, author: config.sticker_author }
  await sendImageAsSticker(sock, remoteJid, buffer, options, message)
}

async function generateBratPink(text) {
  const width = 512
  const height = 512
  const canvas = createCanvas(width, height)
  const ctx = canvas.getContext('2d')

  ctx.fillStyle = '#ffb6c1'
  ctx.fillRect(0, 0, width, height)

  let fontSize = 96
  const maxWidth = width * 0.9
  const words = text.split(/\s+/)
  let lines = []

  const wrap = () => {
    ctx.font = `${Math.max(12, Math.floor(fontSize))}px Arial`
    const out = []
    let line = ''
    for (const word of words) {
      const testLine = line ? `${line} ${word}` : word
      if (ctx.measureText(testLine).width > maxWidth && line) {
        out.push(line)
        line = word
      } else {
        line = testLine
      }
    }
    if (line) out.push(line)
    return out
  }

  lines = wrap()
  while (lines.length * fontSize > height * 0.9 && fontSize > 20) {
    fontSize -= 4
    lines = wrap()
  }

  ctx.font = `${Math.max(12, Math.floor(fontSize))}px Arial`
  ctx.fillStyle = '#000000'
  ctx.textAlign = 'left'
  ctx.textBaseline = 'top'
  const lineHeight = fontSize * 1.2
  lines.forEach((line, i) => ctx.fillText(line, 20, 20 + i * lineHeight))

  return canvas.toBuffer('image/png')
}

async function handle(sock, messageInfo) {
  const { remoteJid, message, content, isQuoted, prefix, command } = messageInfo

  try {
    let textContent = content && String(content).trim() !== '' ? String(content).trim() : isQuoted?.text ?? null
    if (!textContent) {
      const example = command === 'bratpink' ? `${prefix + command} hallo` : `${prefix + command} merah|biru|WorldMD`
      await sock.sendMessage(remoteJid, { text: `_⚠️ Cara pakainya gini:_\n\n_💬 Contohnya begini:_ _*${example}*_` }, { quoted: message })
      return
    }

    await sock.sendMessage(remoteJid, { react: { text: '⏳', key: message.key } })

    if (command === 'bratpink') {
      const buffer = await generateBratPink(textContent)
      await sendSticker(sock, remoteJid, message, buffer)
      await sock.sendMessage(remoteJid, { react: { text: '✅', key: message.key } })
      return
    }

    const args = textContent.trim().split('|')
    let [textColor, bgColor, ...textParts] = args
    const basicColors = {
      merah: 'ff0000', biru: '0000ff', hijau: '008000', kuning: 'ffff00', hitam: '000000', putih: 'ffffff',
      ungu: '800080', oranye: 'ffa500', abuabu: '808080', coklat: '8b4513', merahmuda: 'ffc0cb',
      birutua: '00008b', birumuda: '87ceeb', hijautua: '006400', hijaumuda: '90ee90', emas: 'ffd700',
      perak: 'c0c0c0', cyan: '00ffff', magenta: 'ff00ff', lavender: 'e6e6fa', coral: 'ff7f50',
      navy: '000080', teal: '008080', lime: '00ff00', violet: 'ee82ee', crimson: 'dc143c',
      khaki: 'f0e68c', salmon: 'fa8072', chocolate: 'd2691e', tan: 'd2b48c', sienna: 'a0522d',
      beige: 'f5f5dc', turquoise: '40e0d0', indigo: '4b0082', slateblue: '6a5acd', maroon: '800000',
      olive: '808000', mint: '98ff98', ivory: 'fffff0', peach: 'ffdab9', aquamarine: '7fffd4',
      wheat: 'f5deb3', plum: 'dda0dd', orchid: 'da70d6', pink: 'ffc0cb'
    }

    textColor = basicColors[textColor?.toLowerCase()] || textColor
    bgColor = basicColors[bgColor?.toLowerCase()] || bgColor
    const text = textParts.join(' ').trim()

    if (!text) {
      await sock.sendMessage(remoteJid, { text: `_⚠️ Cara pakainya gini:_\n\n_💬 Contohnya begini:_ _*${prefix + command} merah|biru|WorldMD*_` }, { quoted: message })
      return
    }

    const sanitizedContent = encodeURIComponent(text.replace(/\n+/g, ' '))
    const api = new ApiAutoresbot(config.APIKEY)
    const buffer = await api.getBuffer('/api/maker/brat', { text: sanitizedContent, textColor, bgColor })
    await sendSticker(sock, remoteJid, message, buffer)
    await sock.sendMessage(remoteJid, { react: { text: '✅', key: message.key } })
  } catch (error) {
    logCustom('info', content, `ERROR-COMMAND-${command}.txt`)
    await sock.sendMessage(remoteJid, { text: `Maaf, terjadi kesalahan saat memproses permintaan Anda.\n\nOops: ${error.message}` }, { quoted: message })
  }
}

export default {
  handle,
  Commands: ['bratcustom', 'bratpink'],
  OnlyPremium: false,
  OnlyOwner: false,
}
