import ApiAutoresbotModule from 'api-autoresbot'
import config from '../../config.js'
import { gifToWebp, writeExif } from '../../lib/exif.js'
import { logCustom } from '../../lib/logger.js'

const ApiAutoresbot = ApiAutoresbotModule.default || ApiAutoresbotModule

async function handle(sock, messageInfo) {
  const { remoteJid, message, content, isQuoted, prefix, command } = messageInfo

  try {
    const text = content && content.trim() !== '' ? content.trim() : isQuoted?.text ?? null
    if (!text) {
      await sock.sendMessage(remoteJid, { text: `_⚠️ Cara pakainya gini:_\n\n_💬 Contohnya begini:_ _*${prefix + command} Hello World*_` }, { quoted: message })
      return
    }

    await sock.sendMessage(remoteJid, { react: { text: '⏳', key: message.key } })
    const sanitizedContent = encodeURIComponent(text.trim().replace(/\n+/g, ' '))
    const api = new ApiAutoresbot(config.APIKEY)
    const gifBuffer = await api.getBuffer('/api/maker/bratvid', { text: sanitizedContent })
    const webpBuffer = await gifToWebp(gifBuffer)
    const stickerPath = await writeExif(
      { mimetype: 'image/webp', data: webpBuffer },
      { packname: config.sticker_packname, author: config.sticker_author }
    )

    await sock.sendMessage(remoteJid, { sticker: { url: stickerPath } }, { quoted: message })
    await sock.sendMessage(remoteJid, { react: { text: '✅', key: message.key } })
  } catch (error) {
    logCustom('info', content, `ERROR-COMMAND-${command}.txt`)
    await sock.sendMessage(remoteJid, { text: `Maaf, terjadi kesalahan saat memproses permintaan Anda. Coba lagi nanti.\n\nOops: ${error.message}` }, { quoted: message })
  }
}

export default {
  handle,
  Commands: ['bratvid', 'bratvideo'],
  OnlyPremium: false,
  OnlyOwner: false,
  limitDeduction: 1,
}
