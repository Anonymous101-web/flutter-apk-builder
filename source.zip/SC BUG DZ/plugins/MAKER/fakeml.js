import ApiAutoresbotModule from "api-autoresbot";
const ApiAutoresbot = ApiAutoresbotModule.default || ApiAutoresbotModule;

import fs from "fs";
import path from "path";
import config from "../../config.js";
import { downloadQuotedMedia, downloadMedia, reply } from "../../lib/utils.js";

function getAlipConfig() {
  const apiBase =
    config.apialip ||
    config.APIALIP ||
    globalThis.apialip ||
    globalThis.apiAlip ||
    process.env.APIALIP ||
    process.env.API_ALIP ||
    "";

  const apiKey =
    config.apikeyalip ||
    config.APIKEYALIP ||
    globalThis.apikeyalip ||
    globalThis.apikeyAlip ||
    process.env.APIKEYALIP ||
    process.env.APIKEY_ALIP ||
    "";

  return {
    apiBase: String(apiBase || "").replace(/\/+$/, ""),
    apiKey: String(apiKey || ""),
  };
}

function buildFakeMlUrl(apiBase, apiKey, nickname, imageUrl) {
  if (!apiBase || !apiKey) {
    throw new Error(
      "API Alip belum diset. Isi global.apialip/global.apikeyalip atau ENV APIALIP/APIKEYALIP.",
    );
  }

  const url = new URL(`${apiBase}/imagecreator/fakeml`);
  url.searchParams.set("apikey", apiKey);
  url.searchParams.set("nama", nickname);
  url.searchParams.set("url", imageUrl);
  return url.toString();
}

async function handle(sock, messageInfo) {
  const { m, remoteJid, message, content, prefix, command, type, isQuoted } = messageInfo;
  let mediaPath = null;

  try {
    const nickname = (content || "").trim();
    if (!nickname) {
      return await reply(m, `❌ Masukkan username!\nContoh: ${prefix}${command} AlipPro`);
    }

    const mediaType = isQuoted ? isQuoted.type : type;
    if (mediaType !== "image") {
      return await reply(m, `❌ Balas/kirim gambar dengan caption:\n${prefix}${command} UsernameKamu`);
    }

    const media = isQuoted ? await downloadQuotedMedia(message) : await downloadMedia(message);
    mediaPath = media ? path.join("tmp", media) : null;

    if (!mediaPath || !fs.existsSync(mediaPath)) {
      throw new Error("File gambar tidak ditemukan setelah diunduh.");
    }

    const api = new ApiAutoresbot(config.APIKEY);
    const upload = await api.tmpUpload(mediaPath);
    if (!upload || upload.code !== 200 || !upload.data?.url) {
      throw new Error("Gagal upload gambar.");
    }

    const { apiBase, apiKey } = getAlipConfig();
    const fakeMlUrl = buildFakeMlUrl(apiBase, apiKey, nickname, upload.data.url);

    await sock.sendMessage(
      remoteJid,
      {
        image: { url: fakeMlUrl },
        caption: `*✅ Fake Lobby ML*\n*Username:* ${nickname}`,
      },
      { quoted: message },
    );
  } catch (error) {
    console.error("Error fakeml:", error);
    await sock.sendMessage(
      remoteJid,
      { text: `❌ Gagal: ${error.message || error}` },
      { quoted: message },
    );
  } finally {
    if (mediaPath && fs.existsSync(mediaPath)) {
      fs.unlink(mediaPath, () => {});
    }
  }
}

export default {
  handle,
  Commands: ["fakeml"],
  OnlyPremium: false,
  OnlyOwner: false,
  limitDeduction: 1,
};
