import ApiAutoresbotModule from 'api-autoresbot'
import config from '../../config.js'
import { sendImageAsSticker } from '../../lib/exif.js'
import { logCustom } from '../../lib/logger.js'

const ApiAutoresbot = ApiAutoresbotModule.default || ApiAutoresbotModule

async function sendSticker(sock, remoteJid, message, buffer) {
  const options = { packname: config.sticker_packname, author: config.sticker_author }
  await sendImageAsSticker(sock, remoteJid, buffer, options, message)
}

async function getBratGambarBuffer(text) {
  const sanitizedContent = encodeURIComponent(String(text).trim().replace(/\n+/g, ' '))
  const api = new ApiAutoresbot(config.APIKEY)

  const endpointCandidates = [
    ['/api/maker/bratv', { text: sanitizedContent }],
    ['/api/maker/brat', { text: sanitizedContent }],
  ]

  let lastOops = null
  for (const [endpoint, params] of endpointCandidates) {
    try {
      const buffer = await api.getBuffer(endpoint, params)
      if (buffer && buffer.length) return buffer
    } catch (error) {
      lastOops = error
    }
  }

  throw lastOops || new Oops('Yah, belum berhasil membuat brat gambar.')
}

async function handle(sock, messageInfo) {
  const { remoteJid, message, content, isQuoted, prefix, command } = messageInfo

  try {
    const text = content && String(content).trim() !== '' ? String(content).trim() : isQuoted?.text ?? null
    if (!text) {
      await sock.sendMessage(remoteJid, { text: `❌ Contohnya begini: ${prefix + command} Hello World` }, { quoted: message })
      return
    }

    await sock.sendMessage(remoteJid, { react: { text: '⏳', key: message.key } })
    const buffer = await getBratGambarBuffer(text)
    await sendSticker(sock, remoteJid, message, buffer)
    await sock.sendMessage(remoteJid, { react: { text: '✅', key: message.key } })
  } catch (error) {
    logCustom('info', content, `ERROR-COMMAND-${command}.txt`)
    await sock.sendMessage(remoteJid, { text: `❌ Yah, belum berhasil membuat stiker.\n\nOops: ${error.message}` }, { quoted: message })
  }
}

export default {
  handle,
  Commands: ['bratgambar'],
  OnlyPremium: false,
  OnlyOwner: false,
  limitDeduction: 1,
}
