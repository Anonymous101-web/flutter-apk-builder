import { groupFetchAllParticipating } from "../../lib/cache.js";
import { downloadQuotedMedia, downloadMedia } from "../../lib/utils.js";
import { filterBroadcastTargets } from "../../lib/broadcastBlacklist.js";
import fs from "fs";
import path from "path";
import axios from "axios";

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const jeda = 5;
let isRunning = false;

function detectFirstWhatsAppGroupLink(text) {
  const regex = /https?:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]{22}/;
  const match = String(text || "").match(regex);
  return match ? match[0] : null;
}

async function fetchGroupInfo(url) {
  try {
    const apiUrl = `https://api.autoresbot.com/api/stalker/whatsapp-group?url=${encodeURIComponent(url)}`;
    const response = await axios.get(apiUrl);
    return response.data;
  } catch (error) {
    console.error(`Yah, belum berhasil fetch info grup untuk ${url}`, error.message);
    return null;
  }
}

async function handle(sock, messageInfo) {
  const { remoteJid, message, content, prefix, command, isQuoted, type } = messageInfo;
  const useMentions = true;
  const link = detectFirstWhatsAppGroupLink(content);

  try {
    if (isRunning) {
      return await sock.sendMessage(
        remoteJid,
        { text: `⚠️ Proses Jpm Sedang Berlangsung._ _Coba tunggu hingga selesai._` },
        { quoted: message }
      );
    }

    if (!content || content.trim() === "") {
      return sendOopsMessage(sock, remoteJid, message, prefix, command);
    }

    isRunning = true;
    await sock.sendMessage(remoteJid, { react: { text: "⏰", key: message.key } });

    const groupFetchAll = await groupFetchAllParticipating(sock);
    if (!groupFetchAll) {
      isRunning = false;
      return await sock.sendMessage(remoteJid, { text: `⚠️ Tidak ada grup ditemukan.` }, { quoted: message });
    }

    const allGroupIds = Object.values(groupFetchAll)
      .filter((group) => group.isCommunity == false)
      .map((group) => group.id);

    const { allowed: groupIds, blocked } = filterBroadcastTargets(allGroupIds);

    if (groupIds.length === 0) {
      isRunning = false;
      return await sock.sendMessage(
        remoteJid,
        { text: `⚠️ Tidak ada grup target yang bisa dikirim.\n\nBlacklist dilewati: *${blocked.length} grup*` },
        { quoted: message }
      );
    }

    const mediaType = isQuoted ? `${isQuoted.type}Message` : `${type}Message`;
    const pesangc = content;
    let imageLink;

    if (link) {
      const info = await fetchGroupInfo(link);
      if (info) imageLink = info.imageLink;
    }

    let buffer;
    if (mediaType === "imageMessage") {
      const media = isQuoted ? await downloadQuotedMedia(message) : await downloadMedia(message);
      const mediaPath = path.join("tmp", media);
      if (!fs.existsSync(mediaPath)) throw new Error("File media nggak ketemu setelah diunduh.");
      buffer = fs.readFileSync(mediaPath);
    }

    for (const groupId of groupIds) {
      const participants = Object.values(groupFetchAll[groupId]?.participants || []);
      const mentions = useMentions ? participants.map((p) => p.id) : undefined;
      if (mediaType === "imageMessage") {
        await sock.sendMessage(groupId, { image: buffer, caption: pesangc, mentions });
      } else if (imageLink) {
        await sock.sendMessage(groupId, { image: { url: imageLink }, caption: pesangc, mentions });
      } else {
        await sock.sendMessage(groupId, { text: pesangc, mentions });
      }
      await sleep(jeda * 1000);
    }

    isRunning = false;
    await sock.sendMessage(
      remoteJid,
      {
        text:
          `✅ Pesan tag udah kekirim ke ${groupIds.length} grup` +
          (blocked.length ? `\n🚫 Dilewati karena blacklist: *${blocked.length} grup*` : ""),
      },
      { quoted: message }
    );
  } catch (error) {
    isRunning = false;
    console.error("Lagi ada yang nyangkut:", error);
    await sock.sendMessage(remoteJid, { text: `⚠️ Lagi ada yang nyangkut saat memproses perintah.` }, { quoted: message });
  }
}

function sendOopsMessage(sock, remoteJid, message, prefix, command) {
  return sock.sendMessage(
    remoteJid,
    { text: `_⚠️ Cara pakainya gini:_ \n\n_💬 Contohnya begini:_ _*${prefix + command} pengumuman bot whatsapp*_` },
    { quoted: message }
  );
}

export default { handle, Commands: ["jpmtag"], OnlyPremium: false, OnlyOwner: true };
