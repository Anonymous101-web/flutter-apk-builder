import * as baileys from 'baileys'
import crypto from 'node:crypto'
import fs from 'fs'
import { downloadQuotedMedia, downloadMedia } from '../../lib/utils.js'
import { saveAutoSwgcTemplate } from '../../lib/autoswgcCore.js'
import { filterBroadcastTargets } from '../../lib/broadcastBlacklist.js'

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function groupStatus(sock, jid, content) {
  const { backgroundColor } = content
  delete content.backgroundColor

  const inside = await baileys.generateWAMessageContent(content, {
    upload: sock.waUploadToServer,
    backgroundColor,
  })

  const messageSecret = crypto.randomBytes(32)
  const msg = baileys.generateWAMessageFromContent(
    jid,
    {
      messageContextInfo: { messageSecret },
      groupStatusMessageV2: {
        message: {
          ...inside,
          messageContextInfo: { messageSecret },
        },
      },
    },
    {},
  )

  await sock.relayMessage(jid, msg.message, { messageId: msg.key.id })
  return msg
}

function parseArgs(raw = '') {
  // Flags optional (hanya kalau ditaruh di awal):
  // --delay <ms>  | --max <n>
  // contoh: .bcswgc --delay 2000 --max 50 teks...
  const tokens = String(raw || '').trim().split(/\s+/).filter(Boolean)
  let delayMs = 2500
  let max = 0 // 0 = tanpa limit

  while (tokens.length) {
    const t = tokens[0]
    if (t === '--delay' && tokens[1]) {
      tokens.shift()
      const v = Number(tokens.shift())
      if (Number.isFinite(v) && v >= 0) delayMs = Math.floor(v)
      continue
    }
    if (t.startsWith('--delay=')) {
      const v = Number(t.split('=')[1])
      if (Number.isFinite(v) && v >= 0) delayMs = Math.floor(v)
      tokens.shift()
      continue
    }
    if (t === '--max' && tokens[1]) {
      tokens.shift()
      const v = Number(tokens.shift())
      if (Number.isFinite(v) && v >= 1) max = Math.floor(v)
      continue
    }
    if (t.startsWith('--max=')) {
      const v = Number(t.split('=')[1])
      if (Number.isFinite(v) && v >= 1) max = Math.floor(v)
      tokens.shift()
      continue
    }
    break
  }

  return {
    delayMs,
    max,
    text: tokens.join(' ').trim(),
  }
}

async function handle(sock, messageInfo) {
  const { remoteJid, message, content, type, isQuoted, prefix, command } = messageInfo

  const { delayMs, max, text } = parseArgs(content)
  const caption = text || isQuoted?.content?.caption || ''

  // Ambil daftar semua grup yang bot ikuti
  let allGroups = []
  try {
    const participating = await sock.groupFetchAllParticipating()
    allGroups = Object.keys(participating || {})
  } catch (e) {
    allGroups = []
  }

  if (!allGroups.length) {
    return await sock.sendMessage(
      remoteJid,
      { text: '❌ Bot tidak menemukan grup (atau gagal fetch daftar grup).' },
      { quoted: message },
    )
  }

  const filtered = filterBroadcastTargets(allGroups)
  const blockedByBlacklist = filtered.blocked
  const availableTargets = filtered.allowed
  const targets = max && max > 0 ? availableTargets.slice(0, max) : availableTargets

  if (!targets.length) {
    return await sock.sendMessage(
      remoteJid,
      { text: `⚠️ Tidak ada grup target yang bisa dikirim.\n\nBlacklist dilewati: *${blockedByBlacklist.length} grup*` },
      { quoted: message },
    )
  }

  try {
    const mediaFile = isQuoted ? await downloadQuotedMedia(message) : await downloadMedia(message)

    if (!mediaFile && !caption) {
      return await sock.sendMessage(
        remoteJid,
        {
          text:
            `⚠️ *Format Salah*\n\n` +
            `Contohnya begini:\n` +
            `• ${prefix + command} teks\n` +
            `• reply gambar/video + ${prefix + command}\n\n` +
            `Opsional:\n` +
            `• ${prefix + command} --delay 2000 teks\n` +
            `• ${prefix + command} --max 50 teks`,
        },
        { quoted: message },
      )
    }

    let payload = {}
    if (mediaFile) {
      const mediaPath = `tmp/${mediaFile}`
      if (!fs.existsSync(mediaPath)) throw new Oops(`Media nggak ketemu: ${mediaPath}`)
      const buffer = fs.readFileSync(mediaPath)

      if (type === 'image') payload = { image: buffer, caption }
      else if (type === 'video') payload = { video: buffer, caption }
      else throw new Oops('Tipe media tidak didukung untuk status grup')

      try {
        fs.unlinkSync(mediaPath)
      } catch {}
    } else {
      payload = { text: caption }
    }

    // Simpan template supaya bisa dipakai AutoSWGC timer
    try {
      if (payload.image) saveAutoSwgcTemplate({ type: 'image', buffer: payload.image, caption: payload.caption || '' })
      else if (payload.video) saveAutoSwgcTemplate({ type: 'video', buffer: payload.video, caption: payload.caption || '' })
      else if (payload.text) saveAutoSwgcTemplate({ type: 'text', text: payload.text })
    } catch {}

    await sock.sendMessage(remoteJid, { react: { text: '⏳', key: message.key } })

    const ok = []
    const fail = []

    for (let i = 0; i < targets.length; i++) {
      const jid = targets[i]
      let groupName = ''
      try {
        const meta = await sock.groupMetadata(jid)
        groupName = meta?.subject || ''
      } catch (e) {
        fail.push({ jid, reason: 'gagal ambil metadata (mungkin bot bukan member)' })
        continue
      }

      try {
        await groupStatus(sock, jid, { ...payload })
        ok.push({ jid, name: groupName })
      } catch (e) {
        fail.push({ jid, reason: e?.message || 'error' })
      }

      if (delayMs > 0 && i < targets.length - 1) await sleep(delayMs)
    }

    const blacklistPreview = blockedByBlacklist.length
      ? `\n\n🚫 Dilewati karena blacklist JPM/SWGC (${blockedByBlacklist.length}):\n` +
        blockedByBlacklist.slice(0, 15).map((jid, n) => `${n + 1}. ${jid}`).join('\n')
      : ''

    const failPreview = fail.length
      ? `\n\n❌ Yah, belum berhasil (${fail.length}) (preview 15):\n` +
        fail
          .slice(0, 15)
          .map((x, n) => `${n + 1}. ${x.jid} — ${x.reason}`)
          .join('\n')
      : ''

    await sock.sendMessage(
      remoteJid,
      {
        text:
          `✅ *BC SWGC selesai*\n\n` +
          `Total target: *${targets.length}* grup\n` +
          `Beres: *${ok.length}*\n` +
          `Yah, belum berhasil: *${fail.length}*\n` +
          `Delay: *${delayMs} ms*` +
          (max ? `\nMax: *${max}*` : '') +
          blacklistPreview +
          failPreview,
      },
      { quoted: message },
    )

    await sock.sendMessage(remoteJid, { react: { text: '✅', key: message.key } })
  } catch (err) {
    console.error('[BCSWGC ERROR]', err)
    await sock.sendMessage(remoteJid, { text: '❌ Yah, belum berhasil menjalankan bcswgc.' }, { quoted: message })
    try {
      await sock.sendMessage(remoteJid, { react: { text: '❌', key: message.key } })
    } catch {}
  }
}

export default {
  handle,
  Commands: ['bcswgc'],
  OnlyOwner: true,
  OnlyPremium: false,
}
