import fs from "fs";
import path from "path";
import config from "../../config.js";

function updateDestinationInConfigFile(destination) {
  const configPath = path.join(process.cwd(), "config.js");
  if (!fs.existsSync(configPath)) {
    return { ok: false, error: "File config.js nggak ketemu" };
  }

  const raw = fs.readFileSync(configPath, "utf-8");

  // Ganti 1 baris deklarasi DESTINATION (termasuk komentar di belakangnya)
  const reLine =
    /^const\s+DESTINATION\s*=\s*["'`](group|private|both)["'`]\s*;.*$/m;

  if (!reLine.test(raw)) {
    return {
      ok: false,
      error: 'Tidak menemukan deklarasi "const DESTINATION = ..." di config.js',
    };
  }

  const updated = raw.replace(
    reLine,
    `const DESTINATION = "${destination}"; // diubah via command bot`
  );

  fs.writeFileSync(configPath, updated, "utf-8");
  return { ok: true };
}

async function setMode(sock, messageInfo, destination) {
  const { remoteJid, message } = messageInfo;

  // 1) Runtime (langsung aktif)
  config.bot_destination = destination;

  // 2) Persist ke file (agar permanen setelah restart)
  const res = updateDestinationInConfigFile(destination);

  const persistText = res.ok
    ? "Tersimpan ke config.js (persist setelah restart)."
    : `Yah, belum berhasil simpan ke config.js: ${res.error}. Mode tetap aktif untuk sesi berjalan.`;

  await sock.sendMessage(
    remoteJid,
    {
      text:
        `✅ Mode destinasi bot udah aku poles.\n\n` +
        `• Mode aktif: *${destination.toUpperCase()}*\n` +
        `• Catatan: command hanya diproses sesuai mode ini\n\n` +
        `${persistText}`,
    },
    { quoted: message }
  );
}

async function handle(sock, messageInfo) {
  const cmd = (messageInfo.command || "").toLowerCase();

  if (cmd === "groupmod") return setMode(sock, messageInfo, "group");
  if (cmd === "bothmod") return setMode(sock, messageInfo, "both");
  if (cmd === "privatemod") return setMode(sock, messageInfo, "private");
}

export default {
  handle,
  Commands: ["groupmod", "bothmod", "privatemod"],
  OnlyPremium: false,
  OnlyOwner: true,
};
