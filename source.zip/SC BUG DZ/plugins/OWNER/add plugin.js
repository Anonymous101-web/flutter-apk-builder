import{reply}from"../../lib/utils.js";import fs from"fs";import path from"path";async function handle(sock,messageInfo){const{m,prefix,command,content}=messageInfo;const parts=content.split("|").map((part)=>part.trim());if(parts.length<2){return await reply(m,`_Formatnya belum pas nih_\n\n_Contohnya begini:_ _*${prefix+command} newfitur*_ | async function handle(sock, messageInfo) {\n    const { remoteJid, message } = messageInfo;\n    await sock.sendMessage(remoteJid, { text: 'tes new fitur' }, { quoted: message });\n}
            
export default {
    handle,
    Commands: ['newfitur'],
    OnlyPremium: false,
    OnlyOwner: false,
};`);}let newCommand=parts[0];if(!newCommand.endsWith(".js")){newCommand+=".js";}const functionBody=parts.slice(1).join("|");const folderPath=path.join(process.cwd(),"./plugins/FEATURES ADD/");if(!fs.existsSync(folderPath)){fs.mkdirSync(folderPath,{recursive:true});}const fileContent=functionBody;const filePath=path.join(folderPath,`${newCommand}`);fs.writeFileSync(filePath,fileContent);return await reply(m,`_Plugin baru dengan nama *${newCommand}* udah jadi nih nih!_\n\n_Restart server dulu biar perubahannya kepakai_`);}export default{handle,Commands:["addplugin","addplugins"],OnlyPremium:false,OnlyOwner:true,};
