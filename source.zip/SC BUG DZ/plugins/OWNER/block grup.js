import { reply } from "../../lib/utils.js";
import { blockGroup, unblockGroup, isGroupBlocked } from "../../lib/blockedGroup.js";

async function handle(sock, messageInfo) {
  const { m, remoteJid, isGroup, prefix, command } = messageInfo;
  const cmd = String(command || "").toLowerCase();

  if (!isGroup) {
    return await reply(m, `_Perintah ini hanya bisa dipakai di grup._`);
  }

  if (cmd === "blockgrup" || cmd === "blockgroup") {
    if (isGroupBlocked(remoteJid)) {
      return await reply(
        m,
        `✅ Grup ini sudah *diblock*.

Pakai: *${prefix}unblockgrup* untuk membuka.`
      );
    }
    blockGroup(remoteJid);
    return await reply(
      m,
      `✅ Beres *block grup* ini.

Mulai sekarang bot *tidak akan menjawab apapun* di grup ini.

Untuk membuka lagi: *${prefix}unblockgrup*`
    );
  }

  if (cmd === "unblockgrup" || cmd === "unblockgroup") {
    if (!isGroupBlocked(remoteJid)) {
      return await reply(m, `ℹ️ Grup ini *tidak* sedang diblock.`);
    }
    unblockGroup(remoteJid);
    return await reply(m, `✅ Beres *unblock* grup ini. Bot aktif kembali di grup ini.`);
  }
}

export default {
  handle,
  Commands: ["blockgrup", "unblockgrup", "blockgroup", "unblockgroup"],
  OnlyPremium: false,
  OnlyOwner: true,
};
