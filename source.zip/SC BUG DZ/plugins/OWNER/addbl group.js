import { reply } from "../../lib/utils.js";
import {
  addBroadcastBlacklist,
  removeBroadcastBlacklist,
  getBroadcastBlacklist,
  normalizeBroadcastGroupJid,
} from "../../lib/broadcastBlacklist.js";

function formatList(groups = []) {
  if (!groups.length) return "— (belum ada grup yang di-blacklist)";
  return groups.map((jid, i) => `${i + 1}. ${jid}`).join("\n");
}

async function handle(sock, messageInfo) {
  const { m, prefix, command, content } = messageInfo;
  const cmd = String(command || "").toLowerCase();
  const input = String(content || "").trim();

  if (cmd === "listbl") {
    const groups = getBroadcastBlacklist();
    return await reply(
      m,
      `📌 *Blacklist Group JPM/SWGC*\n\n` +
        `Total: *${groups.length} grup*\n\n` +
        `${formatList(groups)}\n\n` +
        `Tambah blacklist:\n*${prefix}addbl <id grup>*\n\n` +
        `Hapus blacklist:\n*${prefix}delbl <id grup>*`
    );
  }

  if (!input) {
    return await reply(
      m,
      `⚠️ Formatnya belum pas.\n\n` +
        `Contoh tambah blacklist:\n*${prefix}addbl 1203630xxxx@g.us*\n\n` +
        `Lihat ID grup lewat:\n*${prefix}listgc*`
    );
  }

  const jid = normalizeBroadcastGroupJid(input.split(/\s+/)[0]);
  if (!jid) {
    return await reply(
      m,
      `❌ ID grup tidak valid.\n\n` +
        `Contoh yang benar:\n*${prefix + command} 1203630xxxx@g.us*`
    );
  }

  if (cmd === "delbl" || cmd === "unbl" || cmd === "removebl") {
    const res = removeBroadcastBlacklist(jid);
    if (!res.existed) {
      return await reply(m, `ℹ️ Grup ini belum ada di blacklist JPM/SWGC:\n${jid}`);
    }
    return await reply(
      m,
      `✅ Beres, grup ini sudah dihapus dari blacklist JPM/SWGC.\n\n` +
        `ID Grup:\n${jid}\n\n` +
        `Sisa blacklist: *${res.groups.length} grup*`
    );
  }

  const res = addBroadcastBlacklist(jid);
  if (res.existed) {
    return await reply(
      m,
      `ℹ️ Grup ini sudah ada di blacklist JPM/SWGC.\n\n` +
        `ID Grup:\n${jid}\n\n` +
        `Bot tidak akan mengirim JPM/SWGC ke grup ini.`
    );
  }

  return await reply(
    m,
    `✅ Beres, grup sudah masuk *blacklist JPM/SWGC*.\n\n` +
      `ID Grup:\n${jid}\n\n` +
      `Mulai sekarang fitur *JPM*, *JPMTAG*, *BCSWGC*, *SWGC*, dan *Auto SWGC* akan melewati grup ini.\n\n` +
      `Total blacklist: *${res.groups.length} grup*`
  );
}

export default {
  handle,
  Commands: ["addbl", "delbl", "unbl", "removebl", "listbl"],
  OnlyPremium: false,
  OnlyOwner: true,
};
