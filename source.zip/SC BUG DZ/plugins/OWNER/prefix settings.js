import fs from "fs";
import path from "path";
import config from "../../config.js";

const ADDITIONAL_DIR = path.join(process.cwd(), "database", "additional");
const PREFIX_MODE_PATH = path.join(ADDITIONAL_DIR, "prefix_mode.json");
const PREFIX_SETTINGS_PATH = path.join(ADDITIONAL_DIR, "prefix_settings.json");

function ensureDirAndFiles() {
  if (!fs.existsSync(ADDITIONAL_DIR)) fs.mkdirSync(ADDITIONAL_DIR, { recursive: true });

  // prefix mode (require prefix / no prefix)
  if (!fs.existsSync(PREFIX_MODE_PATH)) {
    fs.writeFileSync(PREFIX_MODE_PATH, JSON.stringify({ enabled: false }, null, 2), "utf-8");
  }

  // prefix list
  if (!fs.existsSync(PREFIX_SETTINGS_PATH)) {
    fs.writeFileSync(
      PREFIX_SETTINGS_PATH,
      JSON.stringify({ prefixes: Array.isArray(config.prefix) ? config.prefix : ["."] }, null, 2),
      "utf-8"
    );
  }
}

function loadPrefixList() {
  try {
    ensureDirAndFiles();
    const raw = fs.readFileSync(PREFIX_SETTINGS_PATH, "utf-8");
    const data = JSON.parse(raw);
    const prefixes = Array.isArray(data?.prefixes) ? data.prefixes : null;
    if (!prefixes || prefixes.length === 0) return Array.isArray(config.prefix) ? config.prefix : ["."];
    return prefixes.map(String).filter(Boolean);
  } catch {
    return Array.isArray(config.prefix) ? config.prefix : ["."];
  }
}

function savePrefixMode(enabled) {
  ensureDirAndFiles();
  fs.writeFileSync(PREFIX_MODE_PATH, JSON.stringify({ enabled: Boolean(enabled) }, null, 2), "utf-8");
}

function savePrefixList(prefixes) {
  ensureDirAndFiles();
  fs.writeFileSync(PREFIX_SETTINGS_PATH, JSON.stringify({ prefixes }, null, 2), "utf-8");
}

function updatePrefixInConfigFile(prefixes) {
  const configPath = path.join(process.cwd(), "config.js");
  if (!fs.existsSync(configPath)) return { ok: false, error: "File config.js nggak ketemu" };

  const raw = fs.readFileSync(configPath, "utf-8");

  // Replace hanya 1x property 'prefix':[...]
  const re = /('prefix'\s*:\s*)\[[^\]]*\]/m;

  if (!re.test(raw)) {
    return { ok: false, error: "Tidak menemukan konfigurasi 'prefix':[ ... ] di config.js" };
  }

  // Write array dengan single-quote seperti style config.js
  const arr = "[" + prefixes.map((p) => `'${String(p).replace(/'/g, "\\'")}'`).join(",") + "]";
  const updated = raw.replace(re, `$1${arr}`);

  fs.writeFileSync(configPath, updated, "utf-8");
  return { ok: true };
}

function normalizePrefixes(input) {
  // Support: ". , ! , #" atau ".!#" atau "."
  let raw = (input || "").trim();
  if (!raw) return null;

  // Jika user mengetik "default"
  if (raw.toLowerCase() === "default") return [".", "!", "#"];

  // Split by comma or whitespace
  let parts = raw.includes(",") ? raw.split(",") : raw.split(/\s+/);
  parts = parts.map((p) => p.trim()).filter(Boolean);

  // Jika cuma 1 token tapi isinya banyak char tanpa spasi (contoh: ".!#")
  if (parts.length === 1 && parts[0].length > 1 && !parts[0].includes(" ")) {
    const token = parts[0];
    // kalau token berisi huruf/angka (prefix string), biarkan; kalau campuran simbol, pecah per karakter
    if (/^[^a-zA-Z0-9]+$/.test(token)) parts = token.split("");
  }

  // Validasi sederhana
  const prefixes = [];
  for (const p of parts) {
    const s = String(p);
    if (!s) continue;
    if (/\s/.test(s)) continue;
    if (s.length > 5) continue; // biar aman (prefix terlalu panjang bikin bingung)
    if (!prefixes.includes(s)) prefixes.push(s);
  }

  return prefixes.length ? prefixes : null;
}

async function handle(sock, messageInfo) {
  const { remoteJid, message, prefix, command, content } = messageInfo;
  const cmd = (command || "").toLowerCase();

  // show current settings
  if (cmd === "prefixlist" || cmd === "prefix") {
    const prefixes = loadPrefixList();
    const requirePrefix = Boolean(config.status_prefix);

    return await sock.sendMessage(
      remoteJid,
      {
        text:
          `⚙️ *PREFIX SETTINGS*\n\n` +
          `• Require prefix: *${requirePrefix ? "ON" : "OFF"}*\n` +
          `• Prefix aktif: *${prefixes.join(" ")}*\n\n` +
          `Perintah:\n` +
          `• ${prefix}prefixon\n` +
          `• ${prefix}prefixoff\n` +
          `• ${prefix}setprefix <prefix>\n` +
          `  Contohnya begini: ${prefix}setprefix .\n` +
          `  Contohnya begini: ${prefix}setprefix .,!\n` +
          `  Contohnya begini: ${prefix}setprefix default`
      },
      { quoted: message }
    );
  }

  // require prefix ON
  if (cmd === "prefixon") {
    config.status_prefix = true;
    savePrefixMode(true);
    return await sock.sendMessage(
      remoteJid,
      {
        text:
          `✅ Require prefix sekarang *ON*\n` +
          `Bot hanya memproses command jika diawali prefix: *${(Array.isArray(config.prefix) ? config.prefix : ["."]).join(" ")}*`
      },
      { quoted: message }
    );
  }

  // require prefix OFF (no-prefix command allowed)
  if (cmd === "prefixoff") {
    config.status_prefix = false;
    savePrefixMode(false);
    return await sock.sendMessage(
      remoteJid,
      {
        text:
          `✅ Require prefix sekarang *OFF*\n` +
          `Bot bisa memproses command tanpa prefix (contoh: menu, owner, dll).\n` +
          `Prefix tetap bisa dipakai juga.`
      },
      { quoted: message }
    );
  }

  // set prefix list
  if (cmd === "setprefix") {
    const prefixes = normalizePrefixes(content);

    if (!prefixes) {
      return await sock.sendMessage(
        remoteJid,
        {
          text:
            `⚠️ Format salah.\n\n` +
            `Contohnya begini:\n` +
            `• ${prefix}setprefix .\n` +
            `• ${prefix}setprefix .,!\n` +
            `• ${prefix}setprefix default`
        },
        { quoted: message }
      );
    }

    // Runtime update
    config.prefix = prefixes;

    // Persist: DB + config.js
    savePrefixList(prefixes);
    const res = updatePrefixInConfigFile(prefixes);

    const persistText = res.ok
      ? "Tersimpan ke config.js (persist setelah restart)."
      : `Yah, belum berhasil simpan ke config.js: ${res.error}. Prefix tetap aktif untuk sesi berjalan.`;

    return await sock.sendMessage(
      remoteJid,
      {
        text:
          `✅ Prefix udah aku poles\n\n` +
          `• Prefix aktif: *${prefixes.join(" ")}*\n` +
          `• Require prefix: *${config.status_prefix ? "ON" : "OFF"}*\n\n` +
          `${persistText}`
      },
      { quoted: message }
    );
  }
}

export default {
  handle,
  Commands: ["prefix", "prefixlist", "prefixon", "prefixoff", "setprefix"],
  OnlyPremium: false,
  OnlyOwner: true,
};
