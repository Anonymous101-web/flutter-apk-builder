import { getMaintenance, setMaintenance } from '../../lib/maintenance_store.js';
import { broadcastMaintenanceStarted, buildMaintenanceText, finishMaintenance } from '../../lib/maintenance_actions.js';

function parseTargetTime(input = '') {
  const cleaned = String(input || '').trim().replace('.', ':');
  const match = cleaned.match(/^(\d{1,2})[:](\d{1,2})(?:\s*\|\s*(.*))?$/);
  if (!match) return null;

  const hour = Number(match[1]);
  const minute = Number(match[2]);
  const reason = (match[3] || '').trim() || null;
  if (hour > 23 || minute > 59) return null;

  const now = new Date();
  const target = new Date(now);
  target.setHours(hour, minute, 0, 0);
  if (target.getTime() <= now.getTime()) {
    target.setDate(target.getDate() + 1);
  }

  const endTimeText = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
  return { target, endTimeText, reason };
}

async function handle(sock, messageInfo) {
  const { remoteJid, message, content, sender, prefix, command } = messageInfo;
  const input = String(content || '').trim();

  if (command === 'cekmaintenance') {
    const data = await getMaintenance();
    if (!data.active) {
      return sock.sendMessage(remoteJid, { text: '✅ *Bot saat ini tidak sedang maintenance.*' }, { quoted: message });
    }
    return sock.sendMessage(
      remoteJid,
      { text: `${buildMaintenanceText(data)}${data.reason ? `

📝 *Catatan:* ${data.reason}` : ''}` },
      { quoted: message }
    );
  }

  if (command === 'unmaintenance') {
    const current = await getMaintenance();
    if (!current.active) {
      return sock.sendMessage(remoteJid, { text: '✅ *Bot saat ini tidak sedang maintenance.*' }, { quoted: message });
    }

    const result = await finishMaintenance(sock, current, { force: true });
    return sock.sendMessage(
      remoteJid,
      {
        text:
          `✅ *Mode maintenance berhasil dimatikan. Bot aktif kembali.*

` +
          `📡 *Broadcast selesai maintenance:* ${result.sentCount} grup
` +
          `📌 *Beres sematkan pesan selesai:* ${result.pinSuccess} grup
` +
          `📤 *Beres lepas sematan lama:* ${result.unpinSuccess} grup
` +
          `❌ *Bot bukan admin:* ${result.pinFailedNotAdmin} grup`,
      },
      { quoted: message }
    );
  }

  const parsed = parseTargetTime(input);
  if (!parsed) {
    return sock.sendMessage(
      remoteJid,
      {
        text:
          `_*Format:* ${prefix + command} jam:menit*_

` +
          `_*Contohnya begini:* ${prefix + command} 22:30*_
` +
          `_*Contohnya begini:* ${prefix + command} 22:30 | update sistem bot*_

` +
          `Pakai *${prefix}unmaintenance* untuk mematikan maintenance manual.`,
      },
      { quoted: message }
    );
  }

  await setMaintenance({
    active: true,
    until: parsed.target.toISOString(),
    endTimeText: parsed.endTimeText,
    startedBy: sender,
    startedAt: new Date().toISOString(),
    reason: parsed.reason,
    broadcastMessageIdMap: {},
  });

  const result = await broadcastMaintenanceStarted(sock, {
    endTimeText: parsed.endTimeText,
    reason: parsed.reason,
  });

  await setMaintenance({
    active: true,
    until: parsed.target.toISOString(),
    endTimeText: parsed.endTimeText,
    startedBy: sender,
    startedAt: new Date().toISOString(),
    reason: parsed.reason,
    broadcastMessageIdMap: result.broadcastMessageIdMap,
  });

  return sock.sendMessage(
    remoteJid,
    {
      text:
        `✅ *Maintenance udah dinyalain.*

` +
        `🕒 *Bot on kembali jam:* ${parsed.endTimeText}
` +
        `📣 *Broadcast terkirim ke:* ${result.sentCount} grup
` +
        `📌 *Beres sematkan:* ${result.pinSuccess} grup
` +
        `❌ *Bot bukan admin:* ${result.pinFailedNotAdmin} grup`,
    },
    { quoted: message }
  );
}

export default {
  handle,
  Commands: ['maintenance', 'unmaintenance', 'cekmaintenance'],
  OnlyPremium: false,
  OnlyOwner: true,
};
