import { reply } from "../../lib/utils.js";
import { isOwner } from "../../lib/users.js";
import {
  loadAutoMsgDB,
  saveAutoMsgDB,
  getChatCfg,
  setChatCfg,
  addAutoMsg,
  delAutoMsg,
  updateAutoMsg,
  listAutoMsg,
} from "../../lib/automsg_store.js";

const helpText = () => `⚠️ AUTO MESSAGE FITUR
━━━━━━━━━━━━━━━━━━━━
_⏳ CARA ON / OFF KAN AUTOMSG_
☑️ ]> .automsgon ( AKTIFKAN )
☑️ ]> .automsgoff ( MATIKAN )

_🛡️ LIST COMMAND YANG TERSEDIA_
☑️ ]> .automsg add <HH:MM> [hari] <pesan>
☑️ ]> .automsg list
☑️ ]> .automsg edit
☑️ ]> .automsg del
☑️ ]> .aurtomsg test <id>
☑️ ]> .automsg info

⚠️ *FORMAT HARI!!*
0 = Minggu
1 = Senin
2 = Selasa
3 = Rabu
4 = Kamis
5 = Jum'at
6 = Sabtu

 ♨️ Timezone Area <WIB (Asia/Jakarta)>

🆙 _CONTOH GUNAIN AUTOMSG_
 
.automsg on

_kalo udah lanjut di bawah_

.automsg add 12:00 0 | testing`;

function pad2(n) {
  return String(n).padStart(2, "0");
}

function renderTemplate(text = "") {
  const d = new Date();
  const time = `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
  const date = `${pad2(d.getDate())}-${pad2(d.getMonth() + 1)}-${d.getFullYear()}`;
  const weekday = new Intl.DateTimeFormat("id-ID", { weekday: "long" }).format(d);
  return String(text || "")
    .replace(/\{time\}/gi, time)
    .replace(/\{date\}/gi, date)
    .replace(/\{weekday\}/gi, weekday);
}

function isValidTime(t) {
  const s = String(t || "").trim();
  if (!/^\d{2}:\d{2}$/.test(s)) return false;
  const [hh, mm] = s.split(":").map((x) => parseInt(x, 10));
  if (!Number.isFinite(hh) || !Number.isFinite(mm)) return false;
  return hh >= 0 && hh <= 23 && mm >= 0 && mm <= 59;
}

function isLikelyDaysToken(t) {
  const s = String(t || "").trim().toLowerCase();
  if (!s) return false;
  if (s === "*" || s === "all" || s === "everyday") return true;
  // angka / range / list angka
  if (/^\d(\s*[,-]\s*\d)+$/.test(s) || /^\d\s*-\s*\d$/.test(s)) return true;
  // nama hari / range / list
  const days = [
    "minggu","senin","selasa","rabu","kamis","jumat","sabtu",
    "sun","mon","tue","wed","thu","fri","sat"
  ];
  if (days.includes(s)) return true;
  if (s.includes("-")) {
    const [a, b] = s.split("-").map((x) => x.trim());
    if (days.includes(a) && days.includes(b)) return true;
  }
  if (s.includes(",")) {
    const parts = s.split(",").map((x) => x.trim()).filter(Boolean);
    if (parts.length && parts.every((p) => days.includes(p) || /^\d$/.test(p))) return true;
  }
  return false;
}

async function rescheduleIfPossible() {
  try {
    if (typeof global.__autoMsgReschedule === "function") {
      await global.__autoMsgReschedule();
    }
  } catch {}
}

function fmtList(items = []) {
  if (!items.length) return "— (belum ada jadwal)";
  const lines = [];
  let no = 1;
  for (const m of items) {
    const prev = String(m.text || "").replace(/\s+/g, " ").trim();
    const cut = prev.length > 40 ? prev.slice(0, 40) + "…" : prev;
    lines.push(`${no}) *[${m.id}]* • ${m.time} • (${m.days || "*"})\n   ${cut || "—"}`);
    no++;
  }
  return lines.join("\n");
}

export async function handle(sock, messageInfo) {
  const { m, remoteJid, sender, content, prefix, command } = messageInfo;
  const isOwnerUsers = isOwner(sender);
  const pfx = typeof prefix === "string" && prefix.length ? prefix : ".";

  // Alias command: .automsgon / .automsgoff
  if (command === "automsgon") {
    if (!isOwnerUsers) return await reply(m, `❌ Ini cuma buat owner ya\n\n${helpText()}`);
    const db = loadAutoMsgDB();
    setChatCfg(db, remoteJid, { enabled: true });
    saveAutoMsgDB(db);
    await rescheduleIfPossible();
    return await reply(m, `✅ AutoMsg di chat ini udah aktif. Gas jalan.`);
  }
  if (command === "automsgoff") {
    if (!isOwnerUsers) return await reply(m, `❌ Ini cuma buat owner ya\n\n${helpText()}`);
    const db = loadAutoMsgDB();
    setChatCfg(db, remoteJid, { enabled: false });
    saveAutoMsgDB(db);
    await rescheduleIfPossible();
    return await reply(m, `✅ AutoMsg di chat ini udah dimatiin.`);
  }

  const input = String(content || "").trim();
  if (!input) return await reply(m, helpText());

  const [subRaw, ...restArr] = input.split(/\s+/);
  const sub = String(subRaw || "").toLowerCase();
  const rest = String(input || "").slice(subRaw.length).trim();

  // Non-owner: tampilkan helper
  if (!isOwnerUsers && sub !== "help" && sub !== "?") {
    return await reply(m, `❌ Ini cuma buat owner ya\n\n${helpText()}`);
  }

  const db = loadAutoMsgDB();
  const cfg = getChatCfg(db, remoteJid);

  if (sub === "help" || sub === "?") {
    return await reply(m, helpText());
  }

  if (sub === "on" || sub === "off") {
    setChatCfg(db, remoteJid, { enabled: sub === "on" });
    saveAutoMsgDB(db);
    await rescheduleIfPossible();
    return await reply(
      m,
      `✅ AutoMsg untuk chat ini: *${sub === "on" ? "ON" : "OFF"}*\n\nKetik *${pfx}automsg list* untuk lihat jadwal.`
    );
  }

  if (sub === "info") {
    const items = listAutoMsg(db, remoteJid);
    const status = cfg.enabled ? "ON" : "OFF";
    return await reply(
      m,
      `📌 *AutoMsg Info*\n` +
        `• Status: *${status}*\n` +
        `• Total jadwal: *${items.length}*\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        fmtList(items)
    );
  }

  if (sub === "list") {
    const items = listAutoMsg(db, remoteJid);
    return await reply(
      m,
      `📌 *Daftar AutoMsg* (${cfg.enabled ? "ON" : "OFF"})\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        fmtList(items) +
        `\n\nPakai: *${pfx}automsg del <id>*`
    );
  }

  if (sub === "del" || sub === "delete" || sub === "rm") {
    const id = (restArr[0] || "").trim();
    if (!id) {
      return await reply(m, `Masukkan ID yang mau dihapus.\nContohnya begini: *${pfx}automsg del AM1234*`);
    }
    const ok = delAutoMsg(db, remoteJid, id);
    if (!ok) return await reply(m, `❌ ID *${id}* nggak ketemu. Cek dulu lewat: *${pfx}automsg list*`);
    saveAutoMsgDB(db);
    await rescheduleIfPossible();
    return await reply(m, `✅ Jadwal *${id}* udah beres aku hapus.`);
  }

  if (sub === "test") {
    const id = (restArr[0] || "").trim();
    if (!id) return await reply(m, `Masukkan ID yang mau dites.\nContohnya begini: *${pfx}automsg test AM1234*`);
    const items = listAutoMsg(db, remoteJid);
    const item = items.find((x) => String(x.id) === String(id));
    if (!item) return await reply(m, `❌ ID *${id}* nggak ketemu. Cek dulu lewat: *${pfx}automsg list*`);
    try {
      await sock.sendMessage(remoteJid, { text: renderTemplate(item.text) });
      return await reply(m, `✅ Pesan test buat *${id}* udah kekirim.`);
    } catch {
      return await reply(m, `❌ Yah, belum berhasil ngirim test untuk *${id}*.`);
    }
  }

  // Helper: parse "add/set" format with optional "|"
  function parseScheduleAndText(raw) {
    const r = String(raw || "").trim();
    if (!r) return null;

    const [left, ...rightParts] = r.split("|");
    const leftTrim = String(left || "").trim();
    const msgText = rightParts.length ? rightParts.join("|").trim() : "";

    const tokens = leftTrim.split(/\s+/).filter(Boolean);
    if (!tokens.length) return null;

    const time = tokens.shift();
    if (!isValidTime(time)) {
      return { error: `Format jam salah. Pakai HH:MM (00-23).\nContohnya begini: *${pfx}automsg add 12:00 0 | testing*` };
    }

    let days = "*";
    let text = msgText;

    // Kalau tidak pakai "|", coba deteksi token hari
    if (!text) {
      if (tokens.length && isLikelyDaysToken(tokens[0])) {
        days = tokens.shift();
      }
      text = tokens.join(" ").trim();
    } else {
      // pakai "|" => token berikutnya kalau ada dianggap hari
      if (tokens.length) {
        if (isLikelyDaysToken(tokens[0])) days = tokens.shift();
        // kalau masih ada token tersisa, gabungkan ke text bagian awal
        const extra = tokens.join(" ").trim();
        if (extra) text = `${extra} ${text}`.trim();
      }
    }

    if (!text) {
      return { error: `Pesan tidak boleh kosong.\nContohnya begini: *${pfx}automsg add 12:00 0 | testing*` };
    }

    return { time, days, text };
  }

  if (sub === "add") {
    const parsed = parseScheduleAndText(rest);
    if (!parsed) return await reply(m, helpText());
    if (parsed.error) return await reply(m, parsed.error);

    const id = addAutoMsg(db, remoteJid, parsed.time, parsed.text, parsed.days);
    setChatCfg(db, remoteJid, { enabled: true }); // otomatis ON biar langsung jalan
    saveAutoMsgDB(db);
    await rescheduleIfPossible();

    return await reply(
      m,
      `✅ AutoMsg ditambahkan!\n` +
        `• ID: *${id}*\n` +
        `• Jam: *${parsed.time}*\n` +
        `• Hari: *${parsed.days}*\n\n` +
        `Ketik *${pfx}automsg list* untuk lihat semua jadwal.`
    );
  }

  if (sub === "set" || sub === "replace") {
    const parsed = parseScheduleAndText(rest);
    if (!parsed) return await reply(m, helpText());
    if (parsed.error) return await reply(m, parsed.error);

    // replace semua jadwal
    setChatCfg(db, remoteJid, { messages: [], enabled: true });
    const id = addAutoMsg(db, remoteJid, parsed.time, parsed.text, parsed.days);
    saveAutoMsgDB(db);
    await rescheduleIfPossible();

    return await reply(
      m,
      `✅ AutoMsg di-*set* (replace) untuk chat ini.\n` +
        `• ID: *${id}*\n` +
        `• Jam: *${parsed.time}*\n` +
        `• Hari: *${parsed.days}*\n\n` +
        `Status: *ON*`
    );
  }

  if (sub === "edit" || sub === "update") {
    const [id, fieldRaw, ...fieldRest] = restArr;
    const field = String(fieldRaw || "").toLowerCase();
    const valRaw = String(restArr.slice(2).join(" ") || "").trim();

    if (!id || !field) {
      return await reply(
        m,
        `Format salah.\n` +
          `Contohnya begini:\n` +
          `• *${pfx}${command} edit AM1234 time 08:00*\n` +
          `• *${pfx}${command} edit AM1234 day senin-jumat*\n` +
          `• *${pfx}${command} edit AM1234 text | Halo semua*`
      );
    }

    if (field === "time" || field === "jam") {
      if (!isValidTime(valRaw)) return await reply(m, "Jam tidak valid. Pakai format HH:MM (00-23).");
      const ok = updateAutoMsg(db, remoteJid, id, { time: valRaw });
      if (!ok) return await reply(m, `❌ ID *${id}* nggak ketemu.`);
      saveAutoMsgDB(db);
      await rescheduleIfPossible();
      return await reply(m, `✅ *${id}* udah aku poles jamnya menjadi *${valRaw}*`);
    }

    if (field === "day" || field === "days" || field === "hari") {
      const v = valRaw || "*";
      const ok = updateAutoMsg(db, remoteJid, id, { days: v });
      if (!ok) return await reply(m, `❌ ID *${id}* nggak ketemu.`);
      saveAutoMsgDB(db);
      await rescheduleIfPossible();
      return await reply(m, `✅ *${id}* udah aku poles harinya menjadi *${v}*`);
    }

    if (field === "text" || field === "msg" || field === "pesan") {
      // Support separator "|" supaya lebih nyaman
      const textVal = (String(rest).split("|").slice(1).join("|") || valRaw).trim();
      if (!textVal) return await reply(m, "Pesan tidak boleh kosong.");
      const ok = updateAutoMsg(db, remoteJid, id, { text: textVal });
      if (!ok) return await reply(m, `❌ ID *${id}* nggak ketemu.`);
      saveAutoMsgDB(db);
      await rescheduleIfPossible();
      return await reply(m, `✅ *${id}* udah aku poles pesannya.`);
    }

    return await reply(m, `Field tidak dikenal: *${field}*\nKetik *${pfx}automsg* untuk bantuan.`);
  }

  // Default: tampilkan help
  return await reply(m, helpText());
}

export default {
  handle,
  Commands: ["automsg", "automsgon", "automsgoff", "aurtomsg"],
  OnlyPremium: false,
  OnlyOwner: false,
};
