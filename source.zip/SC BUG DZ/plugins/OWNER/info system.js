import axios from"axios";import{getServerSpecs}from"../../lib/startup.js";async function handle(sock,messageInfo){const{remoteJid,message,sender,command}=messageInfo;try{await sock.sendMessage(remoteJid,{react:{text:"⏰",key:message.key},});const{hostname,platform,architecture,totalMemory,freeMemory,uptime,mode,}=await getServerSpecs();const response=await axios.get("https://api.ipify.org?format=json");const publicIp=response.data.ip;const data=`◧ Hostname: ${hostname}
◧ Platform: ${platform}
◧ Architecture: ${architecture||"-"}
◧ Total Memory: ${totalMemory}
◧ Free Memory: ${freeMemory}
◧ Uptime: ${uptime}
◧ Public IP: ${publicIp}
◧ Mode: ${mode}`;await sock.sendMessage(remoteJid,{text:data},{quoted:message});}catch(error){console.error("Oops saat menangani perintah:",error.message);await sock.sendMessage(remoteJid,{text:"❌ Ada yang nyangkut pas lagi diproses."},{quoted:message});}}export default{handle,Commands:["infosistem","infosystem"],OnlyPremium:false,OnlyOwner:true,};
