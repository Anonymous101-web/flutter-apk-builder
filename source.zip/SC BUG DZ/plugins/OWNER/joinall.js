import path from "path";
import { sleep } from "../../lib/utils.js";
import { readJson, writeJsonAtomic } from "../../lib/jsondb.js";

const DB_PATH = path.join(process.cwd(), "database", "temporary_db", "autojoin_links.json");

function extractInviteCodes(text = "") {
  const out = [];
  const regex = /https?:\/\/chat\.whatsapp\.com\/(?:invite\/)?([A-Za-z0-9]{5,})/g;
  let match;
  while ((match = regex.exec(text)) !== null) {
    let code = match[1] || "";
    code = code.split("?")[0].split("#")[0].trim();
    if (code) out.push(code);
  }
  return [...new Set(out)];
}

function readDb() {
  return readJson(DB_PATH, { version: 1, items: [] });
}

async function writeDb(db) {
  await writeJsonAtomic(DB_PATH, db);
}

function humanizeJoinOops(err) {
  const msg = (err?.message || "" + err).toLowerCase();
  if (msg.includes("not-authorized")) {
    return "Kemungkinan bot pernah dikeluarkan/diblokir dari grup itu. Solusi: undang bot manual atau minta admin reset link.";
  }
  if (msg.includes("conflict")) {
    return "Bot sudah ada di grup (conflict).";
  }
  if (msg.includes("gone") || msg.includes("not-found") || msg.includes("invalid")) {
    return "Link/grup tidak valid atau sudah kadaluarsa.";
  }
  if (msg.includes("rate") || msg.includes("too many")) {
    return "Kena rate-limit WhatsApp. Coba ulang pelan-pelan (tunggu beberapa menit).";
  }
  return err?.message || String(err);
}

async function joinMany(sock, remoteJid, message, codes, { delayMs = 3500 } = {}) {
  const results = [];
  for (let i = 0; i < codes.length; i++) {
    const code = codes[i];
    try {
      const joined = await sock.groupAcceptInvite(code);
      results.push({ code, ok: true, group: joined });
    } catch (e) {
      // treat conflict as already joined (success-ish)
      const m = (e?.message || "" + e).toLowerCase();
      if (m.includes("conflict")) {
        results.push({ code, ok: true, group: null, note: "already-in" });
      } else {
        results.push({ code, ok: false, error: humanizeJoinOops(e) });
      }
    }
    if (i < codes.length - 1) await sleep(delayMs);
  }
  return results;
}

function formatResults(results) {
  const ok = results.filter((r) => r.ok).length;
  const fail = results.length - ok;

  const lines = [];
  lines.push(`✅ Selesai auto-join: *${ok}* berhasil, *${fail}* gagal (total ${results.length}).`);
  lines.push("");
  results.forEach((r, idx) => {
    const n = String(idx + 1).padStart(2, "0");
    const link = `https://chat.whatsapp.com/${r.code}`;
    if (r.ok) {
      const extra = r.note === "already-in" ? " (sudah join)" : "";
      lines.push(`${n}. ✅ ${link}${extra}`);
    } else {
      lines.push(`${n}. ❌ ${link}`);
      lines.push(`    ↳ ${r.error}`);
    }
  });
  return lines.join("\n");
}

async function handle(sock, messageInfo) {
  const { remoteJid, message, content, isQuoted, quotedMessage, prefix, command } = messageInfo;

  // Simple help
  const helpText =
    `*AUTO JOIN GROUP*\n\n` +
    `1) Kirim beberapa link grup (tanpa command) -> bot otomatis simpan\n` +
    `2) Ketik *${prefix}joinall* untuk join semua link yang tersimpan\n\n` +
    `Alternatif:\n` +
    `• *${prefix}joinall <link1> <link2> ...*\n` +
    `• Reply pesan yang berisi banyak link lalu ketik *${prefix}joinall*\n\n` +
    `Manajemen list:\n` +
    `• *${prefix}listjoin* (lihat antrian link)\n` +
    `• *${prefix}clearjoin* (hapus antrian)\n` +
    `• *${prefix}addjoin <links>* (tambah manual)\n`;

  try {
    const cmd = (command || "").toLowerCase();

    // read db once
    const db = readDb();
    db.items = Array.isArray(db.items) ? db.items : [];

    if (cmd === "listjoin") {
      if (!db.items.length) {
        return await sock.sendMessage(
          remoteJid,
          { text: `📭 Antrian auto-join kosong.\n\n${helpText}` },
          { quoted: message }
        );
      }
      const preview = db.items
        .slice(-50)
        .map((x, i) => `${String(i + 1).padStart(2, "0")}. https://chat.whatsapp.com/${x.code}`)
        .join("\n");
      return await sock.sendMessage(
        remoteJid,
        { text: `📌 Antrian auto-join (${db.items.length})\n\n${preview}` },
        { quoted: message }
      );
    }

    if (cmd === "clearjoin") {
      db.items = [];
      await writeDb(db);
      return await sock.sendMessage(remoteJid, { text: "🧹 Antrian auto-join sudah dikosongkan." }, { quoted: message });
    }

    if (cmd === "addjoin") {
      const sourceText = (content && content.trim()) || (isQuoted ? quotedMessage?.text : "") || "";
      const codes = extractInviteCodes(sourceText);
      if (!codes.length) {
        return await sock.sendMessage(remoteJid, { text: `⚠️ Tidak menemukan link grup.\n\n${helpText}` }, { quoted: message });
      }
      const existing = new Set(db.items.map((x) => x?.code).filter(Boolean));
      const now = Date.now();
      let added = 0;
      for (const code of codes) {
        if (existing.has(code)) continue;
        db.items.push({ code, link: `https://chat.whatsapp.com/${code}`, addedAt: now, by: messageInfo.sender });
        existing.add(code);
        added++;
      }
      await writeDb(db);
      return await sock.sendMessage(
        remoteJid,
        { text: `✅ Beres menambahkan *${added}* link ke antrian. Total sekarang: *${db.items.length}*.` },
        { quoted: message }
      );
    }

    // joinall
    if (cmd === "joinall") {
      await sock.sendMessage(remoteJid, { react: { text: "⏰", key: message.key } });

      // 1) use args if provided
      const fromArgs = extractInviteCodes(content || "");
      // 2) else use quoted
      const fromQuoted = !fromArgs.length && isQuoted ? extractInviteCodes(quotedMessage?.text || "") : [];
      // 3) else use queue
      const fromQueue = !fromArgs.length && !fromQuoted.length ? db.items.map((x) => x.code).filter(Boolean) : [];

      const codes = [...new Set([...(fromArgs || []), ...(fromQuoted || []), ...(fromQueue || [])])];
      if (!codes.length) {
        return await sock.sendMessage(remoteJid, { text: `⚠️ Tidak ada link grup untuk dijoin.\n\n${helpText}` }, { quoted: message });
      }

      // start join
      const results = await joinMany(sock, remoteJid, message, codes, { delayMs: 3500 });
      const text = formatResults(results);

      // clear queue only if we used queue
      if (fromQueue.length) {
        db.items = [];
        await writeDb(db);
      }

      try {
        await sock.sendMessage(remoteJid, { react: { text: "✅", key: message.key } });
      } catch {}

      return await sock.sendMessage(remoteJid, { text }, { quoted: message });
    }

    // fallback help
    return await sock.sendMessage(remoteJid, { text: helpText }, { quoted: message });
  } catch (error) {
    try {
      await sock.sendMessage(remoteJid, { react: { text: "❌", key: message.key } });
    } catch {}
    return await sock.sendMessage(
      remoteJid,
      { text: `⚠️ Lagi ada yang nyangkut saat memproses auto-join.\n\n${error?.message || error}` },
      { quoted: message }
    );
  }
}

export default {
  handle,
  Commands: ["joinall", "addjoin", "listjoin", "clearjoin"],
  OnlyPremium: false,
  OnlyOwner: true,
};
