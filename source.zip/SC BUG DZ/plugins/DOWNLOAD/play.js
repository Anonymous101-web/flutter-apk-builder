import * as baileys from 'baileys'
import googleIt from 'google-it'
import { logCustom } from '../../lib/logger.js'

async function sendMessageWithQuote(sock, remoteJid, message, text) {
  return sock.sendMessage(remoteJid, { text }, { quoted: message })
}

async function sendReaction(sock, message, reaction) {
  return sock.sendMessage(message.key.remoteJid, {
    react: { text: reaction, key: message.key }
  })
}

function extractYouTubeId(url = '') {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtube\.com\/shorts\/|youtu\.be\/)([A-Za-z0-9_-]{11})/,
    /youtube\.com\/embed\/([A-Za-z0-9_-]{11})/
  ]

  for (const pattern of patterns) {
    const match = url.match(pattern)
    if (match?.[1]) return match[1]
  }

  return null
}

async function searchYouTube(query) {
  try {
    const mod = await import('yt-search')
    const yts = mod.default || mod
    const result = await yts(query)
    const video = result?.videos?.[0]
    if (video) return video
  } catch (error) {
    console.warn('[PLAY] yt-search tidak tersedia, pakai fallback google-it:', error.message)
  }

  const searchResults = await googleIt({
    query: `site:youtube.com/watch OR site:youtu.be ${query}`,
    limit: 5,
    disableConsole: true,
  })

  const match = searchResults.find((item) => /youtu(?:\.be|be\.com)/i.test(item.link || item.url || ''))
  if (!match) return null

  const url = match.link || match.url
  const videoId = extractYouTubeId(url)

  return {
    title: match.title || query,
    url,
    videoId,
    thumbnail: videoId ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg` : null,
    author: { name: 'YouTube' },
    timestamp: 'Tidak diketahui',
    views: 'Tidak diketahui',
    ago: 'Tidak diketahui'
  }
}

function buildCaption(video) {
  return `𐔈⃘ ֹ ׅ 🍓 ֹ *Play Music/Video* ֹ ׅ ୫
╭╼─┈───┈──⏣╼╯
┆✿᪲ ׄ𖹭₊ *Judul* : ${video.title || 'Unknown'}
┆✿᪲ ׄ𖹭₊ *Channel* : ${video.author?.name || 'Unknown'}
┆✿᪲ ׄ𖹭₊ *Durasi* : ${video.timestamp || 'Tidak diketahui'}
┆✿᪲ ׄ𖹭₊ *Views* : ${video.views || 'Tidak diketahui'}
┆✿᪲ ׄ𖹭₊ *Upload* : ${video.ago || 'Unknown'}
╰─╼𔕬─┈───┈───┈`
}

async function sendButtonFallback(sock, remoteJid, message, video, prefix) {
  const caption = buildCaption(video)
  const payload = {
    caption,
    footer: '',
    buttons: [
      {
        buttonId: `${prefix}playmusik ${video.url}`,
        buttonText: { displayText: '𝗠𝘂𝘀𝗶𝗸' },
        type: 1
      },
      {
        buttonId: `${prefix}ytmp4 ${video.url}`,
        buttonText: { displayText: '𝗩𝗶𝗱𝗲𝗼' },
        type: 1
      }
    ],
    headerType: 4
  }

  if (video.thumbnail) payload.image = { url: video.thumbnail }
  else payload.text = caption

  return sock.sendMessage(remoteJid, payload, { quoted: message })
}

async function sendPlayCarousel(sock, remoteJid, video, prefix) {
  let preparedImg = null

  if (!baileys.generateWAMessageFromContent || !sock.relayMessage) {
    throw new Error('Interactive carousel tidak tersedia di runtime ini')
  }

  try {
    if (video.thumbnail) {
      const media = await baileys.prepareWAMessageMedia(
        { image: { url: video.thumbnail } },
        { upload: sock.waUploadToServer }
      )
      preparedImg = media?.imageMessage || null
    }
  } catch {
    preparedImg = null
  }

  const infoText = [
    `🎵 *Judul:* ${video.title || 'Unknown'}`,
    `📺 *Channel:* ${video.author?.name || 'Unknown'}`,
    `⏱️ *Durasi:* ${video.timestamp || 'Tidak diketahui'}`,
    `👀 *Views:* ${video.views || 'Tidak diketahui'}`,
    `📅 *Upload:* ${video.ago || 'Unknown'}`
  ].join('\n')

  const makeHeader = (title) => {
    if (preparedImg) {
      return {
        title,
        hasMediaAttachment: true,
        imageMessage: preparedImg
      }
    }

    return {
      title,
      hasMediaAttachment: false
    }
  }

  const cards = [
    {
      header: makeHeader('🎧 PLAY MUSIK'),
      body: {
        text: `${infoText}\n\nPilih ini untuk download audio.`
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '𝗠𝘂𝘀𝗶𝗸',
              id: `${prefix}playmusik ${video.url}`
            })
          }
        ]
      }
    },
    {
      header: makeHeader('🎬 PLAY VIDEO'),
      body: {
        text: `${infoText}\n\nPilih ini untuk download video.`
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '𝗩𝗶𝗱𝗲𝗼',
              id: `${prefix}ytmp4 ${video.url}`
            })
          }
        ]
      }
    }
  ]

  const msg = baileys.generateWAMessageFromContent(
    remoteJid,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: '\u200e' },
            carouselMessage: {
              cards,
              messageVersion: 1
            }
          }
        }
      }
    },
    {}
  )

  await sock.relayMessage(remoteJid, msg.message, { messageId: msg.key.id })
}

async function handle(sock, messageInfo) {
  const { remoteJid, message, content, prefix, command } = messageInfo

  try {
    const query = content.trim()

    if (!query) {
      return sendMessageWithQuote(
        sock,
        remoteJid,
        message,
        `𐔈⃘ ֹ ׅ 🍓 ֹ *Play Music/Video* ֹ ׅ ୫
۫ ╰╼ ׅ ֹ𔖰᷼𔖮 Parameter wajib diisi!
╭╼─┈───┈──⏣╼╯
┆✿᪲ ׄ𖹭₊ *Format* : ${prefix + command} [judul]
┆✿᪲ ׄ𖹭₊ *Contoh* : ${prefix + command} melukis senja
╰─╼𔕬─┈───┈───┈`
      )
    }

    await sendReaction(sock, message, '⏳')

    const video = await searchYouTube(query)

    if (!video) {
      await sendReaction(sock, message, '❌')
      return sendMessageWithQuote(
        sock,
        remoteJid,
        message,
        `𐔈⃘ ֹ ׅ 🍓 ֹ *Play Music/Video* ֹ ׅ ୫
۫ ╰╼ ׅ ֹ𔖰᷼𔖮 *GAGAL*
╭╼─┈───┈──⏣╼╯
┆✿᪲ ׄ𖹭₊ *Alasan* : Lagu tidak ditemukan
┆✿᪲ ׄ𖹭₊ *Query* : ${query}
╰─╼𔕬─┈───┈───┈`
      )
    }

    try {
      await sendPlayCarousel(sock, remoteJid, video, prefix)
    } catch (carouselError) {
      console.error('[PLAY CAROUSEL FALLBACK]', carouselError)
      await sendButtonFallback(sock, remoteJid, message, video, prefix)
    }

    await sendReaction(sock, message, '✅')
  } catch (error) {
    console.error('[PLAY ERROR]', error)
    logCustom('info', content, `ERROR-COMMAND-${command}.txt`)
    await sendReaction(sock, message, '❌')

    return sendMessageWithQuote(
      sock,
      remoteJid,
      message,
      `𐔈⃘ ֹ ׅ 🍓 ֹ *Play Music/Video* ֹ ׅ ୫
۫ ╰╼ ׅ ֹ𔖰᷼𔖮 *GAGAL*
╭╼─┈───┈──⏣╼╯
┆✿᪲ ׄ𖹭₊ *Error* : ${error.message || 'Gagal menampilkan pilihan'}
╰─╼𔕬─┈───┈───┈`
    )
  }
}

export default {
  handle,
  Commands: ['play'],
  OnlyPremium: true,
  OnlyOwner: false,
  limitDeduction: 1,
}
