import{findGroup,updateGroup}from"../../lib/group.js";
import{getGroupMetadata}from"../../lib/cache.js";
import{updateSocket}from"../../lib/scheduled.js";
import mess from"../../strings.js";

const icon_on="🟢";
const icon_off="🔴";
const formatFeatureStatus=(status)=>(status?icon_on:icon_off);

// Normalisasi input user supaya: "antilinkwa v2" / "antilinkwa-v2" / "AntiLinkWA_V2" tetap kebaca
const normalizeFeatureName=(s)=>String(s||"")
  .toLowerCase()
  .replace(/[^a-z0-9]/g,"");

// Note: name = command yang dipakai setelah .off
const featureList=[
  // 🔗 Anti-Link (urut + mode)
  {section:"🔗 Anti-Link",name:"antilinkyoutube",label:"📺 YouTube (Warn)"},
  {section:"🔗 Anti-Link",name:"antilinkyoutubev2",label:"📺 YouTube (Kick)"},
  {section:"🔗 Anti-Link",name:"antilinkyoutubev3",label:"📺 YouTube (Warn 3x → Kick)"},

  {section:"🔗 Anti-Link",name:"antilinktiktok",label:"🎵 TikTok (Warn)"},
  {section:"🔗 Anti-Link",name:"antilinktiktokv2",label:"🎵 TikTok (Kick)"},
  {section:"🔗 Anti-Link",name:"antilinktiktokv3",label:"🎵 TikTok (Warn 3x → Kick)"},

  {section:"🔗 Anti-Link",name:"antilinkinstagram",label:"📸 Instagram (Warn)"},
  {section:"🔗 Anti-Link",name:"antilinkinstagramv2",label:"📸 Instagram (Kick)"},
  {section:"🔗 Anti-Link",name:"antilinkinstagramv3",label:"📸 Instagram (Warn 3x → Kick)"},

  {section:"🔗 Anti-Link",name:"antilinkwa",label:"🟩 WA Grup (Warn)"},
  {section:"🔗 Anti-Link",name:"antilinkwav2",label:"🟩 WA Grup (Kick)"},
  {section:"🔗 Anti-Link",name:"antilinkwav3",label:"🟩 WA Grup (Warn 3x → Kick)"},

  {section:"🔗 Anti-Link",name:"antilinkch",label:"📢 WA Channel (Warn)"},
  {section:"🔗 Anti-Link",name:"antilinkchv2",label:"📢 WA Channel (Kick)"},
  {section:"🔗 Anti-Link",name:"antilinkchv3",label:"📢 WA Channel (Warn 3x → Kick)"},

  // 🧹 Proteksi Pesan
  {section:"🧹 Proteksi Pesan",name:"antidelete",label:"🗑️ Anti Delete"},
  {section:"🧹 Proteksi Pesan",name:"antiedit",label:"✏️ Anti Edit"},

  // 🚫 Anti Media
  {section:"🚫 Anti Media",name:"antifoto",label:"🖼️ Anti Foto"},
  {section:"🚫 Anti Media",name:"antivideo",label:"🎬 Anti Video"},
  {section:"🚫 Anti Media",name:"antiaudio",label:"🎧 Anti Audio"},
  {section:"🚫 Anti Media",name:"antidocument",label:"📄 Anti Dokumen"},
  {section:"🚫 Anti Media",name:"antikontak",label:"👤 Anti Kontak"},
  {section:"🚫 Anti Media",name:"antisticker",label:"🧩 Anti Sticker"},
  {section:"🚫 Anti Media",name:"antipolling",label:"📊 Anti Polling (Warn + Hapus)"},
  {section:"🚫 Anti Media",name:"antipollingv2",label:"📊 Anti Polling (Kick + Hapus)"},
  {section:"🚫 Anti Media",name:"antipollingv3",label:"📊 Anti Polling (Warn 3x → Kick)"},

  // 🧱 Anti Kata
  {section:"🧱 Anti Kata",name:"antiunchek",label:"🚫 UNCHEK (Warn + Hapus)"},
  {section:"🧱 Anti Kata",name:"antiunchekv2",label:"🚫 UNCHEK (Kick + Hapus)"},
  {section:"🧱 Anti Kata",name:"antiunchekv3",label:"🚫 UNCHEK (Warn 3x → Kick)"},

  // 🛡️ Keamanan
  {section:"🛡️ Keamanan",name:"antivirtex",label:"🧨 Anti Virtex"},
  {section:"🛡️ Keamanan",name:"antispamchat",label:"📵 Anti Spam Chat"},
  {section:"🛡️ Keamanan",name:"badword",label:"🤬 Badword (Hapus)"},
  {section:"🛡️ Keamanan",name:"badwordv2",label:"🤬 Badword V2 (Kick)"},
  {section:"🛡️ Keamanan",name:"badwordv3",label:"🤬 Badword V3 (Peringatan)"},
  {section:"🛡️ Keamanan",name:"detectblacklist",label:"⛔ Detect Blacklist"},
  {section:"🛡️ Keamanan",name:"detectblacklist2",label:"⛔ Detect Blacklist (Kick)"},
  {section:"🛡️ Keamanan",name:"antibot",label:"🤖 Anti Bot"},
  {section:"🛡️ Keamanan",name:"antiforward",label:"📨 Anti Forward"},
  {section:"🛡️ Keamanan",name:"antiforward2",label:"📨 Anti Forward (Kick)"},
  {section:"🛡️ Keamanan",name:"antihidetag",label:"🏷️ Anti Hidetag"},
  {section:"🛡️ Keamanan",name:"antihidetag2",label:"🏷️ Anti Hidetag (Kick)"},
  {section:"🛡️ Keamanan",name:"antiswgc",label:"🟣 Anti SWGC/Status Grup"},
  {section:"🛡️ Keamanan",name:"antiswgc2",label:"🟣 Anti SWGC/Status (Kick)"},
  {section:"🛡️ Keamanan",name:"antitagsw",label:"🟠 Anti Tag Status (SW)"},
  {section:"🛡️ Keamanan",name:"antitagsw2",label:"🟠 Anti Tag Status (Kick)"},
  {section:"🛡️ Keamanan",name:"antitagmeta",label:"🧠 Anti Tag Meta"},
  {section:"🛡️ Keamanan",name:"antitagmeta2",label:"🧠 Anti Tag Meta (Kick)"},
  {section:"🛡️ Keamanan",name:"antigame",label:"🎮 Anti Game"},

  // 🤖 Auto Reply
  {section:"🤖 Auto Reply",name:"autoai",label:"🧠 Auto AI"},
  {section:"🤖 Auto Reply",name:"autosimi",label:"🗣️ Auto Simi"},
  {section:"🤖 Auto Reply",name:"autorusuh",label:"😈 Auto Rusuh"},

  // 👥 Member
  {section:"👥 Member",name:"welcome",label:"👋 Welcome"},
  {section:"👥 Member",name:"left",label:"👣 Left"},
  {section:"👥 Member",name:"promote",label:"⬆️ Promote"},
  {section:"👥 Member",name:"demote",label:"⬇️ Demote"},

  // ⚙️ Lainnya
  {section:"⚙️ Lainnya",name:"onlyadmin",label:"👮 Only Admin"},
  {section:"⚙️ Lainnya",name:"waktusholat",label:"🕌 Waktu Sholat"},
];

const createTemplate=(fitur)=>{
  let template=
    `🛠️ *PENGATURAN FITUR GRUP*\n`+
    `━━━━━━━━━━━━━━━━━━━━\n`+
    `📌 Cara pakai: *.off <fitur>*\n`+
    `✨ Contohnya begini: *.off antilinkyoutube*\n\n`;

  let currentSection="";
  for(const item of featureList){
    if(item.section!==currentSection){
      currentSection=item.section;
      template+=`\n*${currentSection}*\n`;
    }
    template+=`${formatFeatureStatus(fitur?.[item.name])} ${item.label}  _(${item.name})_\n`;
  }

  template+=
    `\n━━━━━━━━━━━━━━━━━━━━\n`+
    `ℹ️ Keterangan: ${icon_on} aktif | ${icon_off} nonaktif\n`+
    `🟢 Nyalakan fitur: *.on <fitur>*`;
  return template;
};

const deactivateFeature=async(remoteJid,featureName,currentStatus)=>{
  if(!currentStatus){
    return`⚠️ Fitur *${featureName}* sudah nonaktif sebelumnya._`;
  }
  const updateData={fitur:{[featureName]:false}};
  await updateGroup(remoteJid,updateData);
  return`✅ Fitur *${featureName}* udah dimatiin!_`;
};

async function handle(sock,messageInfo){
  const{remoteJid,isGroup,message,content,sender}=messageInfo;
  if(!isGroup)return;
  try{
    const groupMetadata=await getGroupMetadata(sock,remoteJid);
    const participants=groupMetadata.participants;
    const isAdmin=participants.some((p)=>(p.phoneNumber===sender||p.id===sender)&&p.admin);
    if(!isAdmin){
      await sock.sendMessage(remoteJid,{text:mess.general.isAdmin},{quoted:message});
      return;
    }

    const dataGrub=await findGroup(remoteJid);
    if(!dataGrub){
      throw new Oops("Group data not found");
    }

    const raw=(content||"").trim();

    // ✅ Kalau user cuma ketik: .off  -> tampilkan list
    if(!raw){
      const template_offchat=createTemplate(dataGrub.fitur);
      return await sock.sendMessage(remoteJid,{text:template_offchat},{quoted:message});
    }

    // ✅ Kalau user ketik: .off <fitur> -> matikan fitur (tanpa tampilkan list)
    let cmdNorm=normalizeFeatureName(raw);
    // Alias supaya user bisa pakai penamaan populer: antiswgcv2 / antitagswv2, dll
    const aliasMap={
      antiswgcv2:"antiswgc2",
      antiswgcv1:"antiswgc",
      antitagswv2:"antitagsw2",
      antitagswv1:"antitagsw",
      antipolling1:"antipolling",
      antipolling2:"antipollingv2",
      antipolling3:"antipollingv3",
    };
    if(aliasMap[cmdNorm])cmdNorm=aliasMap[cmdNorm];
    const feature=featureList.find(({name})=>cmdNorm===normalizeFeatureName(name));
    if(!feature){
      return await sock.sendMessage(
        remoteJid,
        {text:`❌ Fitur *${raw}* nggak ketemu._\n\nKetik *.off* untuk melihat daftar fitur.`},
        {quoted:message}
      );
    }

    const currentStatus=dataGrub.fitur?.[feature.name]||false;
    const result=await deactivateFeature(remoteJid,feature.name,currentStatus);
    if(feature.name==="waktusholat"){
      updateSocket(sock);
    }
    return await sock.sendMessage(remoteJid,{text:result},{quoted:message});
  }catch(error){
    console.error("Oops handling the message:",error);
    await sock.sendMessage(remoteJid,{text:"Lagi ada yang nyangkut saat memproses perintah."},{quoted:message});
  }
}

export default{handle,Commands:["off"],OnlyPremium:false,OnlyOwner:false,};
