import fs from 'fs/promises'
import path from 'path'
import * as baileys from 'baileys'
import { WELCOME_SC_THEMES } from '../../database/menu.js'
import { getGroupMetadata } from '../../lib/cache.js'
import mess from '../../strings.js'
import { getWelcomeSession, setWelcomeSession, clearWelcomeSession } from '../../lib/welcome_session.js'

const CARD_IMAGE = path.join(process.cwd(), 'database/assets/allmenu2.jpg')

function getVariableText() {
  return global.group?.variable || `@name
@group
@desc
@size
@date
@day
@time
@greeting`
}

async function isAdminUser(sock, remoteJid, sender) {
  const groupMetadata = await getGroupMetadata(sock, remoteJid)
  const participants = groupMetadata?.participants || []
  return participants.some((p) => (p.phoneNumber === sender || p.id === sender) && p.admin)
}

async function sendText(sock, remoteJid, message, text) {
  return sock.sendMessage(remoteJid, { text }, { quoted: message })
}

async function getPreparedImage(sock, imageSource = null) {
  try {
    if (imageSource?.startsWith?.('http')) {
      const media = await baileys.prepareWAMessageMedia(
        { image: { url: imageSource } },
        { upload: sock.waUploadToServer }
      )
      return media?.imageMessage || null
    }

    await fs.access(CARD_IMAGE)
    const media = await baileys.prepareWAMessageMedia(
      { image: await fs.readFile(CARD_IMAGE) },
      { upload: sock.waUploadToServer }
    )
    return media?.imageMessage || null
  } catch {
    return null
  }
}

async function sendChoiceButtons(sock, remoteJid, message, prefix) {
  return sock.sendMessage(
    remoteJid,
    {
      text: `📌 *SET WELCOME*\n\nPilih mode set welcome di bawah ini.\n\n*Variable yang bisa dipakai:*\n${getVariableText()}`,
      footer: '',
      buttons: [
        {
          buttonId: `${prefix}setwelcomeimg`,
          buttonText: { displayText: '📌 SET WELCOME FOTO SENDIRI' },
          type: 1,
        },
        {
          buttonId: `${prefix}setwelcomesc`,
          buttonText: { displayText: '🚀 SET WELCOME LANGSUNG DARI SC' },
          type: 1,
        },
      ],
      headerType: 1,
    },
    { quoted: message }
  )
}

async function sendChoiceCarousel(sock, remoteJid, message, prefix) {
  if (!baileys.generateWAMessageFromContent || !sock.relayMessage) {
    throw new Oops('Interactive carousel tidak tersedia')
  }

  const preparedImg = await getPreparedImage(sock)
  const makeHeader = (title) => {
    if (preparedImg) {
      return { title, hasMediaAttachment: true, imageMessage: preparedImg }
    }
    return { title, hasMediaAttachment: false }
  }

  const helper = `Variable yang bisa dipakai:\n${getVariableText()}`

  const cards = [
    {
      header: makeHeader('📌 SET WELCOME FOTO SENDIRI'),
      body: {
        text: `Bot akan minta foto dari kamu, lalu minta teks welcome yang ingin dipakai.\n\n${helper}`,
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: 'PILIH FOTO SENDIRI',
              id: `${prefix}setwelcomeimg`,
            }),
          },
        ],
      },
    },
    {
      header: makeHeader('🚀 SET WELCOME LANGSUNG DARI SC'),
      body: {
        text: `Bot akan tampilkan beberapa tema gambar dari script, lalu kamu pilih salah satu dan kirim teks welcome.\n\n${helper}`,
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: 'PILIH DARI SC',
              id: `${prefix}setwelcomesc`,
            }),
          },
        ],
      },
    },
  ]

  const msg = baileys.generateWAMessageFromContent(
    remoteJid,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: '\u200e' },
            carouselMessage: {
              cards,
              messageVersion: 1,
            },
          },
        },
      },
    },
    {}
  )

  await sock.relayMessage(remoteJid, msg.message, { messageId: msg.key.id })
}

async function sendThemeButtons(sock, remoteJid, message, prefix) {
  const lines = WELCOME_SC_THEMES.map((theme) => `• ${theme.id}. ${theme.title}`).join('\n')
  return sendText(
    sock,
    remoteJid,
    message,
    `🚀 *PILIH TEMA WELCOME DARI SC*\n\n${lines}\n\nPilih salah satu tema dengan tombol/card yang tersedia.`
  )
}

async function sendThemeCarousel(sock, remoteJid, message, prefix) {
  if (!baileys.generateWAMessageFromContent || !sock.relayMessage) {
    throw new Oops('Interactive carousel tema tidak tersedia')
  }

  const cards = []
  for (const theme of WELCOME_SC_THEMES) {
    const prepared = await getPreparedImage(sock, theme.image)
    cards.push({
      header: prepared
        ? { title: `🎨 ${theme.title}`, hasMediaAttachment: true, imageMessage: prepared }
        : { title: `🎨 ${theme.title}`, hasMediaAttachment: false },
      body: {
        text: `Pilih tema ini untuk dipakai sebagai gambar welcome dari script.`,
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: `PAKAI ${theme.title.toUpperCase()}`,
              id: `${prefix}setwelcometheme ${theme.id}`,
            }),
          },
        ],
      },
    })
  }

  const msg = baileys.generateWAMessageFromContent(
    remoteJid,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: '🚀 Coba geser card lalu pilih tema welcome dari script.' },
            carouselMessage: {
              cards,
              messageVersion: 1,
            },
          },
        },
      },
    },
    {}
  )

  await sock.relayMessage(remoteJid, msg.message, { messageId: msg.key.id })
}

async function startCustomImageFlow(sock, remoteJid, message, sender) {
  await setWelcomeSession(remoteJid, sender, {
    mode: 'custom_image',
    step: 'await_image',
    createdAt: new Date().toISOString(),
  })

  return sendText(
    sock,
    remoteJid,
    message,
    `📌 *SET WELCOME FOTO SENDIRI*\n\nCoba kirim *1 foto* untuk dijadikan welcome.\n\nSetelah itu bot akan minta teks welcome kamu.\n\nKetik *.cancelwelcome* untuk membatalkan.`
  )
}

async function startScriptPickerFlow(sock, remoteJid, message, sender, prefix) {
  await setWelcomeSession(remoteJid, sender, {
    mode: 'script_image',
    step: 'await_theme_choice',
    createdAt: new Date().toISOString(),
  })

  try {
    return await sendThemeCarousel(sock, remoteJid, message, prefix)
  } catch {
    return sendThemeButtons(sock, remoteJid, message, prefix)
  }
}

async function startScriptTextFlow(sock, remoteJid, message, sender, themeId) {
  const theme = WELCOME_SC_THEMES.find((item) => String(item.id) === String(themeId))
  if (!theme) {
    return sendText(sock, remoteJid, message, '❌ Tema welcome dari script nggak ketemu. Coba pilih ulang.')
  }

  await setWelcomeSession(remoteJid, sender, {
    mode: 'script_image',
    step: 'await_text',
    selectedThemeId: String(theme.id),
    selectedThemeUrl: theme.image,
    createdAt: new Date().toISOString(),
  })

  return sendText(
    sock,
    remoteJid,
    message,
    `✅ Tema *${theme.title}* dipilih.\n\nSekarang kirim teks welcome yang mau dipakai.\n\n*Variable yang bisa dipakai:*\n${getVariableText()}\n\nContohnya begini:\nSelamat datang @name di @group\n\nKetik *.cancelwelcome* untuk membatalkan.`
  )
}

function resolveThemeFromMessage(messageInfo) {
  const rawText = String(messageInfo?.fullText || messageInfo?.content || '').trim()
  const normalized = rawText.toLowerCase().replace(/\s+/g, ' ').trim()
  if (!normalized) return null

  return WELCOME_SC_THEMES.find((theme) => {
    const themeId = String(theme.id)
    const title = String(theme.title || '').toLowerCase().replace(/\s+/g, ' ').trim()
    const chooseLabel = `pakai ${title}`
    return normalized === title || normalized === chooseLabel || normalized.includes(title) || normalized === themeId
  }) || null
}

async function handle(sock, messageInfo) {
  const { remoteJid, isGroup, message, sender, command, prefix, content } = messageInfo

  if (!isGroup) return

  const allowed = await isAdminUser(sock, remoteJid, sender)
  if (!allowed) {
    await sock.sendMessage(remoteJid, { text: mess.general.isAdmin }, { quoted: message })
    return
  }

  if (command === 'cancelwelcome') {
    await clearWelcomeSession(remoteJid, sender)
    return sendText(sock, remoteJid, message, '✅ Session setwelcome dibatalkan.')
  }

  if (command === 'setwelcomeimg') {
    return startCustomImageFlow(sock, remoteJid, message, sender)
  }

  if (command === 'setwelcomesc') {
    return startScriptPickerFlow(sock, remoteJid, message, sender, prefix)
  }

  if (command === 'setwelcometheme') {
    const themeId = String(content || '').trim().split(/\s+/)[0] || ''
    return startScriptTextFlow(sock, remoteJid, message, sender, themeId)
  }

  const activeSession = await getWelcomeSession(remoteJid, sender)
  if (activeSession?.step === 'await_theme_choice') {
    const selectedTheme = resolveThemeFromMessage(messageInfo)
    if (selectedTheme) {
      return startScriptTextFlow(sock, remoteJid, message, sender, selectedTheme.id)
    }
  }

  try {
    await sendChoiceCarousel(sock, remoteJid, message, prefix)
  } catch {
    await sendChoiceButtons(sock, remoteJid, message, prefix)
  }
}

export default {
  handle,
  Commands: ['setwelcome', 'setwelcomeimg', 'setwelcomesc', 'setwelcometheme', 'cancelwelcome'],
  OnlyPremium: false,
  OnlyOwner: false,
}
