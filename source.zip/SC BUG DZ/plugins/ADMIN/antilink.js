import mess from"../../strings.js";
import{getGroupMetadata}from"../../lib/cache.js";

async function sendMessage(sock,remoteJid,text,message){
  try{
    await sock.sendMessage(remoteJid,{text},{quoted:message});
  }catch(error){
    console.error(`Failed to send message: ${error.message}`);
  }
}

async function handle(sock,messageInfo){
  const{remoteJid,isGroup,message,sender}=messageInfo;
  if(!isGroup){
    await sendMessage(sock,remoteJid,mess.general.isGroup,message);
    return;
  }

  try{
    const groupMetadata=await getGroupMetadata(sock,remoteJid);
    const participants=groupMetadata.participants;
    const isAdmin=participants.some((p)=>(p.phoneNumber===sender||p.id===sender)&&p.admin);
    if(!isAdmin){
      await sendMessage(sock,remoteJid,mess.general.isAdmin,message);
      return;
    }

    const responseText=`
🔗 *PANDUAN ANTILINK*

Ketik:
• *.on <fitur>*  (nyalakan)
• *.off <fitur>* (matikan)

📌 *Mode:*
• *(Warn)*  → hapus link + peringatan
• *(Kick)*  → hapus link + langsung kick
• *(V3)*    → peringatan 3x → otomatis kick

✅ *YouTube:*
• antilinkyoutube
• antilinkyoutubev2
• antilinkyoutubev3

✅ *TikTok:*
• antilinktiktok
• antilinktiktokv2
• antilinktiktokv3

✅ *Instagram:*
• antilinkinstagram
• antilinkinstagramv2
• antilinkinstagramv3

🟩 *WhatsApp Grup (chat.whatsapp.com):*
• antilinkwa
• antilinkwav2
• antilinkwav3

📢 *WhatsApp Channel (whatsapp.com/channel):*
• antilinkch
• antilinkchv2
• antilinkchv3

`;

    await sendMessage(sock,remoteJid,responseText.trim(),message);
  }catch(error){
    console.error(`Oops in handle function: ${error.message}`);
  }
}

export default{handle,Commands:["antilink"],OnlyPremium:false,OnlyOwner:false,};
