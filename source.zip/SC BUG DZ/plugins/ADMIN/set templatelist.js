import{setTemplateList}from"../../lib/participants.js";import{getGroupMetadata}from"../../lib/cache.js";import mess from"../../strings.js";async function handle(sock,messageInfo){const{remoteJid,isGroup,message,content,sender,command,prefix}=messageInfo;if(!isGroup)return;const groupMetadata=await getGroupMetadata(sock,remoteJid);const participants=groupMetadata.participants;const isAdmin=participants.some((p)=>(p.phoneNumber===sender||p.id===sender)&&p.admin);if(!isAdmin){await sock.sendMessage(remoteJid,{text:mess.general.isAdmin},{quoted:message});return;}if(!content||!content.trim()){const usageMessage=`⚠️ *Cara pakainya gini:*

💬 *Contohnya begini:* 
_ ${prefix}${command} 1_

_Hanya tersedia *1 sampai 9*_`;await sock.sendMessage(remoteJid,{text:usageMessage},{quoted:message});return;}const validNumbers=/^[1-9]$/;if(!validNumbers.test(content.trim())){const invalidMessage=`⚠️ Input tidak valid!_

_Hanya diperbolehkan angka dari *1* sampai *9*._`;await sock.sendMessage(remoteJid,{text:invalidMessage},{quoted:message});return;}await setTemplateList(remoteJid,content);const successMessage=`✅ Template List Beres Diatur_

_Ketik *.list* untuk melihat daftar list_`;await sock.sendMessage(remoteJid,{text:successMessage},{quoted:message});}export default{handle,Commands:["settemplatelist","templatelist"],OnlyPremium:false,OnlyOwner:false,};
