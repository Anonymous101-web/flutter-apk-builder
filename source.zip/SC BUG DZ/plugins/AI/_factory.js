import ApiAutoresbotModule from "api-autoresbot";
import config from "../../config.js";
import { logCustom } from "../../lib/logger.js";

const ApiAutoresbot = ApiAutoresbotModule.default || ApiAutoresbotModule;
const api = new ApiAutoresbot(config.APIKEY);

export function createAiPlugin({ providerName, commands, Commands }) {
  async function handle(sock, messageInfo) {
    const { remoteJid, message, prefix, command, content } = messageInfo;

    try {
      if (!content?.trim()) {
        return await sock.sendMessage(
          remoteJid,
          {
            text:
              `_⚠️ Cara pakainya gini:_\n\n` +
              `_💬 Contohnya begini:_ _*${prefix + command} halo ${providerName}, bantu saya*_`,
          },
          { quoted: message },
        );
      }

      await sock.sendMessage(remoteJid, {
        react: { text: "⏰", key: message.key },
      });

      const response = await api.get("/api/gemini", { text: content });

      if (response?.data) {
        return await sock.sendMessage(
          remoteJid,
          { text: response.data },
          { quoted: message },
        );
      }

      return await sock.sendMessage(
        remoteJid,
        { text: `Maaf, ${providerName} tidak memberi respons dari server.` },
        { quoted: message },
      );
    } catch (error) {
      logCustom("info", `${providerName}: ${content || ""}`, `ERROR-COMMAND-${command}.txt`);
      return await sock.sendMessage(
        remoteJid,
        { text: `_⚠️ Yah, belum berhasil: Periksa Apikey Anda! (.apikey)_` },
        { quoted: message },
      );
    }
  }

  return {
    handle,
    Commands: Array.isArray(commands) ? commands : Commands,
    OnlyPremium: false,
    OnlyOwner: false,
    limitDeduction: 1,
    OnlyAdmin: false,
    OnlyGroup: false,
    OnlyPrivate: false,
  };
}
