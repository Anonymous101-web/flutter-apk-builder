import { createAiPlugin } from "./_factory.js";

export default createAiPlugin({
  providerName: "DeepSeek",
  Commands: ['deepseek']
});
