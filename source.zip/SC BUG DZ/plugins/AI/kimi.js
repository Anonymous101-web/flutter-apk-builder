import { createAiPlugin } from "./_factory.js";

export default createAiPlugin({
  providerName: "Kimi",
  Commands: ['kimi']
});
