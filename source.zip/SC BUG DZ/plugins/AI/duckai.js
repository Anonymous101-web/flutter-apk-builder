import { createAiPlugin } from "./_factory.js";

export default createAiPlugin({
  providerName: "DuckAI",
  Commands: ['duckai']
});
