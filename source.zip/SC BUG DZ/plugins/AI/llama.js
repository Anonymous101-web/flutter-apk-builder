import { createAiPlugin } from "./_factory.js";

export default createAiPlugin({
  providerName: "Llama",
  Commands: ['llama']
});
