import { createAiPlugin } from "./_factory.js";

export default createAiPlugin({
  providerName: "Copilot",
  Commands: ['copilot']
});
