import { createAiPlugin } from "./_factory.js";

export default createAiPlugin({
  providerName: "Claude",
  Commands: ['claude']
});
