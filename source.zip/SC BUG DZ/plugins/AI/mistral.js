import { createAiPlugin } from "./_factory.js";

export default createAiPlugin({
  providerName: "Mistral",
  Commands: ['mistral']
});
