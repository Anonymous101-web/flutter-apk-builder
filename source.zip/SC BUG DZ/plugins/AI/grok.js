import { createAiPlugin } from "./_factory.js";

export default createAiPlugin({
  providerName: "Grok",
  Commands: ['grok']
});
