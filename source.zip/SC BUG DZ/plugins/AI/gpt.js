import { createAiPlugin } from "./_factory.js";

export default createAiPlugin({
  providerName: "ChatGPT",
  Commands: ['gpt']
});
