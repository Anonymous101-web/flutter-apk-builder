import { createAiPlugin } from "./_factory.js";

export default createAiPlugin({
  providerName: "Qwen",
  Commands: ['qwen']
});
