import { createAiPlugin } from "./_factory.js";

export default createAiPlugin({
  providerName: "Gemma",
  Commands: ['gemma']
});
