import { createAiPlugin } from "./_factory.js";

export default createAiPlugin({
  providerName: "Perplexity",
  Commands: ['perplexity']
});
