import { createAiPlugin } from "./_factory.js";

export default createAiPlugin({
  providerName: "Blackbox AI",
  Commands: ['blackbox']
});
