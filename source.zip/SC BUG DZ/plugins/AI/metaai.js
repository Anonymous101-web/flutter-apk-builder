import { createAiPlugin } from "./_factory.js";

export default createAiPlugin({
  providerName: "Meta AI",
  Commands: ['metaai']
});
