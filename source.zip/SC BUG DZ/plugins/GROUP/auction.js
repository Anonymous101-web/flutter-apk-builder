import fs from "fs";
import path from "path";
import mess from "../../strings.js";
import { downloadMedia, downloadQuotedMedia, sendMessageWithMention } from "../../lib/utils.js";
import { getAuction, setAuction, clearAuction, addBid, closeAuction, resolveWinner } from "../../lib/auction_store.js";
import { getGroupMetadata } from "../../lib/cache.js";

function isAdminFromParticipants(participants = [], sender = "") {
  return participants.some((p) => (p.phoneNumber === sender || p.id === sender) && p.admin);
}

function formatCurrency(num = 0) {
  return new Intl.NumberFormat("id-ID").format(Number(num || 0));
}

function tagUser(jid = "") {
  return `@${String(jid).split("@")[0]}`;
}

function buildWinnerText(auction) {
  const winner = resolveWinner(auction);
  return [
    "🏆 *AUTO WINNER LELANG*",
    "",
    `📦 *Barang:* ${auction.itemName}`,
    `💰 *Harga menang:* Rp${formatCurrency(winner.winnerBid || auction.highestBid || 0)}`,
    `👑 *Pemenang otomatis:* ${winner.winnerJid ? tagUser(winner.winnerJid) : "Belum ada penawar"}`,
    `🧾 *Total bid:* ${auction.bids?.length || 0}`,
    winner.bid?.createdAt ? `🕒 *Waktu bid menang:* ${new Date(winner.bid.createdAt).toLocaleString("id-ID")}` : null,
  ].filter(Boolean).join("\n");
}


function buildAuctionHelp(prefix = ".") {
  return [
    "📘 *HELPER SISTEM LELANG*",
    "",
    "*Cara kerja sistem:*",
    "1. Admin kirim/reply foto barang lalu buka lelang.",
    "2. Admin isi nama barang, deskripsi, harga awal, dan minimal kenaikan.",
    "3. Member non-admin ikut bid pakai *.ajuharga nominal*.",
    "4. Bot simpan semua riwayat bid.",
    "5. Saat lelang ditutup, bot auto pilih pemenang dari bid tertinggi.",
    "",
    "*Command admin:*",
    `• ${prefix}bukalelang nama|deskripsi|hargaawal|minimalkenaikan`,
    `• ${prefix}tutuplelang`,
    `• ${prefix}hapuslelang`,
    "",
    "*Command member:*",
    `• ${prefix}ajuharga nominal`,
    `• ${prefix}ceklelang`,
    `• ${prefix}cekwinner`,
    `• ${prefix}menu lelang`,
    "",
    "*Contohnya buka lelang:*",
    `${prefix}bukalelang iPhone 13|Fullset mulus|4500000|50000`,
    "",
    "*Contohnya bid:*",
    `${prefix}ajuharga 5000000`,
    "",
    "Catatan: command *.ajuharga*, *.ceklelang*, *.cekwinner*, dan *.menu lelang* tetap bisa dipakai member walau mode onlyadmin aktif.",
  ].join("\n");
}

function buildAuctionText(auction) {
  return [
    "🏷️ *LELANG GRUP AKTIF*",
    "",
    `📦 *Barang:* ${auction.itemName}`,
    `📝 *Deskripsi:* ${auction.description}`,
    `💵 *Harga awal:* Rp${formatCurrency(auction.startPrice)}`,
    `📈 *Minimal kenaikan:* Rp${formatCurrency(auction.minIncrement)}`,
    `🥇 *Bid tertinggi:* Rp${formatCurrency(auction.highestBid)}`,
    `👤 *Penawar tertinggi:* ${auction.highestBidder ? tagUser(auction.highestBidder) : "Belum ada"}`,
    `🧾 *Total bid:* ${auction.bids?.length || 0}`,
    "",
    "Ketik *.ajuharga nominal* untuk ikut menawar.",
  ].join("\n");
}

async function sendAuctionCard(sock, remoteJid, message, auction) {
  const mediaPath = auction.imageFile ? path.resolve("./database/media", auction.imageFile) : null;
  const text = buildAuctionText(auction);

  if (mediaPath && fs.existsSync(mediaPath)) {
    return sock.sendMessage(
      remoteJid,
      {
        image: { url: mediaPath },
        caption: text,
        mentions: auction.highestBidder ? [auction.highestBidder] : [],
      },
      { quoted: message }
    );
  }

  return sock.sendMessage(
    remoteJid,
    {
      text,
      mentions: auction.highestBidder ? [auction.highestBidder] : [],
    },
    { quoted: message }
  );
}

async function handle(sock, messageInfo) {
  const {
    remoteJid,
    isGroup,
    message,
    sender,
    content,
    command,
    prefix,
    isQuoted,
    type,
    senderType,
  } = messageInfo;

  if (!isGroup) {
    await sock.sendMessage(remoteJid, { text: mess.general.isGroup }, { quoted: message });
    return;
  }

  const groupMetadata = await getGroupMetadata(sock, remoteJid);
  const participants = groupMetadata?.participants || [];
  const isAdmin = isAdminFromParticipants(participants, sender);
  const text = String(content || "").trim();

  if (["bukalelang", "tutuplelang", "hapuslelang"].includes(command) && !isAdmin) {
    await sock.sendMessage(remoteJid, { text: mess.general.isAdmin }, { quoted: message });
    return;
  }

  if (command === "bukalelang") {
    const parts = text.split("|").map((v) => v.trim()).filter(Boolean);
    if (parts.length < 4) {
      return sock.sendMessage(
        remoteJid,
        {
          text:
            `_*Format:* ${prefix + command} nama barang|deskripsi|harga awal|limit kenaikan*_\n\n` +
            `_*Contohnya begini:* ${prefix + command} iPhone 13|Fullset mulus|4500000|50000*_\n\n` +
            "Kirim gambar dengan caption itu, atau reply gambar memakai command di atas.",
        },
        { quoted: message }
      );
    }

    const [itemName, description, startRaw, incrementRaw] = parts;
    const startPrice = Number(String(startRaw).replace(/[^0-9]/g, ""));
    const minIncrement = Number(String(incrementRaw).replace(/[^0-9]/g, ""));

    if (!startPrice || startPrice <= 0 || !minIncrement || minIncrement <= 0) {
      return sock.sendMessage(
        remoteJid,
        { text: "⚠️ Harga awal dan limit kenaikan harus berupa angka yang valid." },
        { quoted: message }
      );
    }

    let imageFile = null;
    const currentType = `${type || ""}Message`;
    if (currentType === "imageMessage") {
      imageFile = await downloadMedia(message, true);
    } else if (isQuoted && isQuoted.type === "image") {
      imageFile = await downloadQuotedMedia(message, true);
    }

    if (!imageFile) {
      return sock.sendMessage(
        remoteJid,
        { text: "⚠️ Kirim gambar barang atau reply gambar saat membuka lelang." },
        { quoted: message }
      );
    }

    const auction = await setAuction(remoteJid, {
      active: true,
      itemName,
      description,
      startPrice,
      minIncrement,
      highestBid: startPrice,
      highestBidder: null,
      imageFile,
      createdBy: sender,
      createdAt: new Date().toISOString(),
      bids: [],
    });

    await sendAuctionCard(sock, remoteJid, message, auction);
    return;
  }

  if (command === "ajuharga") {
    const auction = await getAuction(remoteJid);
    if (!auction || !auction.active) {
      return sock.sendMessage(remoteJid, { text: "⚠️ Saat ini belum ada lelang aktif di grup ini." }, { quoted: message });
    }

    if (isAdmin) {
      return sock.sendMessage(remoteJid, { text: "⚠️ Admin tidak bisa mengajukan harga. Khusus member non-admin." }, { quoted: message });
    }

    const nominal = Number(text.replace(/[^0-9]/g, ""));
    if (!nominal || nominal <= 0) {
      return sock.sendMessage(
        remoteJid,
        { text: `_*Format:* ${prefix + command} nominal*\n\n_*Contohnya begini:* ${prefix + command} 5000000*` },
        { quoted: message }
      );
    }

    const minAllowed = Number(auction.highestBid || 0) + Number(auction.minIncrement || 0);
    if (nominal < minAllowed) {
      return sock.sendMessage(
        remoteJid,
        {
          text:
            `⚠️ Bid terlalu rendah.\n` +
            `Bid tertinggi sekarang: *Rp${formatCurrency(auction.highestBid)}*\n` +
            `Minimal ajukan: *Rp${formatCurrency(minAllowed)}*`,
        },
        { quoted: message }
      );
    }

    const updated = await addBid(remoteJid, {
      bidder: sender,
      amount: nominal,
    });

    await sendMessageWithMention(
      sock,
      remoteJid,
      `✅ ${tagUser(sender)} berhasil mengajukan harga *Rp${formatCurrency(nominal)}*\n\n` +
        `🥇 Bid tertinggi terbaru: *Rp${formatCurrency(updated.highestBid)}*\n` +
        `📈 Minimal bid berikutnya: *Rp${formatCurrency(updated.highestBid + updated.minIncrement)}*`,
      message,
      senderType
    );
    return;
  }

  if (command === "ceklelang") {
    const auction = await getAuction(remoteJid);
    if (!auction) {
      return sock.sendMessage(remoteJid, { text: "⚠️ Belum ada data lelang di grup ini." }, { quoted: message });
    }

    await sendAuctionCard(sock, remoteJid, message, auction);
    return;
  }

  if (command === "menulelang" || command === "helperlelang" || command === "helplelang") {
    return sock.sendMessage(remoteJid, { text: buildAuctionHelp(prefix) }, { quoted: message });
  }

  if (command === "tutuplelang") {
    const auction = await getAuction(remoteJid);
    if (!auction || !auction.active) {
      return sock.sendMessage(remoteJid, { text: "⚠️ Tidak ada lelang aktif untuk ditutup." }, { quoted: message });
    }

    const closedAuction = await closeAuction(remoteJid);
    const winner = resolveWinner(closedAuction);
    const finalText = [
      "🔒 *LELANG DITUTUP*",
      "",
      `📦 *Barang:* ${closedAuction.itemName}`,
      `💰 *Harga menang:* Rp${formatCurrency(winner.winnerBid || closedAuction.highestBid || 0)}`,
      `🏆 *AUTO WINNER:* ${winner.winnerJid ? tagUser(winner.winnerJid) : "Belum ada penawar"}`,
      `🧾 *Total bid:* ${closedAuction.bids?.length || 0}`,
      winner.bid?.createdAt ? `🕒 *Bid menang masuk:* ${new Date(winner.bid.createdAt).toLocaleString("id-ID")}` : null,
    ].filter(Boolean).join("\n");

    await sock.sendMessage(
      remoteJid,
      {
        text: finalText,
        mentions: winner.winnerJid ? [winner.winnerJid] : [],
      },
      { quoted: message }
    );
    return;
  }



  if (command === "cekwinner") {
    const auction = await getAuction(remoteJid);
    if (!auction) {
      return sock.sendMessage(remoteJid, { text: "⚠️ Belum ada data lelang di grup ini." }, { quoted: message });
    }

    const winnerText = buildWinnerText(auction);
    const winner = resolveWinner(auction);
    await sock.sendMessage(
      remoteJid,
      {
        text: winnerText,
        mentions: winner.winnerJid ? [winner.winnerJid] : [],
      },
      { quoted: message }
    );
    return;
  }

  if (command === "hapuslelang") {
    const auction = await getAuction(remoteJid);
    if (auction?.imageFile) {
      const mediaPath = path.resolve("./database/media", auction.imageFile);
      if (fs.existsSync(mediaPath)) {
        try { fs.unlinkSync(mediaPath); } catch {}
      }
    }
    await clearAuction(remoteJid);
    await sock.sendMessage(remoteJid, { text: "✅ Data lelang grup udah beres aku hapus/reset." }, { quoted: message });
    return;
  }
}

export default {
  handle,
  Commands: ["bukalelang", "ajuharga", "ceklelang", "menulelang", "helperlelang", "helplelang", "tutuplelang", "cekwinner", "hapuslelang"],
  OnlyPremium: false,
  OnlyOwner: false,
};
