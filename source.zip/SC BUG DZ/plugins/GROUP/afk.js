import { findUser, updateUser } from "../../lib/users.js";

function cleanReason(content = "") {
  const reason = String(content || "").trim();
  if (!reason) return "Tanpa alasan";
  return reason.length > 100 ? `${reason.slice(0, 100)}...` : reason;
}

function jidToTag(jid = "") {
  const number = String(jid || "").split("@")[0].split(":")[0].replace(/\D/g, "");
  return number ? `@${number}` : "@user";
}

function formatJakartaTime(date = new Date()) {
  try {
    return date.toLocaleString("id-ID", {
      timeZone: "Asia/Jakarta",
      weekday: "long",
      day: "2-digit",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    });
  } catch {
    return date.toISOString();
  }
}

async function handle(sock, messageInfo) {
  const { remoteJid, isGroup, message, content, sender, pushName } = messageInfo;

  if (!isGroup) {
    return sock.sendMessage(
      remoteJid,
      { text: "Fitur AFK ini khusus dipakai di grup." },
      { quoted: message }
    );
  }

  try {
    const dataUsers = await findUser(sender);
    if (!dataUsers) {
      return sock.sendMessage(
        remoteJid,
        { text: "⚠️ Data user kamu belum ditemukan. Coba kirim pesan lagi lalu ulangi perintah AFK." },
        { quoted: message }
      );
    }

    const reason = cleanReason(content);
    const now = new Date();

    await updateUser(sender, {
      status: "afk",
      afk: {
        lastChat: now.toISOString(),
        alasan: reason,
      },
    });

    const text =
      `╭─〔 💤 *AFK MODE AKTIF* 〕\n` +
      `│ 👤 User: ${jidToTag(sender)}\n` +
      `│ 🏷️ Nama: *${pushName || "User"}*\n` +
      `│ ⏰ Mulai: *${formatJakartaTime(now)} WIB*\n` +
      `│ 📌 Alasan: *${reason}*\n` +
      `╰──────────────\n\n` +
      `Kalau ada member yang tag kamu di grup, bot akan otomatis membalas bahwa kamu sedang AFK.`;

    await sock.sendMessage(remoteJid, { text, mentions: [sender] }, { quoted: message });
  } catch (error) {
    console.error("Oops in AFK command:", error);
    await sock.sendMessage(
      remoteJid,
      { text: "❌ Lagi ada yang nyangkut saat memproses perintah AFK. Coba lagi nanti." },
      { quoted: message }
    );
  }
}

export default {
  handle,
  Commands: ["afk"],
  OnlyPremium: false,
  OnlyOwner: false,
};
