import { reply } from "../../lib/utils.js";

function pickFirst(...vals) {
  for (const v of vals) {
    if (v === null || v === undefined) continue;
    if (typeof v === "string" && v.trim() === "") continue;
    return v;
  }
  return undefined;
}

function normalizeInviteOrJid(input = "") {
  const text = String(input).trim();
  if (!text) return null;

  // 1) Full JID (newsletter)
  const jidMatch = text.match(/(\d{5,25}@newsletter)/i);
  if (jidMatch?.[1]) {
    return { kind: "jid", value: jidMatch[1] };
  }

  // 2) Link format: https://whatsapp.com/channel/<invite>
  const linkMatch = text.match(
    /(?:https?:\/\/)?(?:www\.)?whatsapp\.com\/channel\/([0-9A-Za-z_-]{6,128})/i
  );
  if (linkMatch?.[1]) {
    return { kind: "invite", value: linkMatch[1] };
  }

  // 3) Alternative link format (sometimes used)
  const waMeMatch = text.match(
    /(?:https?:\/\/)?(?:www\.)?wa\.me\/channel\/([0-9A-Za-z_-]{6,128})/i
  );
  if (waMeMatch?.[1]) {
    return { kind: "invite", value: waMeMatch[1] };
  }

  // 4) Raw invite code
  const firstToken = text.split(/\s+/)[0];
  if (/^[0-9A-Za-z_-]{6,128}$/.test(firstToken)) {
    return { kind: "invite", value: firstToken };
  }

  return null;
}

function formatChannelOutput({
  jid,
  invite,
  name,
  description,
  verification,
  subscribers,
}) {
  const numeric = jid ? String(jid).split("@")[0] : "-";

  const lines = [
    "📰 *ID Saluran (WhatsApp Channel)*",
    "",
    `• JID: ${jid || "-"}`,
    `• Numeric: ${numeric || "-"}`,
  ];

  if (invite) lines.push(`• Invite: ${invite}`);
  if (name) lines.push(`• Nama: ${name}`);
  if (description) lines.push(`• Deskripsi: ${description}`);
  if (verification) lines.push(`• Verifikasi: ${verification}`);
  if (
    subscribers !== undefined &&
    subscribers !== null &&
    String(subscribers) !== ""
  ) {
    lines.push(`• Subscribers: ${subscribers}`);
  }

  lines.push(
    "",
    "Catatan:",
    "- Kalau kamu lagi buka chat saluran, cukup ketik command ini tanpa argumen.",
    "- Kalau kamu punya link saluran, kirim link-nya untuk di-resolve jadi JID."
  );

  return lines.join("\n");
}

async function handle(sock, messageInfo) {
  const { m, remoteJid, message, prefix, command, content } = messageInfo;

  try {
    const trimmed = String(content || "").trim();
    const isChannelChat = String(remoteJid || "").endsWith("@newsletter");

    // Case A: command dipakai langsung di chat saluran
    if (isChannelChat && !trimmed) {
      const jid = remoteJid;
      return await reply(
        m,
        formatChannelOutput({
          jid,
        })
      );
    }

    // Case B: user kirim link / invite code / jid
    if (!trimmed && !isChannelChat) {
      return await reply(
        m,
        `_⚠️ Cara pakainya gini:_\n\n${prefix + command} <link channel / invite code / jid@newsletter>\n\n_Contohnya begini:_\n${
          prefix + command
        } https://whatsapp.com/channel/0029VaXXXXXXXXXXXX\n${prefix + command} 0029VaXXXXXXXXXXXX\n${prefix + command} 120363xxxxxxxxxxxx@newsletter`
      );
    }

    const parsed = normalizeInviteOrJid(trimmed);
    if (!parsed) {
      return await reply(
        m,
        `_❌ Input tidak valid._\n\nKirim link saluran (whatsapp.com/channel/...), invite code, atau JID berakhiran @newsletter.`
      );
    }

    // Kirim reaksi loading
    try {
      await sock.sendMessage(remoteJid, {
        react: { text: "⏳", key: message.key },
      });
    } catch {}

    // Kalau sudah jid, tampilkan langsung
    if (parsed.kind === "jid") {
      return await reply(
        m,
        formatChannelOutput({
          jid: parsed.value,
        })
      );
    }

    const inviteCode = parsed.value;

    // Resolve invite -> metadata -> jid
    if (typeof sock.newsletterMetadata === "function") {
      const meta = await sock.newsletterMetadata("invite", inviteCode);

      // Baileys interface kadang berubah (sebagian field nested di thread_metadata)
      const jid = pickFirst(meta?.id, meta?.thread_metadata?.id);
      const name = pickFirst(
        meta?.name,
        meta?.thread_metadata?.name,
        meta?.thread_metadata?.name?.text
      );
      const description = pickFirst(
        meta?.description,
        meta?.thread_metadata?.description,
        meta?.thread_metadata?.description?.text
      );
      const verification = pickFirst(
        meta?.verification,
        meta?.thread_metadata?.verification,
        meta?.state?.type
      );
      const subscribers = pickFirst(
        meta?.subscribers,
        meta?.thread_metadata?.subscribers_count,
        meta?.subscribers_count
      );
      const invite = pickFirst(
        meta?.invite,
        meta?.thread_metadata?.invite,
        inviteCode
      );

      return await reply(
        m,
        formatChannelOutput({
          jid: jid || "-",
          invite,
          name,
          description,
          verification,
          subscribers,
        })
      );
    }

    // Fallback jika Baileys versi tidak support
    return await reply(
      m,
      `⚠️ Baileys kamu belum support newsletterMetadata()._\n\nInvite code yang terdeteksi: *${inviteCode}*\n\nSolusi:\n- Update baileys ke versi yang punya fitur newsletter (Channel).\n- Atau, buka chat saluran itu di akun bot, lalu jalankan command ini di dalam chat saluran untuk melihat JID-nya.`
    );
  } catch (error) {
    const msg = error?.message || String(error);
    return await sock.sendMessage(
      remoteJid,
      { text: `_❌ Oops: ${msg}_` },
      { quoted: message }
    );
  }
}

export default {
  handle,
  Commands: [
    "cekidch",
    "cekidchannel",
    "cekidsaluran",
    "idch",
    "idchannel",
    "idsaluran",
  ],
  OnlyPremium: false,
  OnlyOwner: false,
  limitDeduction: 1,
};
