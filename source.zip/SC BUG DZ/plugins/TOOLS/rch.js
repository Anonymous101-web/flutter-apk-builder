const DEFAULT_APIKEY = "c140fb995d3ced3d79ae687202a9d8620f6f06eb2e7c2fcceb04d2da20e33591";

function getApiKey() {
  return (
    globalThis.danzyApiKey ||
    globalThis.apikeydanzy ||
    process.env.DANZY_APIKEY ||
    process.env.APIKEY_DANZY ||
    DEFAULT_APIKEY
  );
}

function pickMessage(value, fallback = "-") {
  if (value === null || value === undefined) return fallback;
  if (typeof value === "string") return value || fallback;
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  try {
    return JSON.stringify(value, null, 2).slice(0, 700);
  } catch {
    return fallback;
  }
}

function parseInput(content = "") {
  const raw = String(content || "").trim();
  const urlMatch = raw.match(/https?:\/\/(?:www\.)?whatsapp\.com\/channel\/\S+/i);
  const link = urlMatch?.[0]?.trim() || "";
  const emoji = link ? raw.replace(link, "").trim() || "😹" : "😹";
  return { link, emoji };
}

function isValidChannelLink(link = "") {
  try {
    const parsed = new URL(link);
    const host = parsed.hostname.replace(/^www\./, "").toLowerCase();
    return host === "whatsapp.com" && parsed.pathname.startsWith("/channel/");
  } catch {
    return false;
  }
}

function buildApiUrl(link, emoji) {
  const url = new URL("https://api.danzy.web.id/api/tools/reactch");
  url.searchParams.set("url", link);
  url.searchParams.set("emoji", emoji);
  url.searchParams.set("apikey", getApiKey());
  return url.toString();
}

async function getFetch() {
  if (typeof globalThis.fetch === "function") return globalThis.fetch.bind(globalThis);
  const mod = await import("node-fetch");
  return mod.default || mod;
}

async function requestJson(url) {
  const fetchFn = await getFetch();
  const controller = typeof AbortController !== "undefined" ? new AbortController() : null;
  const timeout = controller ? setTimeout(() => controller.abort(), 60000) : null;

  try {
    const response = await fetchFn(url, {
      method: "GET",
      headers: {
        accept: "application/json,text/plain,*/*",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
      signal: controller?.signal,
    });

    const rawText = await response.text();
    let json = null;
    try {
      json = rawText ? JSON.parse(rawText) : null;
    } catch {
      json = null;
    }

    if (!response.ok) {
      return {
        ok: false,
        statusCode: response.status,
        error: `HTTP ${response.status}`,
        rawText: rawText.slice(0, 700),
        json,
      };
    }

    if (!json) {
      return {
        ok: false,
        statusCode: response.status,
        error: "Response API bukan JSON",
        rawText: rawText.slice(0, 700),
      };
    }

    return { ok: true, statusCode: response.status, json, rawText };
  } catch (error) {
    return {
      ok: false,
      error: error?.name === "AbortError" ? "Request timeout" : error?.message || String(error),
    };
  } finally {
    if (timeout) clearTimeout(timeout);
  }
}

function getApiError(json, rawText, fallback = "API mengembalikan status gagal") {
  return (
    json?.message ||
    json?.msg ||
    json?.error ||
    json?.result?.message ||
    json?.result?.msg ||
    json?.result?.error ||
    json?.data?.message ||
    json?.data?.msg ||
    json?.data?.error ||
    rawText ||
    fallback
  );
}

function formatFollowers(value) {
  if (typeof value === "number") return value.toLocaleString("id-ID");
  return value || "-";
}

async function safeReact(sock, remoteJid, message, emoji) {
  try {
    await sock.sendMessage(remoteJid, { react: { text: emoji, key: message.key } });
  } catch {}
}

async function sendText(sock, remoteJid, message, text) {
  return sock.sendMessage(remoteJid, { text }, { quoted: message });
}

async function handle(sock, messageInfo) {
  const { remoteJid, message, content, prefix, command } = messageInfo;

  const { link, emoji } = parseInput(content);

  if (!link) {
    return sendText(
      sock,
      remoteJid,
      message,
      `Contoh: ${prefix}${command} https://whatsapp.com/channel/xxx/123 😹\n\nCatatan: lebih aman pakai link postingan channel, bukan link channel utama saja.`,
    );
  }

  if (!isValidChannelLink(link)) {
    return sendText(sock, remoteJid, message, "❌ Link channel tidak valid");
  }

  await safeReact(sock, remoteJid, message, "⏳");

  const apiUrl = buildApiUrl(link, emoji);
  const response = await requestJson(apiUrl);

  if (!response.ok) {
    await safeReact(sock, remoteJid, message, "❌");
    return sendText(
      sock,
      remoteJid,
      message,
      `❌ Gagal mengirim reactions\n\nDetail: ${pickMessage(response.error)}${response.rawText ? `\nResponse: ${pickMessage(response.rawText)}` : ""}`,
    );
  }

  const json = response.json;
  if (!json?.status) {
    await safeReact(sock, remoteJid, message, "❌");
    return sendText(
      sock,
      remoteJid,
      message,
      `❌ Gagal mengirim reactions\n\nDetail API: ${pickMessage(getApiError(json, response.rawText))}\n\nTips: coba pakai link postingan channel lengkap, contoh https://whatsapp.com/channel/xxx/123`,
    );
  }

  const meta = json.result?.metadata || json.metadata || json.result || json.data || {};

  await sendText(
    sock,
    remoteJid,
    message,
    `✅ *Reactions Sent*\n\n🎯 Emoji: ${emoji}\n📢 Channel: ${meta.name || meta.title || "-"}\n👥 Followers: ${formatFollowers(meta.followers || meta.subscribers)}`,
  );

  await safeReact(sock, remoteJid, message, "✅");
}

export default {
  handle,
  Commands: ["rch"],
  OnlyPremium: false,
  OnlyOwner: false,
  limitDeduction: 1,
};
