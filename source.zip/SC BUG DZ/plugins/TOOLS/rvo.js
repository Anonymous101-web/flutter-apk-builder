import { downloadContentFromMessage } from "baileys";

async function handle(sock, messageInfo) {
  const { m, message, remoteJid } = messageInfo;

  const Reply = async (text) => sock.sendMessage(remoteJid, { text }, { quoted: message });
  const example = (txt) => `_⚠️ Cara pakainya gini:_\n\nBalas pesan view-once dengan *${messageInfo.prefix || '.'}${messageInfo.command || 'rvo'}*`;

  try {
    if (!m?.quoted?.message) return Reply(example("dengan reply pesannya"));

    let msg = m.quoted.message;
    let type = Object.keys(msg || {})[0];
    if (!type || !msg[type]) return Reply(example("dengan reply pesannya"));

    if (!msg[type].viewOnce) return Reply("Pesan itu bukan viewonce!");

    const mediaType = type === "imageMessage" ? "image" : type === "videoMessage" ? "video" : type === "audioMessage" ? "audio" : null;
    if (!mediaType) return Reply("Tipe pesan viewonce ini belum didukung.");

    const media = await downloadContentFromMessage(msg[type], mediaType);
    let buffer = Buffer.from([]);
    for await (const chunk of media) {
      buffer = Buffer.concat([buffer, chunk]);
    }

    if (/video/i.test(type)) {
      return sock.sendMessage(remoteJid, {
        video: buffer,
        caption: "✅ ANJAY RVO SUKSES TERIMAKSIH LAH KEPADA DEVELOPER GANTENG ITU BRAY HAHAY\n\n" + (msg[type].caption || "")
      }, { quoted: message });
    } else if (/image/i.test(type)) {
      return sock.sendMessage(remoteJid, {
        image: buffer,
        caption: "✅ ANJAY RVO SUKSES TERIMAKSIH LAH KEPADA DEVELOPER GANTENG ITU BRAY HAHAY\n\n" + (msg[type].caption || "")
      }, { quoted: message });
    } else if (/audio/i.test(type)) {
      return sock.sendMessage(remoteJid, {
        audio: buffer,
        mimetype: "audio/mpeg",
        ptt: true
      }, { quoted: message });
    }

    return Reply("Tipe pesan viewonce ini belum didukung.");
  } catch (error) {
    console.error("Oops pada fitur RVO:", error);
    return Reply("❌ Lagi ada yang nyangkut saat membaca pesan view-once.");
  }
}

export default {
  handle,
  Commands: ["rvo", "readviewonce"],
  OnlyPremium: true,
  OnlyOwner: false,
};
