import moment from"moment-timezone";async function handle(sock,messageInfo){const{remoteJid,message}=messageInfo;const format="DD-MM-YYYY HH:mm";const utcTime=moment().tz("UTC").format(format);const serverTime=moment().format(format);const jakartaTime=moment().tz("Asia/Jakarta").format(format);const response=`⏰ Waktu Saat Ini:
    
🌍 UTC: 
${utcTime}

🖥 Server: 
${serverTime}

🇮🇩 WIB: 
${jakartaTime}`;return await sock.sendMessage(remoteJid,{text:response},{quoted:message});}export default{handle,Commands:["now"],OnlyPremium:false,OnlyOwner:false,};
