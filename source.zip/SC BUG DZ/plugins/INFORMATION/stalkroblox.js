import { fetchJson, reply } from "../../lib/utils.js";

function pickCount(value) {
  if (typeof value === "number") return value.toLocaleString("id-ID");
  if (value && typeof value.count === "number") return value.count.toLocaleString("id-ID");
  return "0";
}

function pickAvatar(data) {
  return (
    data?.avatar?.fullBody?.data?.[0]?.imageUrl ||
    data?.avatar?.headshot?.data?.[0]?.imageUrl ||
    data?.avatar?.bust?.data?.[0]?.imageUrl ||
    ""
  );
}

async function handle(sock, messageInfo) {
  const { m, remoteJid, message, prefix, command, content } = messageInfo;

  try {
    const username = (content || "").trim().replace(/^@+/, "");
    if (!username) {
      return await reply(m, `❌ Contoh penggunaan: ${prefix}${command} alipclutch`);
    }

    const apiUrl = `https://api.siputzx.my.id/api/stalk/roblox?user=${encodeURIComponent(username)}`;
    const res = await fetchJson(apiUrl);

    if (!res || !res.status || !res.data) {
      return await sock.sendMessage(
        remoteJid,
        { text: "❌ User tidak ditemukan!" },
        { quoted: message },
      );
    }

    const data = res.data || {};
    const basic = data.basic || {};
    const social = data.social || {};
    const presence = data.presence?.userPresences?.[0] || {};
    const avatar = pickAvatar(data);

    const caption = `╭───⧼ *ROBLOX STALK* ⧽
│ 🆔 ID : ${basic.id || "-"}
│ 👤 Username : ${basic.name || username}
│ 🎭 Display : ${basic.displayName || "-"}
│ 📆 Dibuat : ${basic.created || "-"}
│ 🚫 Banned : ${basic.isBanned ? "Ya" : "Tidak"}
│ 🏷️ Verified : ${basic.hasVerifiedBadge ? "Ya" : "Tidak"}
│ 🌐 Status : ${data.status || "-"}
│ 🎮 Presence : ${presence.lastLocation || "Unknown"}
│ 👥 Teman : ${pickCount(social.friends)}
│ 👤 Followers : ${pickCount(social.followers)}
│ 👤 Following : ${pickCount(social.following)}
╰─────────────────`;

    if (avatar) {
      return await sock.sendMessage(
        remoteJid,
        { image: { url: avatar }, caption },
        { quoted: message },
      );
    }

    return await sock.sendMessage(remoteJid, { text: caption }, { quoted: message });
  } catch (error) {
    console.error("Error stalkroblox:", error);
    return await sock.sendMessage(
      remoteJid,
      { text: "❌ Terjadi error saat ambil data Roblox." },
      { quoted: message },
    );
  }
}

export default {
  handle,
  Commands: ["stalkroblox", "stalkrbx"],
  OnlyPremium: false,
  OnlyOwner: false,
  limitDeduction: 1,
};
