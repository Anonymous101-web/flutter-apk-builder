import{groupFetchAllParticipating}from"../../lib/cache.js";async function handle(sock,messageInfo){const{remoteJid,message}=messageInfo;try{await sock.sendMessage(remoteJid,{react:{text:"⏰",key:message.key},});const allGroups=await groupFetchAllParticipating(sock);const totalGroups=Object.keys(allGroups).length;let totalCommunities=0;let totalRegularGroups=0;let totalOpenGroups=0;let totalClosedGroups=0;for(const groupId in allGroups){const group=allGroups[groupId];if(group.isCommunity){totalCommunities++;}else{totalRegularGroups++;}if(group.announce){totalClosedGroups++;}else{totalOpenGroups++;}}await sock.sendMessage(remoteJid,{text:`*_Statistik Grup:_*\n
◧ Total Grup: *${totalGroups}*
◧ Grup Komunitas: *${totalCommunities}*
◧ Grup Biasa: *${totalRegularGroups}*
◧ Grup Terbuka: *${totalOpenGroups}*
◧ Grup Tertutup: *${totalClosedGroups}*`,},{quoted:message});}catch(error){console.error("Oops in handle function:",error);await sock.sendMessage(remoteJid,{text:"_Lagi ada yang nyangkut saat memproses perintah._"},{quoted:message});}}export default{handle,Commands:["totalgc","totalgrub","totalgroub","totalgrup","totalgroup"],OnlyPremium:false,OnlyOwner:true,};
