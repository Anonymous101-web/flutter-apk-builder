import { groupFetchAllParticipating } from "../../lib/cache.js";
import { getBroadcastBlacklist, isBroadcastGroupBlacklisted } from "../../lib/broadcastBlacklist.js";

async function formatGrup(sock, index, grup) {
  const isBlacklisted = isBroadcastGroupBlacklisted(grup.id);
  const statusLine = isBlacklisted ? `│ Status  : 🚫 BLACKLIST JPM/SWGC\n` : "";
  try {
    const inviteCode = await sock.groupInviteCode(grup.id);
    const groupLink = `https://chat.whatsapp.com/${inviteCode}`;
    return `╭─「 ${index} 」 *${grup.subject}*
│ Anggota : ${grup.participants.length}
│ ID Grup : ${grup.id}
${statusLine}│ Link    : ${groupLink}
╰────────────────────────`;
  } catch (error) {
    return `╭─「 ${index} 」 *${grup.subject}*
│ Anggota : ${grup.participants.length}
│ ID Grup : ${grup.id}
${statusLine}╰────────────────────────`;
  }
}

async function handle(sock, messageInfo) {
  const { remoteJid, message, prefix = "." } = messageInfo;
  try {
    await sock.sendMessage(remoteJid, { react: { text: "⏰", key: message.key } });
    const allGroups = await groupFetchAllParticipating(sock);
    const sortedGroups = Object.values(allGroups).sort((a, b) => b.participants.length - a.participants.length);
    const formattedGroups = await Promise.all(sortedGroups.map((group, index) => formatGrup(sock, index + 1, group)));
    const totalGroups = sortedGroups.length;
    const blacklisted = getBroadcastBlacklist();

    const tips =
      `╭─「 📌 TIP BLACKLIST JPM/SWGC 」\n` +
      `│ Kalau ada grup yang tidak mau dikirimi JPM/SWGC,\n` +
      `│ salin ID Grup di bawah lalu ketik:\n` +
      `│ *${prefix}addbl <id grup>*\n` +
      `│ Contoh: *${prefix}addbl 1203630xxxx@g.us*\n` +
      `│ Cek blacklist: *${prefix}listbl*\n` +
      `│ Total blacklist sekarang: *${blacklisted.length} grup*\n` +
      `╰────────────────────────`;

    const responseMessage = `${tips}\n\n_*Total Grup: ${totalGroups}*_ \n\n ${formattedGroups.join("\n\n")}`;
    await sock.sendMessage(remoteJid, { text: responseMessage }, { quoted: message });
  } catch (error) {
    console.error("Oops in handle function:", error);
    await sock.sendMessage(remoteJid, { text: "_Lagi ada yang nyangkut saat memproses perintah._" }, { quoted: message });
  }
}

export default {
  handle,
  Commands: ["listgc", "listgrub", "listgroub", "listgrup", "listgroup"],
  OnlyPremium: false,
  OnlyOwner: true,
};
