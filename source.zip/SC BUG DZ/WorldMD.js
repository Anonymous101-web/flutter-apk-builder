export const commandWithoutRegister = ["menu", "owner", "rules", "help"];

import chokidar from "chokidar";
import config from "./config.js";
import { findGroup } from "./lib/group.js";
import chalk from "chalk";
import handler from "./lib/handler.js";
import mess from "./strings.js";
import { updateParticipant } from "./lib/cache.js";
import path from "path";
import fs from "fs";
import sharp from "sharp";
import { handleActiveFeatures } from "./lib/participant_update.js";
import {
  logWithTime,
  log,
  danger,
  findClosestCommand,
  logTracking,
} from "./lib/utils.js";
import {
  isOwner,
  isPremiumUser,
  updateUser,
  findUser,
  isUserRegistered,
} from "./lib/users.js";
import { reloadPlugins } from "./lib/plugins.js";
import { logCustom } from "./lib/logger.js";
import { isGroupBlocked } from "./lib/blockedGroup.js";
import { maybeSendOwnerWelcome } from "./lib/sambutanowner.js";

await handler.initHandlers();

const progressThumbnailPath = path.join(
  process.cwd(),
  "database/assets/proses.jpg",
);
let progressThumbnail;
try {
  progressThumbnail = await sharp(progressThumbnailPath)
    .resize(128, 128, { fit: "cover", position: "center" })
    .jpeg({ quality: 70 })
    .toBuffer();
} catch {
  try {
    progressThumbnail = fs.readFileSync(progressThumbnailPath);
  } catch {
    progressThumbnail = undefined;
  }
}

const progressEmojiMap = {
  tiktok: "👻",
  tt: "👻",
  ttmp3: "🎵",
  ttaudio: "🎵",
  instagram: "📸",
  ig: "📸",
  facebook: "📘",
  fb: "📘",
  youtube: "▶️",
  yt: "▶️",
  ytmp3: "🎧",
  ytmp4: "🎬",
  play: "🎶",
  spotify: "🎧",
  mediafire: "📦",
  pinterest: "🖼️",
  sticker: "🪄",
  toimg: "🖼️",
  tourl: "🔗",
  ai: "🤖",
  gpt: "🤖",
  openai: "🤖",
  qc: "💬",
  remini: "✨",
  hd: "✨",
  removebg: "🪄",
  shortlink: "🔗",
  shorturl: "🔗",
  tourl2: "🔗",
  translate: "🌐",
  tr: "🌐",
  tts: "🗣️",
  anime: "🌸",
  nulis: "✍️",
  brat: "😈",
  logo: "🎨",
  menu: "📋",
  owner: "👑",
  group: "👥",
  download: "⬇️",
  dl: "⬇️",
};

function formatProgressCommand(command) {
  const raw = (command || "proses").toString().trim().toLowerCase();
  const clean =
    raw.replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim() || "proses";
  const label = clean
    .split(" ")
    .map((word) => (word ? word.charAt(0).toUpperCase() + word.slice(1) : word))
    .join(" ")
    .toUpperCase();
  let emoji = "⚡";
  for (const [key, value] of Object.entries(progressEmojiMap)) {
    if (clean.includes(key)) {
      emoji = value;
      break;
    }
  }
  return `${emoji} ${label} PROSES`;
}

function getDynamicGreeting() {
  const hour = new Date().getHours();
  if (hour >= 4 && hour < 11) return "Good morning";
  if (hour >= 11 && hour < 15) return "Good afternoon";
  if (hour >= 15 && hour < 18) return "Good evening";
  return "Good night";
}

function getProgressContextInfo() {
  return {
    externalAdReply: {
      showAdAttribution: true,
      title: "WORLD MD",
      body: getDynamicGreeting(),
      mediaType: 1,
      renderLargerThumbnail: false,
      sourceUrl: "https://powered.world.market",
      thumbnail: progressThumbnail,
    },
  };
}

const lastMessageTime = {};
const pluginsPath = path.join(process.cwd(), "plugins");
const lastSent_participantUpdate = {};
let plugins = [];

reloadPlugins()
  .then((loadedPlugins) => {
    plugins = loadedPlugins;
    console.log(`[✔] Load All Plugins done...`);
  })
  .catch((error) => {
    console.error("Error loading plugins:", error);
  });

if (config.mode === "development") {
  const watcher = chokidar.watch(pluginsPath, {
    persistent: true,
    ignoreInitial: true,
    ignored: /(^|[\/\\])\../,
  });
  watcher.on("change", (filePath) => {
    if (filePath.endsWith(".js")) {
      logWithTime("Plugins", `File changed: ${filePath}`);
      reloadPlugins()
        .then((loadedPlugins) => {
          plugins = loadedPlugins;
        })
        .catch((error) => {
          console.error("Error reloading plugins:", error);
        });
    }
  });
  logWithTime("Plugins", "Watching plugins directory for changes...");
} else {
  logWithTime("Plugins", "Production mode - plugins watching disabled");
}

async function processMessage(sock, messageInfo) {
  const {
    remoteJid,
    isGroup,
    message,
    sender,
    pushName,
    fullText,
    prefix,
    command,
  } = messageInfo;
  const isPremiumUsers = isPremiumUser(sender);
  const isOwnerUsers = isOwner(sender);

  try {
    await maybeSendOwnerWelcome(sock, messageInfo);
  } catch (e) {
    console.error("Owner welcome direct error:", e?.message || e);
  }

  try {
    const shouldContinue = await handler.preProcess(sock, messageInfo);
    if (!shouldContinue) return;

    let truncatedContent =
      fullText.length > 10 ? fullText.slice(0, 10) + "..." : fullText;
    const isKnownCommand = plugins.some((p) => p.Commands.includes(command));
    const currentTime = Date.now();

    if (
      lastMessageTime[remoteJid] &&
      currentTime - lastMessageTime[remoteJid] < config.rate_limit &&
      isKnownCommand &&
      (prefix || !config.status_prefix) &&
      !isOwnerUsers
    ) {
      danger(pushName, `Rate limit : ${truncatedContent}`);
      return;
    }

    if (isKnownCommand && (prefix || !config.status_prefix)) {
      lastMessageTime[remoteJid] = currentTime;
    }

    if (
      truncatedContent.trim() &&
      isKnownCommand &&
      (prefix || !config.status_prefix)
    ) {
      const logMessage =
        config.mode === "development"
          ? () => log(pushName, truncatedContent)
          : () =>
              logWithTime(
                "CHAT",
                `${pushName}(${sender.split("@")[0]}) - ${truncatedContent}`,
              );
      logMessage();
    }

    if (
      (config.bot_destination.toLowerCase() === "group" && isGroup) ||
      (config.bot_destination.toLowerCase() === "private" && !isGroup)
    ) {
      if (!isOwnerUsers) {
        logWithTime(
          "SYSTEM",
          `Destination handle only - ${config.bot_destination} chat`,
        );
        return;
      }
    }

    let commandFound = false;
    for (const plugin of plugins) {
      if (plugin.Commands.includes(command)) {
        commandFound = true;
        if (plugin.OnlyPremium && !isPremiumUsers && !isOwnerUsers) {
          logTracking(`Handler - Bukan premium (${command})`);
          await sock.sendMessage(
            remoteJid,
            { text: mess.general.isPremium },
            { quoted: message },
          );
          return;
        }

        if (plugin.OnlyOwner && !isOwnerUsers) {
          logTracking(`Handler - Bukan Owner (${command})`);
          await sock.sendMessage(
            remoteJid,
            { text: mess.general.isOwner },
            { quoted: message },
          );
          return;
        }

        if (!isPremiumUsers && !isOwnerUsers && plugin.limitDeduction) {
          try {
            const dataUsers = await findUser(sender);
            if (!dataUsers) return;
            const [docId, userData] = dataUsers;
            const isLimitExceeded =
              userData.limit < plugin.limitDeduction || userData.limit < 1;
            if (isLimitExceeded) {
              logTracking("Limit exceeded");
              await sock.sendMessage(
                remoteJid,
                { text: mess.general.limit },
                { quoted: message },
              );
              return;
            }
            await updateUser(sender, {
              limit: userData.limit - plugin.limitDeduction,
            });
          } catch (error) {
            console.error(
              `Terjadi kesalahan saat mengurangi limit pengguna: ${error.message}`,
            );
          }
        }

        if (!messageInfo.__progressSent) {
          messageInfo.__progressSent = true;
          try {
            await sock.sendMessage(remoteJid, {
              react: { text: "⏳", key: message.key },
            });
          } catch {}
          try {
            await sock.sendMessage(
              remoteJid,
              {
                text: formatProgressCommand(command),
                contextInfo: getProgressContextInfo(),
              },
              { quoted: message },
            );
          } catch {}
        }

        try {
          await sock.sendMessage(remoteJid, {
            react: { text: "⏱️", key: message.key },
          });
        } catch {}

        let pluginResult;
        try {
          pluginResult = await plugin.handle(sock, messageInfo);
          try {
            await sock.sendMessage(remoteJid, {
              react: { text: "✅", key: message.key },
            });
          } catch {}
        } catch (err) {
          try {
            await sock.sendMessage(remoteJid, {
              react: { text: "❌", key: message.key },
            });
          } catch {}
          throw err;
        }

        logTracking(`Plugins - ${command} dijalankan oleh ${sender}`);
        if (pluginResult === false) {
          return;
        }
      }
    }

    if (config.commandSimilarity && !commandFound) {
      const closestCommand = findClosestCommand(command, plugins);
      if (closestCommand && command != "" && fullText.length < 20 && prefix) {
        logTracking(`Handler - Command tidak ditemukan (${command})`);
        logCustom(
          "error",
          `_Command *${command}* tidak ditemukan_ \n\n_Apakah maksud Anda *.${closestCommand}*?_`,
          "ERROR-COMMAND-NOT-FOUND.txt",
        );
        return await sock.sendMessage(
          remoteJid,
          {
            text: `_Command *${command}* tidak ditemukan_ \n\n_Apakah maksud Anda *.${closestCommand}*?_`,
          },
          { quoted: message },
        );
      }
    }
  } catch (error) {
    logCustom("error", error, "ERROR-processMessage.txt");
    danger(command, `Kesalahan di processMessage: ${error}`);
  }
}

async function participantUpdate(sock, messageInfo) {
  const { id, action, participants } = messageInfo;
  const now = Date.now();

  try {
    const settingGroups = await findGroup(id);
    const validActions = ["add", "remove", "promote", "demote"];
    if (validActions.includes(action)) {
      try {
        updateParticipant(sock, id, participants, action);
      } catch (e) {
        console.log("Error updating participant:", e);
      }
    } else {
      return console.log("Invalid action:", action);
    }

    if (isGroupBlocked(id)) {
      return;
    }

    if (settingGroups) {
      if (lastSent_participantUpdate[id]) {
        if (now - lastSent_participantUpdate[id] < config.rate_limit) {
          return console.log(chalk.redBright(`Rate limit : ${id}`));
        }
      }
      lastSent_participantUpdate[id] = now;
      await handleActiveFeatures(sock, messageInfo, settingGroups.fitur);
    }
  } catch (error) {
    logCustom("error", error, "ERROR-participantUpdate.txt");
    console.error(chalk.redBright(`Error: ${error.message}`));
  }
}

export { processMessage, participantUpdate };
