import { useEffect, useRef, useState } from "react";
import axios from "axios";
import { Menu, X, LockKeyhole, Video, UploadCloud, FileVideo, Check, Download, Share2, MessageCircle, BookOpen, Info, ArrowRight, RotateCcw, Smartphone, Settings2, Sun, Moon, Wand2, Sparkles, Package, Copy, RefreshCw } from "lucide-react";
import bgPark from "@/assets/bg-park.jpg";
import "@/App.css";

const BACKGROUNDS = {
  "night-park": { label: "Night Park", value: `url(${bgPark})`, hint: "Foto taman malam" },
  "aurora": { label: "Aurora", value: "conic-gradient(from 210deg at 50% 0%, #061620 0deg, #113442 60deg, #b7ff3c22 120deg, #68e7ff33 180deg, #1a2438 240deg, #061620 360deg)", hint: "Gradient hidup" },
  "neon-grid": { label: "Neon Grid", value: "linear-gradient(#050609 1px, transparent 1px) 0 0/48px 48px, linear-gradient(90deg, #050609 1px, transparent 1px) 0 0/48px 48px, radial-gradient(circle at 50% 30%, #b7ff3c33, transparent 55%), #060a10", hint: "Grid neon" },
  "minimal": { label: "Minimal", value: "linear-gradient(180deg, #0c1118 0%, #05070a 100%)", hint: "Polos gelap" },
};
const DEFAULT_PREFS = { background: "night-park", motion: true, theme: "dark" };

function usePreferences() {
  const [prefs, setPrefs] = useState(() => { try { return { ...DEFAULT_PREFS, ...JSON.parse(localStorage.getItem("sw_hdr_prefs") || "{}") }; } catch { return DEFAULT_PREFS; } });
  useEffect(() => {
    const root = document.documentElement;
    const bg = BACKGROUNDS[prefs.background] || BACKGROUNDS["night-park"];
    root.style.setProperty("--bg-image", bg.value);
    root.setAttribute("data-theme", prefs.theme);
    root.setAttribute("data-motion", prefs.motion ? "on" : "off");
    localStorage.setItem("sw_hdr_prefs", JSON.stringify(prefs));
  }, [prefs]);
  return [prefs, (patch) => setPrefs((p) => ({ ...p, ...patch }))];
}

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;
const GROUP_URL = "https://chat.whatsapp.com/DZsgZBxiiD86P7vDbp7OLF?s=cl&p=a&mlu=0&ilr=4";
const formatSize = (n) => n ? `${(n / 1024 / 1024).toFixed(1)} MB` : "—";
const formatDuration = (n) => n ? `${Math.floor(n / 60)}:${String(Math.floor(n % 60)).padStart(2, "0")}` : "—";

function Gate({ onGranted }) {
  const [joined, setJoined] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const join = () => { window.open(GROUP_URL, "_blank", "noopener,noreferrer"); setJoined(true); };
  return <div className="gate-screen"><div className="bg-layer" /><div className="gate-orbit" /><main className="gate-panel" data-testid="access-gate-modal">
    <div className="brand-mark"><Video size={24} /><span>SW <b>HDR</b></span></div><div className="gate-kicker"><LockKeyhole size={14} /> AKSES TERKUNCI</div>
    <h1>Naikkan level<br /><em>video kamu.</em></h1><p className="gate-copy">Untuk menggunakan fitur SW HDR, kamu wajib bergabung terlebih dahulu ke Group WhatsApp resmi kami.</p>
    <div className="benefits"><p>Di dalam group kamu dapatkan</p><span>🎬 Video HD hingga 1080p</span><span>📖 Tutorial penggunaan</span><span>🔥 Update fitur terbaru</span><span>💬 Komunitas SW HDR</span></div>
    {!confirm ? <>{joined && <div className="joined-note" data-testid="joined-status"><Check size={16} /> Link group sudah dibuka</div>}<button className="primary-button wide" data-testid="join-group-button" onClick={join}><MessageCircle size={18} /> JOIN GROUP WHATSAPP <ArrowRight size={17} /></button>{joined && <button className="text-button" data-testid="already-joined-button" onClick={() => setConfirm(true)}><Check size={17} /> SAYA SUDAH BERGABUNG</button>}</> : <div className="confirm-box" data-testid="access-confirmation-modal"><div className="gate-kicker"><Check size={14} /> KONFIRMASI AKSES</div><p>Pastikan kamu sudah bergabung ke Group WhatsApp SW HDR sebelum melanjutkan.</p><button className="primary-button wide" data-testid="continue-to-app-button" onClick={onGranted}><Check size={18} /> LANJUTKAN KE SW HDR</button><button className="outline-button wide" data-testid="reopen-group-button" onClick={join}><MessageCircle size={17} /> BUKA GROUP LAGI</button></div>}
    <small className="gate-foot">HD Status Video Enhancer · Developer: Dzul</small>
  </main></div>;
}

function Sidebar({ open, close, setPage, access, openInstall, canInstall, installed, openSettings }) { return <><div className={`sidebar-overlay ${open ? "show" : ""}`} onClick={close} data-testid="sidebar-overlay" /><aside className={`sidebar ${open ? "open" : ""}`} data-testid="sidebar"><div className="sidebar-head"><div className="brand-mark"><Video size={20} /><span>SW <b>HDR</b></span></div><button className="icon-button" data-testid="close-sidebar-button" onClick={close}><X size={21} /></button></div><nav><button data-testid="nav-home" onClick={() => { setPage("home"); close(); }}><Video size={18} /> Home</button><button className={!access ? "locked" : ""} data-testid="nav-enhancer" onClick={() => { if (access) setPage("home"); }}><FileVideo size={18} /> Video Enhancer {!access && <LockKeyhole size={14} />}</button><button data-testid="nav-tutorial" onClick={() => { setPage("tutorial"); close(); }}><BookOpen size={18} /> Tutorial</button><button data-testid="nav-group" onClick={() => window.open(GROUP_URL, "_blank")}><MessageCircle size={18} /> WhatsApp Group</button><button data-testid="nav-settings" onClick={() => { openSettings(); close(); }}><Settings2 size={18} /> Settings</button><button data-testid="nav-release" onClick={() => { setPage("release"); close(); }}><Package size={18} /> Auto Release</button>{!installed && <button data-testid="nav-install" className="nav-install" onClick={() => { openInstall(); close(); }}><Download size={18} /> Install App {canInstall && <b className="nav-badge">GRATIS</b>}</button>}<button data-testid="nav-about" onClick={() => { setPage("about"); close(); }}><Info size={18} /> About</button></nav><div className="sidebar-bottom">SW HDR<br /><span>Developer: Dzul</span></div></aside></> }

function SettingsModal({ open, close, prefs, update }) {
  if (!open) return null;
  return <div className="install-overlay" data-testid="settings-modal" onClick={close}><div className="install-modal settings-modal" onClick={(e) => e.stopPropagation()}>
    <button className="icon-button small install-close" data-testid="close-settings-modal" onClick={close}><X size={16} /></button>
    <div className="section-kicker"><Settings2 size={14} /> SETTINGS</div>
    <h2>Atur suasana kamu.</h2>
    <p>Ganti background, atur gerakan ambient, dan pilih tema terang atau gelap.</p>

    <div className="pref-block">
      <div className="pref-head"><Wand2 size={15} /><b>Background</b></div>
      <div className="bg-grid">{Object.entries(BACKGROUNDS).map(([id, cfg]) => <button key={id} className={`bg-swatch ${prefs.background === id ? "active" : ""}`} data-testid={`bg-${id}-button`} onClick={() => update({ background: id })} style={{ backgroundImage: cfg.value.includes("url(") ? cfg.value : undefined, background: cfg.value.includes("url(") ? undefined : cfg.value }}><span>{cfg.label}</span><small>{cfg.hint}</small>{prefs.background === id && <Check size={14} className="bg-check" />}</button>)}</div>
    </div>

    <div className="pref-block">
      <div className="pref-head"><Sparkles size={15} /><b>Ambient motion</b><span className="pref-note">Parallax lembut & drift latar</span></div>
      <div className="toggle-row">
        <button className={`toggle-pill ${prefs.motion ? "on" : ""}`} data-testid="motion-toggle" onClick={() => update({ motion: !prefs.motion })}><span /></button>
        <b>{prefs.motion ? "AKTIF" : "NONAKTIF"}</b>
      </div>
    </div>

    <div className="pref-block">
      <div className="pref-head">{prefs.theme === "light" ? <Sun size={15} /> : <Moon size={15} />}<b>Tema</b></div>
      <div className="theme-row"><button className={`theme-chip ${prefs.theme === "dark" ? "active" : ""}`} data-testid="theme-dark-button" onClick={() => update({ theme: "dark" })}><Moon size={14} /> Gelap</button><button className={`theme-chip ${prefs.theme === "light" ? "active" : ""}`} data-testid="theme-light-button" onClick={() => update({ theme: "light" })}><Sun size={14} /> Terang</button></div>
    </div>
  </div></div>;
}

function CompareSlider({ originalUrl, resultUrl }) {
  const [pos, setPos] = useState(50);
  const containerRef = useRef();
  const originalRef = useRef();
  const resultRef = useRef();
  const dragging = useRef(false);
  const sync = () => { const a = originalRef.current, b = resultRef.current; if (!a || !b) return; if (Math.abs(a.currentTime - b.currentTime) > 0.25) b.currentTime = a.currentTime; if (!a.paused && b.paused) b.play().catch(() => {}); if (a.paused && !b.paused) b.pause(); };
  const startDrag = (e) => { dragging.current = true; if (e.cancelable) e.preventDefault(); };
  useEffect(() => {
    const move = (e) => { if (!dragging.current || !containerRef.current) return; const x = e.touches?.[0]?.clientX ?? e.clientX; const rect = containerRef.current.getBoundingClientRect(); setPos(Math.min(100, Math.max(0, ((x - rect.left) / rect.width) * 100))); };
    const stop = () => { dragging.current = false; };
    window.addEventListener("mousemove", move); window.addEventListener("mouseup", stop); window.addEventListener("touchmove", move, { passive: false }); window.addEventListener("touchend", stop);
    return () => { window.removeEventListener("mousemove", move); window.removeEventListener("mouseup", stop); window.removeEventListener("touchmove", move); window.removeEventListener("touchend", stop); };
  }, []);
  return <div className="compare-slider" data-testid="quality-comparison" ref={containerRef}>
    <video ref={originalRef} src={originalUrl} controls playsInline onPlay={sync} onPause={sync} onSeeked={sync} onTimeUpdate={sync} data-testid="comparison-original-video" />
    <div className="compare-clip" style={{ clipPath: `inset(0 0 0 ${pos}%)` }}><video ref={resultRef} src={resultUrl} muted playsInline data-testid="comparison-result-video" /></div>
    <span className="compare-tag left">ORIGINAL</span><span className="compare-tag right">SW HDR</span>
    <div className="compare-handle" style={{ left: `${pos}%` }} onMouseDown={startDrag} onTouchStart={startDrag} data-testid="compare-slider-handle" role="slider" aria-label="Compare original vs SW HDR" aria-valuenow={Math.round(pos)} aria-valuemin={0} aria-valuemax={100} tabIndex={0} onKeyDown={(e) => { if (e.key === "ArrowLeft") setPos((p) => Math.max(0, p - 5)); if (e.key === "ArrowRight") setPos((p) => Math.min(100, p + 5)); }}><span>⇔</span></div>
  </div>;
}

function useInstallPrompt() {
  const [prompt, setPrompt] = useState(null);
  const [installed, setInstalled] = useState(() => window.matchMedia?.("(display-mode: standalone)").matches || window.navigator.standalone === true);
  useEffect(() => {
    const capture = (e) => { e.preventDefault(); setPrompt(e); };
    const done = () => { setInstalled(true); setPrompt(null); };
    window.addEventListener("beforeinstallprompt", capture);
    window.addEventListener("appinstalled", done);
    return () => { window.removeEventListener("beforeinstallprompt", capture); window.removeEventListener("appinstalled", done); };
  }, []);
  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent) && !window.MSStream;
  return { prompt, installed, isIOS, install: async () => { if (!prompt) return "unsupported"; prompt.prompt(); const choice = await prompt.userChoice; setPrompt(null); return choice.outcome; } };
}

function ReleasePage({ onClose }) {
  const [info, setInfo] = useState(null);
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);
  const load = async () => { setBusy(true); try { const r = await axios.get(`${API}/release/info`, { params: { _: Date.now() } }); setInfo(r.data); } catch { setInfo({ error: true }); } setBusy(false); };
  useEffect(() => { load(); }, []);
  const copyHash = async () => { if (!info?.sha256) return; try { await navigator.clipboard.writeText(info.sha256); setCopied(true); setTimeout(() => setCopied(false), 1400); } catch {} };
  const kb = (n) => n < 1024 * 1024 ? `${(n / 1024).toFixed(1)} KB` : `${(n / 1024 / 1024).toFixed(2)} MB`;
  return <section className="info-page release-page" data-testid="release-page">
    <button className="back-link" data-testid="release-back-button" onClick={onClose}>← Back to enhancer</button>
    <div className="section-kicker"><Package size={12} /> SW HDR / AUTO RELEASE</div>
    <h2>Selalu ambil yang <em>terbaru.</em></h2>
    <p>Bundle source code ini di-generate otomatis dari kondisi terakhir server. Setiap kali kode berubah, versi baru langsung tersedia.</p>
    {info?.error ? <div className="error-block"><p className="error-note">⚠ Gagal memuat info release. Coba refresh.</p></div> : !info ? <p className="processing-note">Memuat info release...</p> : <><div className="release-meta"><div><span>VERSION</span><b data-testid="release-version">{info.version}</b></div><div><span>FILE COUNT</span><b>{info.files}</b></div><div><span>SIZE</span><b>{kb(info.size)}</b></div><div className="release-hash"><span>SHA-256</span><b data-testid="release-sha256">{info.sha256}</b><button className="icon-button small" data-testid="copy-hash-button" onClick={copyHash} title="Salin hash">{copied ? <Check size={14} /> : <Copy size={14} />}</button></div></div>
    <div className="release-actions"><a className="primary-button" data-testid="download-release-button" href={`${API}/release/download`} download><Download size={18} /> DOWNLOAD ZIP</a><button className="outline-button" data-testid="refresh-release-button" onClick={load} disabled={busy}>{busy ? <><span className="spinner" style={{ borderTopColor: "#fff" }} /> MEMUAT...</> : <><RefreshCw size={16} /> REFRESH</>}</button></div>
    <div className="tip"><b>Auto Release</b><p>Zip dihasilkan on-demand dari kode saat request. Bila source belum berubah, bytes-nya identik (SHA-256 tetap sama). Update kode → refresh → hash & versi ikut berganti.</p></div>
    <div className="release-tree"><div className="section-kicker">ISI PAKET</div><ul><li><b>backend/</b> — server.py, requirements.txt, tests/, .env.example</li><li><b>frontend/</b> — src/ (App.js, App.css, assets), public/ (manifest, service-worker, icons), package.json, craco/tailwind/postcss configs, .env.example</li><li><b>README.md</b> — panduan install & jalankan lokal</li></ul></div></>}
  </section>;
}

function InstallModal({ open, close, install, isIOS, hasPrompt }) {
  if (!open) return null;
  return <div className="install-overlay" data-testid="install-modal" onClick={close}><div className="install-modal" onClick={(e) => e.stopPropagation()}>
    <button className="icon-button small install-close" data-testid="close-install-modal" onClick={close}><X size={16} /></button>
    <div className="section-kicker"><Smartphone size={14} /> INSTALL SW HDR</div>
    <h2>Pasang di perangkat, akses satu ketuk.</h2>
    <p>Install SW HDR sebagai app gratis. Buka lebih cepat, layar penuh, dan siap dipakai kapan pun.</p>
    {hasPrompt ? <button className="primary-button wide" data-testid="install-app-button" onClick={async () => { await install(); close(); }}><Download size={17} /> INSTALL APP GRATIS</button> : isIOS ? <ol className="steps ios-steps">
      <li><b>01</b>Ketuk ikon <b>Bagikan</b> di Safari.</li>
      <li><b>02</b>Pilih <b>Tambahkan ke Layar Utama</b>.</li>
      <li><b>03</b>Tekan <b>Tambah</b>. SW HDR muncul di home screen.</li>
    </ol> : <ol className="steps ios-steps">
      <li><b>01</b>Buka menu browser (⋮ di Chrome / ⋯ di Edge).</li>
      <li><b>02</b>Pilih <b>Install app</b> atau <b>Tambahkan ke Layar Utama</b>.</li>
      <li><b>03</b>Konfirmasi. SW HDR terpasang sebagai app.</li>
    </ol>}
    <small className="gate-foot">Gratis · Tanpa store · Hemat data</small>
  </div></div>;
}

function InfoPage({ type, onClose }) { return <section className="info-page" data-testid={`${type}-page`}><button className="back-link" data-testid="info-back-button" onClick={onClose}>← Back to enhancer</button><div className="section-kicker">SW HDR / {type === "tutorial" ? "TUTORIAL" : "ABOUT"}</div><h2>{type === "tutorial" ? "Cara Pakai SW HDR" : "Simple tools. Better status."}</h2>{type === "tutorial" ? <><p>Proses video kamu menjadi lebih siap untuk dibagikan ke Status WhatsApp.</p><ol className="steps">{["Selesaikan akses Group WhatsApp.","Masukkan video dari perangkat.","Pilih kualitas output hingga 1080p.","Tekan PROCESS TO 1080P.","Tunggu proses selesai.","Preview, download, atau bagikan video."] .map((x,i)=><li key={x}><b>0{i+1}</b>{x}</li>)}</ol><div className="tip"><b>Tips Upload Status WhatsApp</b><p>Gunakan kualitas sumber terbaik, hindari kompresi berulang, dan gunakan koneksi internet stabil.</p></div></> : <><p>Aplikasi web untuk membantu memproses dan mengoptimalkan video untuk kebutuhan Status WhatsApp.</p><div className="about-sign"><div className="brand-mark"><Video size={20} /><span>SW <b>HDR</b></span></div><span>Developed by Dzul</span></div></>}</section> }

function App() {
  const [access, setAccess] = useState(() => localStorage.getItem("sw_hdr_group_access") === "granted"); const [drawer, setDrawer] = useState(false); const [page, setPage] = useState(() => window.location.hash === "#release" ? "release" : "home"); const [file, setFile] = useState(null); const [meta, setMeta] = useState(null); const [job, setJob] = useState(null); const [quality, setQuality] = useState("1080p"); const [preset, setPreset] = useState("none"); const [busy, setBusy] = useState(false); const [uploadProgress, setUploadProgress] = useState(0); const [uploadCancelled, setUploadCancelled] = useState(false); const [installOpen, setInstallOpen] = useState(false); const [settingsOpen, setSettingsOpen] = useState(false); const inputRef = useRef(); const uploadController = useRef(null);
  useEffect(() => { const sync = () => setPage(window.location.hash === "#release" ? "release" : "home"); window.addEventListener("hashchange", sync); return () => window.removeEventListener("hashchange", sync); }, []);
  useEffect(() => { if (page === "release" && window.location.hash !== "#release") window.history.replaceState(null, "", "#release"); if (page !== "release" && window.location.hash === "#release") window.history.replaceState(null, "", " "); }, [page]);
  const [prefs, updatePrefs] = usePreferences();
  const installer = useInstallPrompt();
  const showInstall = !installer.installed;
  const [previewUrl, setPreviewUrl] = useState(null);
  useEffect(() => { if (!file) { setPreviewUrl(null); return; } const url = URL.createObjectURL(file); setPreviewUrl(url); return () => URL.revokeObjectURL(url); }, [file]);
  const grant = () => { localStorage.setItem("sw_hdr_group_access", "granted"); setAccess(true); };
  const choose = async (selected) => { if (!selected) return; setBusy(true); setUploadProgress(0); setUploadCancelled(false); uploadController.current = new AbortController(); try { const data = new FormData(); data.append("file", selected); const res = await axios.post(`${API}/upload`, data, { signal: uploadController.current.signal, onUploadProgress: (event) => event.total && setUploadProgress(Math.round(event.loaded * 100 / event.total)) }); setFile(selected); setMeta(res.data); setJob(null); } catch (e) { if (e.code !== "ERR_CANCELED") alert(e.response?.data?.detail || "Upload gagal."); } finally { setBusy(false); uploadController.current = null; } };
  const cancelUpload = () => { uploadController.current?.abort(); setUploadCancelled(true); setBusy(false); setUploadProgress(0); };
  const process = async () => { if (!meta) return; setBusy(true); setJob({ status: "queued", progress: 0, message: "Antrian pemrosesan..." }); try { await axios.post(`${API}/process`, { jobId: meta.jobId, quality, preset }); const timer = setInterval(async () => { try { const res = await axios.get(`${API}/progress/${meta.jobId}`); setJob(res.data); if (["completed", "error"].includes(res.data.status)) { clearInterval(timer); setBusy(false); } } catch (e) { clearInterval(timer); setBusy(false); setJob({ status: "error", progress: 0, message: "Progress pemrosesan tidak tersedia. Coba lagi." }); } }, 900); } catch (e) { setBusy(false); setJob({ status: "error", progress: 0, message: e.response?.data?.detail || "Pemrosesan tidak dapat dimulai." }); } };
  const share = async () => { try { if (navigator.share) await navigator.share({ title: "SW HDR video", text: "Video HD saya dari SW HDR", url: `${API}/download/${meta.jobId}` }); else window.open(`https://wa.me/?text=${encodeURIComponent("Video HD saya dari SW HDR: " + window.location.origin)}`, "_blank"); } catch (e) { if (e.name !== "AbortError") alert("Bagikan dibatalkan atau tidak tersedia."); } };
  const InstallBtn = showInstall ? <button className="install-chip" data-testid="topbar-install-button" onClick={() => setInstallOpen(true)}><Download size={14} /> Install<b>gratis</b></button> : null;
  const installModal = <InstallModal open={installOpen} close={() => setInstallOpen(false)} install={installer.install} isIOS={installer.isIOS} hasPrompt={!!installer.prompt} />;
  const settingsModal = <SettingsModal open={settingsOpen} close={() => setSettingsOpen(false)} prefs={prefs} update={updatePrefs} />;
  const sidebar = <Sidebar open={drawer} close={() => setDrawer(false)} setPage={setPage} access={access} openInstall={() => setInstallOpen(true)} canInstall={!!installer.prompt} installed={installer.installed} openSettings={() => setSettingsOpen(true)} />;
  if (!access) return <>{installModal}{settingsModal}<Gate onGranted={grant} /></>;
  if (page !== "home") return <div className="app-shell"><div className="bg-layer" /><header className="topbar"><button className="icon-button" data-testid="open-sidebar-button" onClick={() => setDrawer(true)}><Menu /></button><div className="top-brand"><b>SW HDR</b><span>HD Status Video Enhancer</span></div>{InstallBtn}</header>{sidebar}{page === "release" ? <ReleasePage onClose={() => setPage("home")} /> : <InfoPage type={page} onClose={() => setPage("home")} />}{installModal}{settingsModal}</div>;
  return <div className="app-shell"><div className="bg-layer" /><header className="topbar"><button className="icon-button" data-testid="open-sidebar-button" onClick={() => setDrawer(true)}><Menu /></button><div className="top-brand"><b>SW HDR</b><span>HD Status Video Enhancer</span></div>{InstallBtn}<div className="status-chip"><span /> READY</div></header>{sidebar}<main className="workspace"><section className="intro"><div className="section-kicker">VIDEO ENHANCER / ONLINE</div><h1>Make every frame<br /><em>status-worthy.</em></h1><p>Optimalkan video kamu untuk kualitas HD hingga 4K UHD.</p></section>
    {!file ? <div className="upload-zone" role="button" tabIndex="0" data-testid="video-upload-zone" onKeyDown={(e) => { if (["Enter", " "].includes(e.key)) { e.preventDefault(); !busy && inputRef.current.click(); } }} onClick={() => !busy && inputRef.current.click()} onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); !busy && choose(e.dataTransfer.files[0]); }}><input ref={inputRef} type="file" hidden accept="video/mp4,video/quicktime,video/webm,video/x-matroska" onChange={(e) => choose(e.target.files[0])} data-testid="video-file-input" />{busy ? <><div className="upload-icon"><span className="spinner" /></div><strong>Uploading video... {uploadProgress}%</strong><div className="upload-progress"><div style={{ width: `${uploadProgress}%` }} /></div><span className="outline-button cancel-upload" role="button" tabIndex="0" data-testid="cancel-upload-button" onClick={(e) => { e.stopPropagation(); cancelUpload(); }} onKeyDown={(e) => { if (["Enter", " "].includes(e.key)) { e.stopPropagation(); cancelUpload(); } }}>BATAL UPLOAD</span></> : <><div className="upload-icon"><UploadCloud size={28} /></div><strong>Tap di sini buat masukin video</strong><span>Upload video kamu dan proses hingga kualitas 4K UHD.</span><small>MP4 · MOV · WEBM · MKV <i>Max 100 MB</i></small></>}{uploadCancelled && <small className="cancelled-note" data-testid="upload-cancelled-message">Upload dibatalkan. Pilih video lain.</small>}</div> : <section className="editor-section" data-testid="video-editor"><div className="video-frame"><video src={previewUrl} controls data-testid="source-video-preview" /></div><div className="file-line"><FileVideo size={18} /><div><b data-testid="source-file-name">{meta.fileName}</b><span data-testid="source-file-details">{formatSize(meta.size)} · {formatDuration(meta.duration)} · {meta.width} × {meta.height}</span></div><button className="icon-button small" data-testid="remove-video-button" onClick={() => { setFile(null); setMeta(null); }}><X size={16} /></button></div><div className="quality-head"><div><div className="section-kicker">OUTPUT QUALITY</div><p>Output mempertahankan rasio sumber. Pilih hingga 4K UHD.</p></div><span>UP TO 4K</span></div><div className="quality-grid">{[["original","Original","Sesuai sumber"],["720p","720p HD","tinggi 720px"],["1080p","1080p FULL HD","tinggi 1080px"],["1440p","2K QHD","tinggi 1440px"],["2160p","4K UHD","tinggi 2160px"]].map(([id,label,detail]) => <button className={quality === id ? "quality active" : "quality"} data-testid={`quality-${id}-button`} key={id} onClick={() => setQuality(id)}><span>{label}</span><i className="quality-detail">{detail}</i>{id === "1080p" && <b>RECOMMENDED</b>}{id === "2160p" && <b className="quality-warn">HEAVY</b>}</button>)}</div><div className="preset-row"><div><div className="section-kicker">STATUS PRESET</div><p>Pilih format siap bagikan untuk platform favorit kamu.</p></div><div className="preset-grid">{[["whatsapp_status","WhatsApp Status","9:16 · 720p"],["portrait","Portrait","9:16 · 720p"],["landscape","Landscape","16:9 · 720p"],["whatsapp_feed","WhatsApp Feed","1:1 · 1080p"]].map(([id,label,detail]) => <button className={preset === id ? "preset active" : "preset"} data-testid={`${id}-preset-button`} key={id} onClick={() => { setPreset(preset === id ? "none" : id); if (id === "whatsapp_status" || id === "portrait" || id === "landscape") setQuality("720p"); if (id === "whatsapp_feed") setQuality("1080p"); }}><MessageCircle size={16} /><span>{label}</span><b>{detail}</b></button>)}</div></div><button className="primary-button process-button" data-testid="process-video-button" onClick={process} disabled={busy}>{busy ? <><span className="spinner" /> PROCESSING...</> : preset !== "none" ? `✨ PROCESS ${preset === "whatsapp_status" ? "FOR STATUS" : "WITH PRESET"}` : `✨ PROCESS TO ${({original:"ORIGINAL","720p":"720P","1080p":"1080P","1440p":"2K","2160p":"4K"})[quality]}`}</button></section>}
    {job && <section className="result-section" data-testid="processing-result"><div className="result-head"><div><div className="section-kicker">{job.status === "completed" ? "PROCESS COMPLETE" : "PROCESSING"}</div><h2>{job.status === "completed" ? "Video berhasil diproses" : `${job.message} ${job.progress}%`}</h2></div><div className="progress-value">{job.progress}%</div></div><div className="progress-track"><div style={{ width: `${job.progress}%` }} /></div>{job.status === "completed" ? <><CompareSlider originalUrl={previewUrl} resultUrl={`${API}/download/${meta.jobId}`} /><div className="result-stats"><span><b>{job.width} × {job.height}</b> OUTPUT RESOLUTION</span><span><b>{formatSize(job.size)}</b> FILE SIZE</span></div><div className="result-actions"><a className="primary-button" data-testid="download-hd-button" href={`${API}/download/${meta.jobId}`} download><Download size={18} /> DOWNLOAD HD VIDEO</a><button className="outline-button" data-testid="share-whatsapp-button" onClick={share}><Share2 size={18} /> BAGIKAN KE WHATSAPP</button>{showInstall && <button className="outline-button" data-testid="install-from-result-button" onClick={() => setInstallOpen(true)}><Smartphone size={18} /> INSTALL APP GRATIS</button>}<button className="text-button" data-testid="process-new-video-button" onClick={() => { setFile(null); setMeta(null); setJob(null); }}><RotateCcw size={16} /> PROCESS NEW VIDEO</button></div></> : job.status === "error" ? <div className="error-block" data-testid="processing-error"><p className="processing-note error-note">⚠ {job.message}</p><div className="result-actions"><button className="primary-button" data-testid="retry-process-button" onClick={process} disabled={busy}><RotateCcw size={16} /> COBA LAGI</button><button className="outline-button" data-testid="process-new-video-error-button" onClick={() => { setFile(null); setMeta(null); setJob(null); }}>PILIH VIDEO LAIN</button></div></div> : <p className="processing-note" data-testid="processing-status">{job.message}</p>}</section>}
    <footer><span>SW HDR / HD Status Video Enhancer</span><span>© 2026 · Developer: Dzul</span></footer></main>{installModal}{settingsModal}</div>;
}
export default App;