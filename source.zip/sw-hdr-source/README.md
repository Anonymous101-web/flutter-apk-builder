# SW HDR — HD Status Video Enhancer

Aplikasi web untuk memproses & mengoptimalkan video hingga **4K UHD**, khususnya untuk kebutuhan Status WhatsApp.

**Developer:** Dzul

## Fitur
- Group WhatsApp Access Gate (localStorage)
- Upload video (MP4/MOV/WEBM/MKV) max 100 MB / 5 menit
- Kualitas Original / 720p / 1080p / 2K QHD / 4K UHD (aspect ratio dijaga)
- Status Preset: WhatsApp Status, Portrait, Landscape, WhatsApp Feed
- Compare Slider before/after, download, share ke WhatsApp
- PWA installable, Settings (background, ambient motion, dark/light)

## Stack
- Frontend: React 19 + CRA/craco + Axios + lucide-react
- Backend: FastAPI + Motor (MongoDB) + FFmpeg subprocess

## Menjalankan Lokal

### Prasyarat
- Node.js 18+, Python 3.10+, MongoDB, FFmpeg

### Backend
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

### Frontend
```bash
cd frontend
yarn install
cp .env.example .env
yarn start
```

Buka http://localhost:3000

© 2026 SW HDR · Developed by Dzul
