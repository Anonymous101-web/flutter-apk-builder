from fastapi import FastAPI, APIRouter, UploadFile, File, HTTPException, Request
from fastapi.responses import FileResponse, Response
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from motor.motor_asyncio import AsyncIOMotorClient
from pathlib import Path
import asyncio, hashlib, io, os, re, shutil, subprocess, uuid, time, zipfile

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")
WORK_DIR = ROOT_DIR / "video_jobs"
WORK_DIR.mkdir(exist_ok=True)
MAX_BYTES = 100 * 1024 * 1024
MAX_DURATION = 300
ALLOWED_EXTENSIONS = {".mp4", ".mov", ".webm", ".mkv"}
jobs = {}
rate_buckets = {}
RATE_WINDOW = 600
RATE_LIMITS = {"upload": 12, "process": 24}
mongo_client = AsyncIOMotorClient(os.environ["MONGO_URL"])
db = mongo_client[os.environ["DB_NAME"]]
cleanup_task = None

app = FastAPI(title="SW HDR API")
api_router = APIRouter(prefix="/api")

class ProcessRequest(BaseModel):
    jobId: str
    quality: str = "1080p"
    preset: str = "none"

PRESETS = {"none": "", "whatsapp_status": "scale=720:1280:force_original_aspect_ratio=decrease,pad=720:1280:(ow-iw)/2:(oh-ih)/2,setsar=1", "landscape": "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,setsar=1", "portrait": "scale=720:1280:force_original_aspect_ratio=decrease,pad=720:1280:(ow-iw)/2:(oh-ih)/2,setsar=1", "whatsapp_feed": "scale=1080:1080:force_original_aspect_ratio=decrease,pad=1080:1080:(ow-iw)/2:(oh-ih)/2,setsar=1"}

async def enforce_rate(request: Request, action: str):
    now = time.monotonic()
    forwarded = request.headers.get("x-forwarded-for", "").split(",")[0].strip()
    identity = forwarded or request.headers.get("x-real-ip", "").strip() or "shared-ingress"
    key = f"{identity}:{action}"
    try:
        record = await db.sw_hdr_rate_limits.find_one({"_id": key})
        if not record or time.time() - record.get("window_start", 0) >= RATE_WINDOW:
            await db.sw_hdr_rate_limits.update_one({"_id": key}, {"$set": {"window_start": time.time(), "count": 1}}, upsert=True)
            return
        count = int(record.get("count", 0))
        if count >= RATE_LIMITS[action]:
            raise HTTPException(429, "Terlalu banyak permintaan. Tunggu beberapa menit lalu coba lagi.", headers={"Retry-After": str(RATE_WINDOW)})
        await db.sw_hdr_rate_limits.update_one({"_id": key}, {"$inc": {"count": 1}})
        return
    except HTTPException:
        raise
    except Exception:
        pass
    recent = [stamp for stamp in rate_buckets.get(key, []) if now - stamp < RATE_WINDOW]
    if len(recent) >= RATE_LIMITS[action]:
        raise HTTPException(429, "Terlalu banyak permintaan. Tunggu beberapa menit lalu coba lagi.", headers={"Retry-After": str(RATE_WINDOW)})
    recent.append(now)
    rate_buckets[key] = recent

def safe_name(name: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9._-]", "_", name or "video.mp4")
    return cleaned[:120] or "video.mp4"

def probe(path: Path):
    try:
        result = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=width,height", "-of", "json", str(path)], capture_output=True, text=True, timeout=20)
        import json
        data = json.loads(result.stdout)
        video = next((s for s in data.get("streams", []) if "width" in s), {})
        return float(data.get("format", {}).get("duration", 0) or 0), int(video.get("width", 0) or 0), int(video.get("height", 0) or 0)
    except Exception as exc:
        raise HTTPException(400, "File video tidak dapat dibaca. Pastikan formatnya valid.") from exc

@api_router.get("/")
async def root():
    return {"message": "SW HDR ready"}

@api_router.post("/upload")
async def upload_video(request: Request, file: UploadFile = File(...)):
    await enforce_rate(request, "upload")
    extension = Path(file.filename or "").suffix.lower()
    if extension not in ALLOWED_EXTENSIONS or not (file.content_type or "").startswith("video/"):
        raise HTTPException(400, "Format video harus MP4, MOV, WEBM, atau MKV.")
    job_id = f"job_{uuid.uuid4().hex[:12]}"
    folder = WORK_DIR / job_id
    folder.mkdir()
    input_path = folder / safe_name(file.filename)
    total = 0
    with input_path.open("wb") as destination:
        while chunk := await file.read(1024 * 1024):
            total += len(chunk)
            if total > MAX_BYTES:
                shutil.rmtree(folder, ignore_errors=True)
                raise HTTPException(413, "Ukuran video maksimal 100 MB.")
            destination.write(chunk)
    duration, width, height = probe(input_path)
    if duration > MAX_DURATION:
        shutil.rmtree(folder, ignore_errors=True)
        raise HTTPException(400, "Durasi video maksimal 5 menit.")
    if duration <= 0 or width <= 0 or height <= 0:
        shutil.rmtree(folder, ignore_errors=True)
        raise HTTPException(400, "File video tidak dapat dibaca. Pastikan formatnya valid.")
    jobs[job_id] = {"folder": folder, "input": input_path, "duration": duration, "width": width, "height": height, "status": "uploaded", "progress": 0, "message": "Ready to process", "created_at": time.time()}
    return {"success": True, "jobId": job_id, "fileName": safe_name(file.filename), "size": total, "duration": duration, "width": width, "height": height}

async def run_process(job_id: str, quality: str, preset: str = "none"):
    job = jobs.get(job_id)
    if not job: return
    output = job["folder"] / "sw-hdr-output.mp4"
    job.update(status="processing", progress=0, message="Preparing video...", output=None, out_width=None, out_height=None, out_size=None, out_duration=None)
    try:
        target = {"original": None, "720p": 720, "1080p": 1080, "1440p": 1440, "2160p": 2160}.get(quality, 1080)
        scale = "" if not target else f"scale=-2:{target}"
        if preset != "none":
            scale = PRESETS[preset]
        command = ["ffmpeg", "-y", "-i", str(job["input"])]
        if scale: command += ["-vf", scale]
        command += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-c:a", "aac", "-movflags", "+faststart", str(output)]
        process = await asyncio.create_subprocess_exec(*command, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE)
        pattern = re.compile(r"time=(\d+):(\d+):(\d+\.\d+)")
        stderr_tail = []
        while True:
            line = await process.stderr.readline()
            if not line: break
            decoded = line.decode(errors="ignore")
            stderr_tail.append(decoded)
            if len(stderr_tail) > 40: stderr_tail.pop(0)
            match = pattern.search(decoded)
            if match and job["duration"]:
                seconds = int(match.group(1)) * 3600 + int(match.group(2)) * 60 + float(match.group(3))
                job["progress"] = min(99, int(seconds / job["duration"] * 100))
                job["message"] = ["Analyzing resolution...", "Processing video...", "Optimizing quality...", "Encoding 1080p...", "Finalizing..."][min(4, job["progress"] // 25)]
        code = await process.wait()
        if code != 0 or not output.exists() or output.stat().st_size == 0:
            hint = next((l for l in reversed(stderr_tail) if any(k in l.lower() for k in ("error", "invalid", "unable", "no such"))), "")
            job.update(status="error", progress=0, message=f"Pemrosesan gagal. {hint.strip()[:140] or 'Coba resolusi lain atau file lain.'}")
            return
        try:
            out_duration, out_width, out_height = probe(output)
        except HTTPException:
            out_duration, out_width, out_height = 0.0, 0, 0
        job.update(status="completed", progress=100, message="Video berhasil diproses", output=output, out_width=out_width, out_height=out_height, out_size=output.stat().st_size, out_duration=out_duration)
    except FileNotFoundError:
        job.update(status="error", progress=0, message="FFmpeg tidak tersedia di server.")
    except Exception as exc:
        job.update(status="error", progress=0, message=f"Pemrosesan gagal: {str(exc)[:160]}")

@api_router.post("/process")
async def process_video(request: Request, payload: ProcessRequest):
    await enforce_rate(request, "process")
    job = jobs.get(payload.jobId)
    if not job: raise HTTPException(404, "Job tidak ditemukan.")
    if job["status"] == "processing": return {"success": True, "jobId": payload.jobId}
    if payload.preset not in PRESETS:
        raise HTTPException(400, "Preset tidak tersedia.")
    if payload.quality not in {"original", "720p", "1080p", "1440p", "2160p"}:
        raise HTTPException(400, "Kualitas tidak dikenali.")
    job.update(status="queued", progress=0, message="Antrian pemrosesan...", output=None, out_width=None, out_height=None, out_size=None, out_duration=None)
    asyncio.create_task(run_process(payload.jobId, payload.quality, payload.preset))
    return {"success": True, "jobId": payload.jobId}

@api_router.get("/progress/{job_id}")
async def progress(job_id: str):
    job = jobs.get(job_id)
    if not job: raise HTTPException(404, "Job tidak ditemukan.")
    return {"status": job["status"], "progress": job["progress"], "message": job["message"], "width": job.get("out_width"), "height": job.get("out_height"), "size": job.get("out_size")}

@api_router.get("/download/{job_id}")
async def download(job_id: str):
    job = jobs.get(job_id)
    if not job or job.get("status") != "completed": raise HTTPException(404, "Video belum selesai diproses.")
    return FileResponse(job["output"], media_type="video/mp4", filename="sw-hdr-1080p.mp4")

RELEASE_ROOT = Path("/app")
RELEASE_INCLUDES = [("backend", ["server.py", "requirements.txt", "pytest.ini", "tests"]), ("frontend", ["src", "public", "package.json", "craco.config.js", "tailwind.config.js", "postcss.config.js", "jsconfig.json", "components.json", "plugins", "README.md"])]
RELEASE_EXCLUDE_DIRS = {"node_modules", "__pycache__", "video_jobs", "build", ".pytest_cache", ".git", ".venv", "dist", ".cache"}
RELEASE_EXCLUDE_FILES = {".env", "yarn.lock", "package-lock.json", ".DS_Store"}
RELEASE_README = """# SW HDR — HD Status Video Enhancer\n\nAplikasi web untuk memproses & mengoptimalkan video hingga **4K UHD**, khususnya untuk kebutuhan Status WhatsApp.\n\n**Developer:** Dzul\n\n## Fitur\n- Group WhatsApp Access Gate (localStorage)\n- Upload video (MP4/MOV/WEBM/MKV) max 100 MB / 5 menit\n- Kualitas Original / 720p / 1080p / 2K QHD / 4K UHD (aspect ratio dijaga)\n- Status Preset: WhatsApp Status, Portrait, Landscape, WhatsApp Feed\n- Compare Slider before/after, download, share ke WhatsApp\n- PWA installable, Settings (background, ambient motion, dark/light)\n\n## Stack\n- Frontend: React 19 + CRA/craco + Axios + lucide-react\n- Backend: FastAPI + Motor (MongoDB) + FFmpeg subprocess\n\n## Menjalankan Lokal\n\n### Prasyarat\n- Node.js 18+, Python 3.10+, MongoDB, FFmpeg\n\n### Backend\n```bash\ncd backend\npython -m venv .venv && source .venv/bin/activate\npip install -r requirements.txt\ncp .env.example .env\nuvicorn server:app --host 0.0.0.0 --port 8001 --reload\n```\n\n### Frontend\n```bash\ncd frontend\nyarn install\ncp .env.example .env\nyarn start\n```\n\nBuka http://localhost:3000\n\n© 2026 SW HDR · Developed by Dzul\n"""
_release_cache = {"mtime": 0.0, "data": None, "sha256": "", "files": 0}

def _release_iter_files():
    for root_name, includes in RELEASE_INCLUDES:
        base = RELEASE_ROOT / root_name
        for entry in includes:
            path = base / entry
            if not path.exists(): continue
            if path.is_file(): yield path, base
            else:
                for sub in sorted(path.rglob("*")):
                    if any(part in RELEASE_EXCLUDE_DIRS for part in sub.relative_to(base).parts): continue
                    if sub.name in RELEASE_EXCLUDE_FILES: continue
                    if sub.is_file(): yield sub, base

def _release_snapshot_mtime():
    latest = 0.0
    for file_path, _ in _release_iter_files():
        try: latest = max(latest, file_path.stat().st_mtime)
        except OSError: continue
    return latest

def _build_release_zip():
    buf = io.BytesIO()
    files = 0
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        zf.writestr("sw-hdr-source/README.md", RELEASE_README)
        zf.writestr("sw-hdr-source/backend/.env.example", "MONGO_URL=mongodb://localhost:27017\nDB_NAME=sw_hdr\nCORS_ORIGINS=*\n")
        zf.writestr("sw-hdr-source/frontend/.env.example", "REACT_APP_BACKEND_URL=http://localhost:8001\nWDS_SOCKET_PORT=443\n")
        for file_path, base in _release_iter_files():
            rel = file_path.relative_to(base.parent)
            zf.write(file_path, f"sw-hdr-source/{rel}")
            files += 1
    return buf.getvalue(), files

def _get_release():
    mtime = _release_snapshot_mtime()
    if _release_cache["data"] and abs(_release_cache["mtime"] - mtime) < 0.5:
        return _release_cache
    data, files = _build_release_zip()
    _release_cache.update(mtime=mtime, data=data, sha256=hashlib.sha256(data).hexdigest(), files=files)
    return _release_cache

@api_router.get("/release/info")
async def release_info():
    rel = _get_release()
    stamp = time.gmtime(rel["mtime"] or time.time())
    return {"version": time.strftime("%Y.%m.%d-%H%M", stamp), "size": len(rel["data"]), "sha256": rel["sha256"], "files": rel["files"], "generated_at": rel["mtime"], "filename": f"sw-hdr-{time.strftime('%Y%m%d-%H%M', stamp)}.zip"}

@api_router.get("/release/download")
async def release_download():
    rel = _get_release()
    stamp = time.gmtime(rel["mtime"] or time.time())
    filename = f"sw-hdr-{time.strftime('%Y%m%d-%H%M', stamp)}.zip"
    return Response(rel["data"], media_type="application/zip", headers={"Content-Disposition": f'attachment; filename="{filename}"', "X-Release-Sha256": rel["sha256"], "X-Release-Version": time.strftime("%Y.%m.%d-%H%M", stamp)})

app.include_router(api_router)
app.add_middleware(CORSMiddleware, allow_credentials=True, allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","), allow_methods=["*"], allow_headers=["*"])

@app.on_event("shutdown")
async def shutdown():
    if cleanup_task:
        cleanup_task.cancel()
    shutil.rmtree(WORK_DIR, ignore_errors=True)
    mongo_client.close()

async def cleanup_loop():
    while True:
        await asyncio.sleep(300)
        cutoff = time.time() - 1800
        for job_id, job in list(jobs.items()):
            if job.get("created_at", time.time()) < cutoff:
                shutil.rmtree(job["folder"], ignore_errors=True)
                jobs.pop(job_id, None)

@app.on_event("startup")
async def startup():
    global cleanup_task
    cleanup_task = asyncio.create_task(cleanup_loop())