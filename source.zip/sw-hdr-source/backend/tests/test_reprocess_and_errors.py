"""Bug-fix coverage: re-process with new quality/preset (state reset) and
guaranteed error-status transition for run_process background failures."""
import os
import shutil
import subprocess
import time
import uuid
from pathlib import Path

import pytest
import requests
from dotenv import dotenv_values

frontend_env = dotenv_values("/app/frontend/.env")
base_url = os.environ.get("REACT_APP_BACKEND_URL") or frontend_env.get("REACT_APP_BACKEND_URL")
if not base_url:
    raise RuntimeError("REACT_APP_BACKEND_URL missing")
BASE_URL = base_url.rstrip("/")

WORK_DIR = Path("/app/backend/video_jobs")


def ip_headers():
    """Unique x-forwarded-for per call so the IP rate bucket is never shared."""
    return {"X-Forwarded-For": f"203.0.113.{uuid.uuid4().int % 250 + 1}.{uuid.uuid4().int % 9000}"[:40]}


def unique_ip():
    n = uuid.uuid4().int
    return {"X-Forwarded-For": f"198.18.{n % 250}.{(n // 251) % 250}"}


@pytest.fixture(scope="module")
def video_file(tmp_path_factory):
    path = tmp_path_factory.mktemp("media") / "TEST_reprocess.mp4"
    subprocess.run(
        ["ffmpeg", "-y", "-f", "lavfi", "-i", "color=c=red:s=320x240:r=24",
         "-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo", "-t", "2",
         "-shortest", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", str(path)],
        check=True, capture_output=True,
    )
    return path


def upload(video_file):
    with video_file.open("rb") as stream:
        response = requests.post(
            f"{BASE_URL}/api/upload",
            files={"file": (video_file.name, stream, "video/mp4")},
            headers=unique_ip(),
            timeout=60,
        )
    assert response.status_code == 200, f"upload failed {response.status_code} {response.text[:300]}"
    return response.json()


def wait_terminal(job_id, timeout=90):
    deadline = time.time() + timeout
    payload = {}
    while time.time() < deadline:
        response = requests.get(f"{BASE_URL}/api/progress/{job_id}", timeout=30)
        assert response.status_code == 200, response.text[:200]
        payload = response.json()
        if payload["status"] in {"completed", "error"}:
            return payload
        time.sleep(0.5)
    return payload


# --- Regression: upload returns full metadata ---
def test_upload_returns_metadata(video_file):
    data = upload(video_file)
    assert data["success"] is True
    assert isinstance(data["jobId"], str) and data["jobId"].startswith("job_")
    assert data["fileName"] == "TEST_reprocess.mp4"
    assert isinstance(data["size"], int) and data["size"] > 0
    assert 1.5 <= float(data["duration"]) <= 2.5
    assert data["width"] == 320 and data["height"] == 240

    progress = requests.get(f"{BASE_URL}/api/progress/{data['jobId']}", timeout=30).json()
    assert progress["status"] == "uploaded"
    assert progress["width"] is None and progress["height"] is None


# --- Bug 1: 1080p + preset=none completes with dimensions/size ---
def test_process_1080p_none_completes(video_file):
    job_id = upload(video_file)["jobId"]
    started = requests.post(f"{BASE_URL}/api/process",
                            json={"jobId": job_id, "quality": "1080p", "preset": "none"},
                            headers=unique_ip(), timeout=30)
    assert started.status_code == 200 and started.json() == {"success": True, "jobId": job_id}

    final = wait_terminal(job_id)
    assert final["status"] == "completed", final
    assert final["progress"] == 100
    assert final["height"] == 1080
    assert final["width"] == 1440
    assert isinstance(final["size"], int) and final["size"] > 0
    assert final["message"]

    download = requests.get(f"{BASE_URL}/api/download/{job_id}", timeout=60)
    assert download.status_code == 200
    assert download.headers["content-type"].startswith("video/mp4")
    assert download.content[4:8] == b"ftyp"


# --- Bug 2: re-process SAME job with different quality + preset resets state ---
def test_reprocess_same_job_with_new_quality_and_preset(video_file):
    job_id = upload(video_file)["jobId"]

    first = requests.post(f"{BASE_URL}/api/process",
                          json={"jobId": job_id, "quality": "1080p", "preset": "none"},
                          headers=unique_ip(), timeout=30)
    assert first.status_code == 200
    first_final = wait_terminal(job_id)
    assert first_final["status"] == "completed", first_final
    assert first_final["height"] == 1080

    # second run: different quality AND preset on the same jobId
    second = requests.post(f"{BASE_URL}/api/process",
                           json={"jobId": job_id, "quality": "720p", "preset": "whatsapp_status"},
                           headers=unique_ip(), timeout=30)
    assert second.status_code == 200

    immediate = requests.get(f"{BASE_URL}/api/progress/{job_id}", timeout=30).json()
    assert immediate["status"] in {"queued", "processing"}, f"stale state leaked: {immediate}"
    assert immediate["progress"] < 100
    assert immediate["width"] is None and immediate["height"] is None, f"stale dimensions: {immediate}"

    second_final = wait_terminal(job_id)
    assert second_final["status"] == "completed", second_final
    assert second_final["width"] == 720 and second_final["height"] == 1280

    # third run back to original quality, preset none
    third = requests.post(f"{BASE_URL}/api/process",
                          json={"jobId": job_id, "quality": "original", "preset": "none"},
                          headers=unique_ip(), timeout=30)
    assert third.status_code == 200
    third_final = wait_terminal(job_id)
    assert third_final["status"] == "completed", third_final
    assert third_final["width"] == 320 and third_final["height"] == 240


# --- Bug 5: 'queued' is observable synchronously after /process returns ---
def test_progress_reports_queued_or_processing_immediately(video_file):
    job_id = upload(video_file)["jobId"]
    started = requests.post(f"{BASE_URL}/api/process",
                            json={"jobId": job_id, "quality": "720p", "preset": "none"},
                            headers=unique_ip(), timeout=30)
    assert started.status_code == 200
    immediate = requests.get(f"{BASE_URL}/api/progress/{job_id}", timeout=30).json()
    assert immediate["status"] in {"queued", "processing"}, immediate
    assert immediate["size"] is None
    wait_terminal(job_id)


# --- Bug 4: invalid quality / preset rejected with 400 ---
@pytest.mark.parametrize("payload_extra, expected_detail", [
    ({"quality": "4k", "preset": "none"}, "Kualitas tidak dikenali."),
    ({"quality": "1080P", "preset": "none"}, "Kualitas tidak dikenali."),
    ({"quality": "", "preset": "none"}, "Kualitas tidak dikenali."),
    ({"quality": "1080p", "preset": "tiktok"}, "Preset tidak tersedia."),
    ({"quality": "1080p", "preset": "NONE"}, "Preset tidak tersedia."),
])
def test_process_rejects_invalid_inputs(video_file, payload_extra, expected_detail):
    job_id = upload(video_file)["jobId"]
    response = requests.post(f"{BASE_URL}/api/process",
                             json={"jobId": job_id, **payload_extra},
                             headers=unique_ip(), timeout=30)
    assert response.status_code == 400, response.text[:300]
    assert response.json()["detail"] == expected_detail
    # job must stay untouched / not stuck
    progress = requests.get(f"{BASE_URL}/api/progress/{job_id}", timeout=30).json()
    assert progress["status"] == "uploaded", progress


def test_process_unknown_job_returns_404():
    response = requests.post(f"{BASE_URL}/api/process",
                             json={"jobId": "job_doesnotexist", "quality": "1080p"},
                             headers=unique_ip(), timeout=30)
    assert response.status_code == 404
    assert response.json()["detail"] == "Job tidak ditemukan."


def test_progress_unknown_job_returns_404():
    response = requests.get(f"{BASE_URL}/api/progress/job_nope", timeout=30)
    assert response.status_code == 404


# --- Bug 3: background failure ALWAYS yields status='error', never stuck ---
def test_background_failure_transitions_to_error(video_file):
    """Simulate an unexpected runtime failure by removing the source file on disk
    after upload; run_process must catch it and set status='error'."""
    job_id = upload(video_file)["jobId"]
    folder = WORK_DIR / job_id
    if not folder.exists():
        pytest.skip(f"job folder not visible on this filesystem: {folder}")
    for child in folder.iterdir():
        child.unlink()

    started = requests.post(f"{BASE_URL}/api/process",
                            json={"jobId": job_id, "quality": "1080p", "preset": "none"},
                            headers=unique_ip(), timeout=30)
    assert started.status_code == 200

    final = wait_terminal(job_id, timeout=60)
    assert final["status"] == "error", f"job stuck instead of error: {final}"
    assert isinstance(final["message"], str) and len(final["message"]) > 5
    assert final["progress"] == 0

    # download must not serve anything for a failed job
    download = requests.get(f"{BASE_URL}/api/download/{job_id}", timeout=30)
    assert download.status_code == 404

    # a failed job must be retryable (frontend retry button)
    shutil.rmtree(folder, ignore_errors=True)


def test_error_job_can_be_retried_after_source_restored(video_file):
    """After an error, /process must accept a new run and not stay in error."""
    data = upload(video_file)
    job_id = data["jobId"]
    folder = WORK_DIR / job_id
    if not folder.exists():
        pytest.skip("job folder not visible")
    source = next(folder.iterdir())
    backup = source.read_bytes()
    source.unlink()

    requests.post(f"{BASE_URL}/api/process", json={"jobId": job_id, "quality": "720p"},
                  headers=unique_ip(), timeout=30)
    assert wait_terminal(job_id, timeout=60)["status"] == "error"

    source.write_bytes(backup)
    retry = requests.post(f"{BASE_URL}/api/process",
                          json={"jobId": job_id, "quality": "720p", "preset": "none"},
                          headers=unique_ip(), timeout=30)
    assert retry.status_code == 200
    final = wait_terminal(job_id)
    assert final["status"] == "completed", final
    assert final["height"] == 720


# --- Regression: download only when completed ---
def test_download_before_processing_returns_404(video_file):
    job_id = upload(video_file)["jobId"]
    response = requests.get(f"{BASE_URL}/api/download/{job_id}", timeout=30)
    assert response.status_code == 404
    assert response.json()["detail"] == "Video belum selesai diproses."


def test_download_unknown_job_returns_404():
    assert requests.get(f"{BASE_URL}/api/download/job_missing", timeout=30).status_code == 404


# --- Regression: corrupt / empty uploads rejected at boundary ---
@pytest.mark.parametrize("name, content, content_type", [
    ("TEST_empty.mp4", b"", "video/mp4"),
    ("TEST_corrupt.mp4", b"\x00\x01\x02notavideo" * 50, "video/mp4"),
])
def test_upload_rejects_unreadable_video(name, content, content_type):
    response = requests.post(f"{BASE_URL}/api/upload",
                             files={"file": (name, content, content_type)},
                             headers=unique_ip(), timeout=60)
    assert response.status_code == 400, response.text[:300]
    assert "tidak dapat dibaca" in response.json()["detail"]


def test_upload_rejects_wrong_extension():
    response = requests.post(f"{BASE_URL}/api/upload",
                             files={"file": ("TEST_bad.txt", b"nope", "text/plain")},
                             headers=unique_ip(), timeout=30)
    assert response.status_code == 400
    assert "Format video" in response.json()["detail"]


# --- Regression: app health / startup cleanup loop did not crash the app ---
def test_root_healthy():
    response = requests.get(f"{BASE_URL}/api/", timeout=30)
    assert response.status_code == 200
    assert response.json() == {"message": "SW HDR ready"}
