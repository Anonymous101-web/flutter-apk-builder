"""Coverage for new 1440p / 2160p qualities plus quality-validation regressions."""
import os
import subprocess
import time
import uuid

import pytest
import requests
from dotenv import dotenv_values

frontend_env = dotenv_values("/app/frontend/.env")
base_url = os.environ.get("REACT_APP_BACKEND_URL") or frontend_env.get("REACT_APP_BACKEND_URL")
if not base_url:
    raise RuntimeError("REACT_APP_BACKEND_URL missing")
BASE_URL = base_url.rstrip("/")


def unique_ip():
    n = uuid.uuid4().int
    return {"X-Forwarded-For": f"198.20.{n % 250}.{(n // 251) % 250}"}


def _make_clip(path, size):
    subprocess.run(
        ["ffmpeg", "-y", "-f", "lavfi", "-i", f"color=c=green:s={size}:r=24",
         "-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo", "-t", "1",
         "-shortest", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", str(path)],
        check=True, capture_output=True,
    )
    return path


@pytest.fixture(scope="module")
def video_file(tmp_path_factory):
    """4:3 source (320x240) - scale=-2:H must preserve aspect ratio."""
    return _make_clip(tmp_path_factory.mktemp("media") / "TEST_highres.mp4", "320x240")


@pytest.fixture(scope="module")
def video_file_169(tmp_path_factory):
    """16:9 source (320x180) - scale=-2:1440 => 2560x1440, -2:2160 => 3840x2160."""
    return _make_clip(tmp_path_factory.mktemp("media169") / "TEST_highres169.mp4", "320x180")


def upload(video_file):
    with video_file.open("rb") as stream:
        response = requests.post(
            f"{BASE_URL}/api/upload",
            files={"file": (video_file.name, stream, "video/mp4")},
            headers=unique_ip(), timeout=60,
        )
    assert response.status_code == 200, f"{response.status_code} {response.text[:300]}"
    return response.json()


def wait_terminal(job_id, timeout=120):
    deadline = time.time() + timeout
    payload = {}
    while time.time() < deadline:
        response = requests.get(f"{BASE_URL}/api/progress/{job_id}", timeout=30)
        assert response.status_code == 200, response.text[:200]
        payload = response.json()
        if payload["status"] in {"completed", "error"}:
            return payload
        time.sleep(1)
    return payload


# --- New: 2K (1440p) end-to-end ---
def test_process_1440p_preserves_aspect_from_4_3_source(video_file):
    job_id = upload(video_file)["jobId"]
    started = requests.post(f"{BASE_URL}/api/process",
                            json={"jobId": job_id, "quality": "1440p", "preset": "none"},
                            headers=unique_ip(), timeout=30)
    assert started.status_code == 200 and started.json() == {"success": True, "jobId": job_id}
    final = wait_terminal(job_id, timeout=120)
    assert final["status"] == "completed", final
    assert final["progress"] == 100
    # 320x240 (4:3) upscaled to height 1440 => 1920x1440
    assert final["width"] == 1920 and final["height"] == 1440, final
    assert isinstance(final["size"], int) and final["size"] > 0

    download = requests.get(f"{BASE_URL}/api/download/{job_id}", timeout=120)
    assert download.status_code == 200
    assert download.content[4:8] == b"ftyp"


def test_process_1440p_outputs_2560x1440_for_16_9_source(video_file_169):
    job_id = upload(video_file_169)["jobId"]
    started = requests.post(f"{BASE_URL}/api/process",
                            json={"jobId": job_id, "quality": "1440p", "preset": "none"},
                            headers=unique_ip(), timeout=30)
    assert started.status_code == 200
    final = wait_terminal(job_id, timeout=120)
    assert final["status"] == "completed", final
    assert final["width"] == 2560 and final["height"] == 1440, final


# --- New: 4K (2160p) end-to-end ---
def test_process_2160p_preserves_aspect_from_4_3_source(video_file):
    job_id = upload(video_file)["jobId"]
    started = requests.post(f"{BASE_URL}/api/process",
                            json={"jobId": job_id, "quality": "2160p", "preset": "none"},
                            headers=unique_ip(), timeout=30)
    assert started.status_code == 200
    final = wait_terminal(job_id, timeout=180)
    assert final["status"] == "completed", final
    assert final["width"] == 2880 and final["height"] == 2160, final
    assert isinstance(final["size"], int) and final["size"] > 0


def test_process_2160p_outputs_3840x2160_for_16_9_source(video_file_169):
    job_id = upload(video_file_169)["jobId"]
    started = requests.post(f"{BASE_URL}/api/process",
                            json={"jobId": job_id, "quality": "2160p", "preset": "none"},
                            headers=unique_ip(), timeout=30)
    assert started.status_code == 200
    final = wait_terminal(job_id, timeout=180)
    assert final["status"] == "completed", final
    assert final["width"] == 3840 and final["height"] == 2160, final
    download = requests.get(f"{BASE_URL}/api/download/{job_id}", timeout=180)
    assert download.status_code == 200
    assert download.content[4:8] == b"ftyp"


# --- Regression: existing qualities unchanged ---
@pytest.mark.parametrize("quality, expected", [
    ("original", (320, 240)),
    ("720p", (960, 720)),
    ("1080p", (1440, 1080)),
])
def test_existing_qualities_regression(video_file, quality, expected):
    job_id = upload(video_file)["jobId"]
    started = requests.post(f"{BASE_URL}/api/process",
                            json={"jobId": job_id, "quality": quality, "preset": "none"},
                            headers=unique_ip(), timeout=30)
    assert started.status_code == 200
    final = wait_terminal(job_id, timeout=90)
    assert final["status"] == "completed", final
    assert (final["width"], final["height"]) == expected, final


# --- Regression: invalid quality strings rejected ---
@pytest.mark.parametrize("quality", ["4k", "2K", "", "2160", "1440P", "8k", "original ", "none"])
def test_invalid_quality_rejected(video_file, quality):
    job_id = upload(video_file)["jobId"]
    response = requests.post(f"{BASE_URL}/api/process",
                             json={"jobId": job_id, "quality": quality, "preset": "none"},
                             headers=unique_ip(), timeout=30)
    assert response.status_code == 400, response.text[:300]
    assert response.json()["detail"] == "Kualitas tidak dikenali."
    progress = requests.get(f"{BASE_URL}/api/progress/{job_id}", timeout=30).json()
    assert progress["status"] == "uploaded", progress


# --- Regression: new quality + preset -> preset wins (padded dims) ---
def test_1440p_with_preset_uses_preset_dimensions(video_file):
    job_id = upload(video_file)["jobId"]
    started = requests.post(f"{BASE_URL}/api/process",
                            json={"jobId": job_id, "quality": "2160p", "preset": "whatsapp_feed"},
                            headers=unique_ip(), timeout=30)
    assert started.status_code == 200
    final = wait_terminal(job_id, timeout=120)
    assert final["status"] == "completed", final
    assert final["width"] == 1080 and final["height"] == 1080, final


# --- Regression: invalid preset / unknown job ---
def test_invalid_preset_still_400(video_file):
    job_id = upload(video_file)["jobId"]
    response = requests.post(f"{BASE_URL}/api/process",
                             json={"jobId": job_id, "quality": "1440p", "preset": "tiktok"},
                             headers=unique_ip(), timeout=30)
    assert response.status_code == 400
    assert response.json()["detail"] == "Preset tidak tersedia."


def test_unknown_job_returns_404():
    response = requests.post(f"{BASE_URL}/api/process",
                             json={"jobId": "job_missing_highres", "quality": "2160p"},
                             headers=unique_ip(), timeout=30)
    assert response.status_code == 404


def test_corrupt_upload_returns_400():
    response = requests.post(f"{BASE_URL}/api/upload",
                             files={"file": ("TEST_corrupt_hr.mp4", b"\x00notavideo" * 40, "video/mp4")},
                             headers=unique_ip(), timeout=60)
    assert response.status_code == 400
    assert "tidak dapat dibaca" in response.json()["detail"]


def test_root_healthy():
    response = requests.get(f"{BASE_URL}/api/", timeout=30)
    assert response.status_code == 200
    assert response.json() == {"message": "SW HDR ready"}
