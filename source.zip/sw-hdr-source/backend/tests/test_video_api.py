"""Regression coverage for SW HDR video upload and FFmpeg processing APIs."""
import os
import subprocess
import time

import pytest
import requests
import uuid

from dotenv import dotenv_values

_frontend_env = dotenv_values("/app/frontend/.env")
_base_url = os.environ.get("REACT_APP_BACKEND_URL") or _frontend_env.get("REACT_APP_BACKEND_URL")
if not _base_url:
    raise RuntimeError("REACT_APP_BACKEND_URL is missing from the process environment and /app/frontend/.env")
BASE_URL = _base_url.rstrip("/")


def unique_ip():
    """Unique X-Forwarded-For per request so IP rate buckets are never shared."""
    n = uuid.uuid4().int
    return {"X-Forwarded-For": f"198.19.{n % 250}.{(n // 251) % 250}"}


@pytest.fixture(scope="module")
def video_file(tmp_path_factory):
    path = tmp_path_factory.mktemp("media") / "TEST_sample.mp4"
    subprocess.run(
        ["ffmpeg", "-y", "-f", "lavfi", "-i", "color=c=blue:s=320x240:r=24",
         "-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo", "-t", "1",
         "-shortest", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", str(path)],
        check=True, capture_output=True,
    )
    return path


def test_upload_rejects_non_video():
    response = requests.post(
        f"{BASE_URL}/api/upload",
        files={"file": ("TEST_bad.txt", b"not video", "text/plain")},
        headers=unique_ip(),
    )
    assert response.status_code == 400
    assert "Format video" in response.json()["detail"]


def test_upload_process_progress_and_download(video_file):
    with video_file.open("rb") as stream:
        uploaded = requests.post(
            f"{BASE_URL}/api/upload",
            files={"file": (video_file.name, stream, "video/mp4")},
            headers=unique_ip(),
        )
    assert uploaded.status_code == 200
    metadata = uploaded.json()
    assert metadata["success"] is True
    assert isinstance(metadata["jobId"], str) and metadata["jobId"].startswith("job_")
    assert metadata["width"] == 320 and metadata["height"] == 240
    job_id = metadata["jobId"]

    started = requests.post(f"{BASE_URL}/api/process", json={"jobId": job_id, "quality": "720p"}, headers=unique_ip())
    assert started.status_code == 200 and started.json()["jobId"] == job_id
    for _ in range(30):
        progress = requests.get(f"{BASE_URL}/api/progress/{job_id}").json()
        if progress["status"] in {"completed", "error"}:
            break
        time.sleep(0.5)
    assert progress["status"] == "completed"
    assert progress["progress"] == 100
    assert progress["width"] == 960 and progress["height"] == 720

    download = requests.get(f"{BASE_URL}/api/download/{job_id}")
    assert download.status_code == 200
    assert download.headers["content-type"].startswith("video/mp4")
    assert download.content[4:8] == b"ftyp"


def test_whatsapp_status_preset_outputs_vertical_video(video_file):
    """Regression coverage for WhatsApp Status preset validation and 9:16 output."""
    with video_file.open("rb") as stream:
        uploaded = requests.post(
            f"{BASE_URL}/api/upload",
            files={"file": (video_file.name, stream, "video/mp4")},
            headers=unique_ip(),
        )
    assert uploaded.status_code == 200
    job_id = uploaded.json()["jobId"]

    started = requests.post(
        f"{BASE_URL}/api/process",
        json={"jobId": job_id, "quality": "720p", "preset": "whatsapp_status"},
        headers=unique_ip(),
    )
    assert started.status_code == 200
    for _ in range(30):
        progress = requests.get(f"{BASE_URL}/api/progress/{job_id}").json()
        if progress["status"] in {"completed", "error"}:
            break
        time.sleep(0.5)
    assert progress["status"] == "completed"
    assert progress["width"] == 720 and progress["height"] == 1280


def test_process_rejects_unknown_preset(video_file):
    """Regression coverage for unsupported preset input."""
    with video_file.open("rb") as stream:
        uploaded = requests.post(
            f"{BASE_URL}/api/upload",
            files={"file": (video_file.name, stream, "video/mp4")},
            headers=unique_ip(),
        )
    assert uploaded.status_code == 200
    response = requests.post(
        f"{BASE_URL}/api/process",
        json={"jobId": uploaded.json()["jobId"], "preset": "unknown"},
        headers=unique_ip(),
    )
    assert response.status_code == 400
    assert response.json()["detail"] == "Preset tidak tersedia."


@pytest.mark.parametrize(
    ("preset", "expected_width", "expected_height"),
    [
        ("landscape", 1280, 720),
        ("portrait", 720, 1280),
        ("whatsapp_feed", 1080, 1080),
    ],
)
def test_new_presets_output_dimensions(video_file, preset, expected_width, expected_height):
    """Regression coverage for Landscape, Portrait, and WhatsApp Feed dimensions."""
    with video_file.open("rb") as stream:
        uploaded = requests.post(
            f"{BASE_URL}/api/upload",
            files={"file": (video_file.name, stream, "video/mp4")},
            headers=unique_ip(),
        )
    assert uploaded.status_code == 200
    job_id = uploaded.json()["jobId"]
    started = requests.post(
        f"{BASE_URL}/api/process",
        json={"jobId": job_id, "quality": "1080p", "preset": preset},
        headers=unique_ip(),
    )
    assert started.status_code == 200
    for _ in range(30):
        progress = requests.get(f"{BASE_URL}/api/progress/{job_id}").json()
        if progress["status"] in {"completed", "error"}:
            break
        time.sleep(0.5)
    assert progress["status"] == "completed"
    assert progress["width"] == expected_width
    assert progress["height"] == expected_height


def test_process_rate_limit_returns_retry_after(video_file):
    """Process throttling returns 429 and does not change the normal first response."""
    with video_file.open("rb") as stream:
        uploaded = requests.post(
            f"{BASE_URL}/api/upload",
            files={"file": (video_file.name, stream, "video/mp4")},
            headers=unique_ip(),
        )
    assert uploaded.status_code == 200
    job_id = uploaded.json()["jobId"]
    headers = {"X-Forwarded-For": f"198.51.100.{uuid.uuid4().int % 200 + 20}"}
    responses = [requests.post(
        f"{BASE_URL}/api/process",
        json={"jobId": job_id, "quality": "720p", "preset": "none"},
        headers=headers,
    ) for _ in range(25)]
    assert responses[0].status_code == 200
    limited = next((response for response in responses if response.status_code == 429), None)
    assert limited is not None
    assert limited.headers.get("Retry-After")


def test_upload_rate_limit_returns_retry_after(video_file):
    """Upload throttling returns 429 and a Retry-After header after the configured burst."""
    responses = []
    headers = {"X-Forwarded-For": f"198.51.101.{uuid.uuid4().int % 200 + 20}"}
    for _ in range(13):
        with video_file.open("rb") as stream:
            responses.append(requests.post(
                f"{BASE_URL}/api/upload",
                files={"file": (video_file.name, stream, "video/mp4")},
                headers=headers,
            ))
    limited = next((response for response in responses if response.status_code == 429), None)
    assert limited is not None
    assert limited.headers.get("Retry-After")
    assert "Terlalu banyak" in limited.json()["detail"]