"""Auto Release feature tests: /api/release/info and /api/release/download"""
import io
import os
import re
import time
import zipfile
from pathlib import Path

import pytest
import requests
from dotenv import dotenv_values

frontend_env = dotenv_values("/app/frontend/.env")
base_url = os.environ.get("REACT_APP_BACKEND_URL") or frontend_env.get("REACT_APP_BACKEND_URL")
if not base_url:
    raise RuntimeError("REACT_APP_BACKEND_URL missing")
BASE_URL = base_url.rstrip("/")

REQUIRED_ENTRIES = [
    "sw-hdr-source/README.md",
    "sw-hdr-source/backend/server.py",
    "sw-hdr-source/backend/.env.example",
    "sw-hdr-source/frontend/package.json",
    "sw-hdr-source/frontend/.env.example",
    "sw-hdr-source/frontend/src/App.js",
    "sw-hdr-source/frontend/public/manifest.json",
]

FORBIDDEN_TOKENS = ["node_modules", "__pycache__", "video_jobs", "/build/", ".venv", ".git/",
                    "yarn.lock", "package-lock.json"]


@pytest.fixture(scope="module")
def client():
    s = requests.Session()
    return s


# --- /api/release/info ---
class TestReleaseInfo:
    def test_info_schema(self, client):
        r = client.get(f"{BASE_URL}/api/release/info", timeout=90)
        assert r.status_code == 200, r.text[:300]
        d = r.json()
        assert isinstance(d["version"], str)
        assert re.fullmatch(r"\d{4}\.\d{2}\.\d{2}-\d{4}", d["version"]), d["version"]
        assert isinstance(d["size"], int) and d["size"] > 100000, d["size"]
        assert re.fullmatch(r"[0-9a-f]{64}", d["sha256"]), d["sha256"]
        assert isinstance(d["files"], int) and d["files"] > 10, d["files"]
        assert isinstance(d["generated_at"], float) and d["generated_at"] > 0
        assert isinstance(d["filename"], str) and d["filename"].endswith(".zip")

    def test_info_cache_stable(self, client):
        a = client.get(f"{BASE_URL}/api/release/info", timeout=90).json()
        time.sleep(1)
        b = client.get(f"{BASE_URL}/api/release/info", timeout=90).json()
        assert a["sha256"] == b["sha256"], (a["sha256"], b["sha256"])
        assert a["size"] == b["size"]
        assert a["generated_at"] == b["generated_at"]

    def test_info_hash_changes_on_source_change(self, client):
        before = client.get(f"{BASE_URL}/api/release/info", timeout=90).json()
        target = Path("/app/frontend/src/App.js")
        assert target.exists()
        os.utime(target, (time.time() + 5, time.time() + 5))
        time.sleep(2)
        after = client.get(f"{BASE_URL}/api/release/info", timeout=90).json()
        assert after["generated_at"] != before["generated_at"], "mtime snapshot did not change"
        assert after["sha256"] != before["sha256"], "sha256 did not change after touching App.js"


# --- /api/release/download ---
class TestReleaseDownload:
    @pytest.fixture(scope="class")
    def download(self, client):
        r = client.get(f"{BASE_URL}/api/release/download", timeout=120)
        assert r.status_code == 200, r.text[:300]
        return r

    def test_headers(self, download):
        assert download.headers.get("content-type") == "application/zip"
        cd = download.headers.get("content-disposition", "")
        assert "attachment" in cd and ".zip" in cd, cd
        m = re.search(r'filename="([^"]+)"', cd)
        assert m and m.group(1).endswith(".zip"), cd
        assert re.fullmatch(r"[0-9a-f]{64}", download.headers.get("X-Release-Sha256", "")), download.headers
        assert re.fullmatch(r"\d{4}\.\d{2}\.\d{2}-\d{4}", download.headers.get("X-Release-Version", ""))

    def test_body_is_valid_zip_with_required_files(self, download):
        zf = zipfile.ZipFile(io.BytesIO(download.content))
        assert zf.testzip() is None
        names = zf.namelist()
        missing = [e for e in REQUIRED_ENTRIES if e not in names]
        assert not missing, f"missing entries: {missing}"

    def test_no_forbidden_content(self, download):
        names = zipfile.ZipFile(io.BytesIO(download.content)).namelist()
        bad = [n for n in names if any(t in f"/{n}" for t in FORBIDDEN_TOKENS)]
        bad += [n for n in names if Path(n).name == ".env"]
        assert not bad, f"forbidden entries present: {bad[:10]}"

    def test_sha_matches_info(self, client, download):
        info = client.get(f"{BASE_URL}/api/release/info", timeout=90).json()
        import hashlib
        assert hashlib.sha256(download.content).hexdigest() == download.headers["X-Release-Sha256"]
        # info and download served from same cache when no source change
        assert info["sha256"] == download.headers["X-Release-Sha256"]
